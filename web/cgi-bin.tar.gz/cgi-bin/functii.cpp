
#include "functii.h"
#include "cgi_cpp.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>

void afiseaza_informatii (const char *fisier)
{
	FILE *f = fopen (fisier, "r");
	if (f!=NULL)
	{
		printf ("<table width=90%>");
		while (!feof(f))
		{
			char *data = readline (f);
			char *text = readline (f);
			if (data!=NULL && text!=NULL)
			{
				printf ("<tr><td><b>%s</b></td><td>%s</td></tr>", filter_html_code(data), filter_html_code(text));
				free (data);
				free (text);
			}
		}
		printf ("</table>");
		fclose (f);
	}
}

const char *data_curenta ()
{
	time_t timp;
	time (&timp);
	tm *data = localtime (&timp);
	const char *zile[7] = {"Duminica", "Luni", "Marti", "Miercuri", "Joi",
			   		       "Vineri", "Sambata"};
	const char *luni[12] = {"Ianuarie", "Februarie", "Martie", "Aprilie", 
							"Mai", "Iunie", "Iulie", "August", "Septembrie"
			   		        "Octombrie", "Noiembrie", "Decembrie"};
	char str_data[100];
	sprintf (str_data, "%s, %d %s %d", zile[data->tm_wday], data->tm_mday,
			 luni[data->tm_mon], data->tm_year+1900);
	return  strdup (str_data);
}

/*char *readline (FILE *f)
{
	char *line = NULL;
	if (f==NULL) return NULL;
	if (!feof(f))
	{
		char v;
		int n;
		fread (&v, 1, 1, f);
		do
		{
			if (v!='\n')
			{
				if (line!=NULL) line = (char*)realloc (line, strlen (line)+2);
				else 
				{	
					line = (char*)malloc (2);
					line[0]='\0';
				}
				n = strlen(line);
				line [n] = v;
				line [n+1] = '\0';
			}
			fread (&v, 1, 1, f);
		} while (!feof(f) && v!='\n');
	}
	return line;
}*/
