
#ifndef _CGI_CPP__H
#define _CGI_CPP__H

#define CGI_CPP
#define DATA_PATH "../date"

#define getsession() getcookie("PS_ID")

// dimensiunea maxima adminsa pentru POST (x*1024 = x KB)
const int MAX_POST = 100*1024;
const int MAX_UPLOAD = 5*1024*1024;

// depanare
void debug (const char *name, const char *s);

// tipareste "Content-type"
void content (const char *s);
void style (const char *s);

// functii de filtrare
char * filter_UTF_8 (const char *s);
const char * filter_html_code (const char *s);
const char * filter_html_code_pre (const char *s);
const char * filter_html_code_textarea (const char *s);
char * code_UTF_8 (const char *s);
char * code_form (const char *s);

// functii de preluarea a datelor de la server
// ATENTIE! Se apeleaza o singura data
int getquery ();
int getpost ();

// functii pentru incarcarea de fisiere
void use_upload ();
char * get_upload_data (const char *filename, const char *accept, long &n);

// functii pentru preloarea valorii variabilelor
char * get_query_var (const char *s);
char * get_post_var (const char *s);

// cookies (prajiturele)
int setcookie (const char *nume, const char *date, const char *expira);
char * getcookie (const char *s);

// sesiuni
int session_new ();
int session_init ();
char * session_var_get (const char *_var);
void session_var_set (const char *var, const char *val);
void session_var_del (const char *_var);
void session_close ();

// informatii despre client
char *get_client_ip ();

#endif
