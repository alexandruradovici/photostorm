
#ifndef _FUNCTII__H
#define _FUNCTII__H

#include <stdio.h>

void afiseaza_informatii (const char *fisier);
const char *data_curenta ();
char *readline (FILE *f);

#endif
