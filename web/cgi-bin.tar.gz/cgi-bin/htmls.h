
#ifndef _HTMS__H
#define _HTMS__H

void write_header ();
void write_login ();
void write_download ();
void write_album_categories();
void write_right_start();
void write_right_end();
void write_menu_copyright ();
void main_display_init ();
void main_display_deinit ();
void write_vertical_line ();
void write_horizontal_line ();
void main_display_close ();
void write_small_album (int album_id, const char *name, const char *author, int nr_photos, const char* link);
void show_very_small_photo (int album_id, int photo_id, const char* alt_text, const char *link, const char *text);
void show_small_photo (int album_id, int photo_id, const char *link, const char* alt_text, const char *text);
void show_large_photo (int album_id, int photo_id, const char *link, const char *alt_text, const char *text);
#endif
