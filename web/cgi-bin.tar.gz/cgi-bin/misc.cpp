

#include "data.h"
#include "misc.h"
#include "photo.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int ps_random (int n)
{
    return rand ()%n;
}

void show_html (const char *html_file)
{
	if (html_file==NULL) return;
	char t[1000];
	sprintf (t, "%s/%s.html", psw_htmls_path, html_file);
	FILE *f = fopen (t, "r");
	if (f!=NULL)
	{
		while (!feof (f))
		{
			char v;
			fread (&v, 1, 1, f);
			if (!feof(f)) printf ("%c", v);
		}
		fclose (f);
	}
}

const char * album_path (const char *album)
{
    char s[1000];
    strcpy (s,"");
    if (album!=NULL) sprintf (s, "%s/%s.psa", psw_album_path, album);
    return strdup (s);
}

const char * album_path_ (const char *album)
{
    char s[1000];
    strcpy (s,"");
    if (album!=NULL) sprintf (s, "%s/%s", psw_album_path, album);
    return strdup (s);
}

const char * categories_path (const char *cat)
{
    char s[1000];
    strcpy (s,"");
    if (cat!=NULL) sprintf (s, "%s/%s", psw_categories_path, cat);
    return strdup (s);
}

const char * categories_path_ (const char *cat)
{
    char s[1000];
    strcpy (s,"");
    if (cat!=NULL) sprintf (s, "%s/%s.ps_cat", psw_categories_path, cat);
    return strdup (s);
}

const char * user_path (const char *user)
{
    char s[1000];
    strcpy (s,"");
    if (user!=NULL) sprintf (s, "%s/%s.ps_user", psw_users_path, user);
    return strdup (s);
}

const char * user_file (const char *user, const char *fis)
{
    char s[1000];
    strcpy (s,"");
    if (user!=NULL && fis!=NULL) sprintf (s, "%s/%s/%s", psw_users_path, user, fis);
    return strdup (s);
}

char * font_path (const char *font)
{
    char s[1000];
    strcpy (s,"");
    if (font!=NULL) sprintf (s, "%s/%s.ttf", psw_fonts_path, font);
    return strdup (s);
}

/*char * album_path (char *album)
{
	char *result;
	if (album==NULL) result=strdup ("");
	else
	{
		if (ps_albums_path!=NULL) result=(char*)malloc (strlen(ps_albums_path)+strlen(album)+10);
			else result=(char*)malloc (strlen(album)+10);
		if (result!=NULL)
		{
			if (ps_albums_path!=NULL) sprintf ((char*)result,"%s/%s",ps_albums_path,(char*)album);
				else sprintf ((char*)result,"./%s",(char*)album);
		}
	}
	return result;
}*/

/*char * pict_path (char *pict)
{
	char *result;
	if (pict==NULL) result=strdup ("");
	else
	{
		if (ps_pics_path!=NULL) result=(char*)malloc (strlen(ps_pics_path)+strlen(pict)+10);
			else result=(char*)malloc (strlen(pict)+10);
		if (result!=NULL)
		{
			if (ps_pics_path!=NULL) sprintf ((char*)result,"%s/%s",ps_pics_path,(char*)pict);
				else sprintf ((char*)result,"./%s",(char*)pict);
		}
	}
	return result;
}

char * font_path (char *font)
{
	char *result;
	if (font==NULL) result=strdup ("");
	else
	{
		if (ps_font_path!=NULL) result=(char*)malloc (strlen(ps_font_path)+strlen(font)+10);
			else result=(char*)malloc (strlen(font)+10);
		if (result!=NULL)
		{
			if (ps_font_path!=NULL) sprintf ((char*)result,"%s/%s.ttf",ps_font_path,(char*)font);
				else sprintf ((char*)result,"./%s.ttf",(char*)font);
		}
	}
	return result;
}*/

char * strtrim (const char *s_)
{
	char * result=NULL;
	if (s_!=NULL)
	{
		const char *s=s_;
		unsigned int i=0;
		unsigned int l=0;
		for (i=0;i<strlen(s_) && s_[i]==' ';i++) s++;
		if (i<strlen(s_))
		{
			const char *temp = s;
			for (i=strlen (temp)-1;i>=0 && temp[i]==' ';i--) l++;
			result = (char*)malloc (strlen (temp)-l+1);
			if (result!=NULL)
			{
				strncpy (result, temp, strlen(temp)-l);
				result [strlen(temp)-l]='\0';
			}
		}
	}
	return result;
}

char * ps_stronly (const char *s_, const char *chars_)
{
	char temp[1000];
	strcpy (temp, "");
	int k=0;
	if (s_!=NULL)
	{
		for (unsigned int i=0;i<strlen(s_);i++)
		if (strchr (chars_, s_[i])!=NULL)
		{
		    temp[k]=s_[i];
		    temp[k+1]='\0';
		    k++;
		}
	}
	return strdup (temp);
}

char * ps_strfilter_filename (char *filename)
{
	char * result = NULL;
	if (filename!=NULL)
	{
		result = strtrim (filename);
		for (unsigned int i=0;i<strlen (result);i++) 
			if (result[i]==' ' || result[i]=='\\' || result[i]=='/') result[i]='_';
	}
	return result;
}

char * ps_replace_str (char *s, unsigned long lmax)
{
	char *result=NULL;
	if (s!=NULL)
	{
		if (strlen(s)>lmax) s[lmax]='\0';
		result=(char*)malloc (strlen(s)+1);
		strcpy (result, s);
		result[strlen(s)]='\0';
	}
	return result;
}
char * extract_path (const char *str)
{
	char * result = strdup ("");
	if (str!=NULL)
	{
		char temp[10000];
		strcpy (temp,"");
		int gata = 0;
		int i=strlen(str);
		while (!gata && i>0)
		{
			i--;
			if (str[i]=='\\' || str[i]=='/') gata=1;
		}
		strncpy (temp, str, i);
		temp[i]='\0';
		result = strdup (temp);
		printf ("calea: %s\n", result);
	}
	return result;
}

char *nexttoken (char *s, const char *separators)
{
	char *token = NULL;
	if (s!=NULL)
	{
		char t[10000];
		strcpy (t,"");
		int g=0;
		int found=0;
		unsigned int i=0;
		while (i<strlen(s) && !found)
		{
			if (s[i]=='\"') 
			{	
				g=!g;
				if (g==0) found=1;
			}
			else 
			if (!g && strchr (separators, s[i])!=NULL) found=1;
			else
			{
				int n=strlen (t);
				t[n]=s[i];
				t[n+1]='\0';
				n++;
			}
			i++;
		}
		if (i<strlen(s)) sprintf (s, "%s", &s[i]);
			else strcpy (s, "");
		if (strlen(t)>0) token = strdup (t);
	}
	return token;
}

int search_keywords (char *keys_, const char *keywords_)
{
	int result = 0;
	char *keys = strdup (keys_);
	char *keywords = strdup (keywords_);
	if (keywords!=NULL)
	{
		if (keys!=NULL) for (unsigned int i=0;i<strlen(keys);i++) keys[i] = tolower (keys[i]);
		for (unsigned int i=0;i<strlen(keywords);i++) keywords[i] = tolower (keywords[i]);
		char *key = nexttoken (keys, ", ");
		while (key!=NULL)
		{
			//printf ("key: -%s-<br>", key);
			if (strstr (keywords, key)!=NULL) return 1;
			key = nexttoken (keys, ", ");
		}
	}
	return result;
}

int search_keywords_ (char *keys_, const char *keywords_)
{
	int result = 1;
	char *keys = strdup (keys_);
	char *keywords = strdup (keywords_);
	if (keywords!=NULL)
	{
		if (keys!=NULL) for (unsigned int i=0;i<strlen(keys);i++) keys[i] = tolower (keys[i]);
		for (unsigned int i=0;i<strlen(keywords);i++) keywords[i] = tolower (keywords[i]);
		char *key = nexttoken (keys, ", ");
		while (key!=NULL)
		{
			if (strstr (keywords, key)==NULL) return 0;
			key = nexttoken (NULL, ", ");
		}
	}
	return result;
}

char *readline (FILE *f)
{
	char *line = NULL;
	if (!feof(f))
	{
		char v;
		int n;
		fread (&v, 1, 1, f);
		do
		{
			if (v!='\n')
			{
				if (line!=NULL) line = (char*)realloc (line, strlen (line)+2);
				else 
				{	
					line = (char*)malloc (2);
					line[0]='\0';
				}
				n = strlen(line);
				line [n] = v;
				line [n+1] = '\0';
			}
			fread (&v, 1, 1, f);
		} while (!feof(f) && v!='\n');
	}
	return line;
}

int ps_strtoint (const char *str)
{
    int nr=0;
    if (str!=NULL)
    {
		if (strcmp (str,"yes")==0) nr=1;
		else
		if (strcasecmp (str,"on")==0) nr=1;
		else
		if (strcmp (str,"no")==0) nr=0;
		else
		sscanf (str, "%d", &nr);
    }
    return nr;
}

const char * ps_inttostr (int nr)
{
	char temp[100];
	sprintf (temp, "%d", nr);
	return strdup (temp);
}

_ps_color * ps_strtocolor (const char *str)
{
	_ps_color *color = ps_pack_color (255, 255, 255, 0);
	if (strcmp (str,"white")==0)
	{
		color->red=255;
		color->green=255;
		color->blue=255;
		color->alpha=0;
	}
	else
	if (strcmp (str,"black")==0)
	{
		color->red=0;
		color->green=0;
		color->blue=0;
		color->alpha=0;
	}
	else
	if (strcmp (str,"red")==0)
	{
		color->red=255;
		color->green=0;
		color->blue=0;
		color->alpha=0;
	}
	else
	if (strcmp (str,"green")==0)
	{
		color->red=0;
		color->green=255;
		color->blue=0;
		color->alpha=0;
	}
	else
	if (strcmp (str,"blue")==0)
	{
		color->red=255;
		color->green=255;
		color->blue=255;
		color->alpha=0;
	}
	else
	if (strcmp (str,"yellow")==0)
	{
		color->red=255;
		color->green=255;
		color->blue=0;
		color->alpha=0;
	}
	else
	if (strcmp (str,"magenta")==0)
	{
		color->red=255;
		color->green=0;
		color->blue=255;
		color->alpha=0;
	}
	else
	if (strcmp (str,"cyan")==0)
	{
		color->red=0;
		color->green=255;
		color->blue=255;
		color->alpha=0;
	}
	else
	{
		int red, green, blue, alpha;
		sscanf (str, "%d,%d,%d,%d", &red, &green, &blue, &alpha);
		alpha = 127-alpha*127/255;
		color->red=red;
		color->green=green;
		color->blue=blue;
		color->alpha=alpha;
	}
	return color;
}

const char * ps_colortostr (_ps_color color)
{
	char temp[100];
	if (color.red==255 && color.green==255 && color.blue==255 && color.alpha==0)
		strcpy (temp, "white");
	else
	if (color.red==0 && color.green==0 && color.blue==0 && color.alpha==0)
		strcpy (temp, "black");
	else
	if (color.red==255 && color.green==0 && color.blue==0 && color.alpha==0)
		strcpy (temp, "red");
	else
	if (color.red==0 && color.green==255 && color.blue==0 && color.alpha==0)
		strcpy (temp, "green");
	else
	if (color.red==0 && color.green==0 && color.blue==255 && color.alpha==0)
		strcpy (temp, "blue");
	else
	if (color.red==255 && color.green==255 && color.blue==0 && color.alpha==0)
		strcpy (temp, "yellow");
	else
	if (color.red==0 && color.green==255 && color.blue==255 && color.alpha==0)
		strcpy (temp, "cyan");
	else
	if (color.red==255 && color.green==0 && color.blue==255 && color.alpha==0)
		strcpy (temp, "magenta");
	else
		sprintf (temp, "%d,%d,%d,%d", color.red, color.green, color.blue, (int)(255-color.alpha*255/127));
	return strdup (temp);
}

_ps_color * ps_pack_color (int r, int g, int b, int alpha)
{
	_ps_color *result = (_ps_color*)malloc (sizeof(_ps_color));
	if (result!=NULL)
	{
		result->red = r;
		result->green = g;
		result->blue = b;
		result->alpha = alpha;
	}
	return result;
}
