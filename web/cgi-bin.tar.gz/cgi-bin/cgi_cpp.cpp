
#include "cgi_cpp.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <zlib.h>

static int upload = false;
static char query [257];
static char buffer [MAX_UPLOAD+2];
static long buffer_size=0;
static char session_id [256];

void debug (const char *name, const char *s)
{
	FILE *f = fopen ("debug.txt", "a+");
	if (f!=NULL)
	{
		fprintf (f, "%s: \"%s\"\n", name, s);
		fclose (f);
	}
}

void content (const char *s)
{
	printf ("Content-type: %s\n\n",s);
}

void style (const char *s)
{
	if (s!=NULL) printf ("<link href=\"%s\" type=\"text/css\" rel=\"StyleSheet\">", s);
}

int convert16 (char v)
{
	int result=-1;
	v=toupper (v);
	if (v>=48 && v<=57) result=v-48;
	if (v>=65 && v<=70) result=v-55;
	return result;
}

char * filter_UTF_8 (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		int j;
		int n=strlen (s);
		char *buf;
		buf=(char *)malloc (strlen(s)+1);
		strcpy (buf,"");
		j=0;
		for (int i=0;i<n;i++)
		{
			if (s[i]=='%')
			{
				char v=convert16(s[i+1])*16+convert16(s[i+2]);
				buf[j]=v;
				buf[j+1]='\0';
				j++;
				i=i+2;
			}
			else
			{
				if (s[i]=='+') buf[j]=' ';
				else buf[j]=s[i];
				buf[j+1]='\0';
				j++;
			}
		}
		result=strdup(buf);
		free (buf);
	}
	return result;
}

char * code_UTF_8 (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		int j;
		int n=strlen (s);
		char *buf;
		buf=(char *)malloc (1);
		strcpy (buf,"");
		j=0;
		for (int i=0;i<n;i++)
		{
			if (s[i]=='\"')
			{
				buf=(char *)realloc (buf, strlen(buf)+4);
				sprintf (&buf[j],"%%%d",22);
				j+=3;
			}
			else
			{
				buf=(char *)realloc (buf, strlen(buf)+2);
				if (s[i]==' ') buf[j]='+';
				else buf[j]=s[i];
				buf[j+1]='\0';
				j++;
			}
		}
		result=strdup(buf);
		free (buf);
	}
	return result;
}

char * code_form (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		int j;
		int n=strlen (s);
		char *buf;
		buf=(char *)malloc (1);
		strcpy (buf,"");
		j=0;
		for (int i=0;i<n;i++)
		{
			if (s[i]=='\"')
			{
				buf=(char *)realloc (buf, strlen(buf)+3);
				sprintf (&buf[j],"\"\"");
				j+=2;
			}
			else
			{
				buf=(char *)realloc (buf, strlen(buf)+2);
				buf[j]=s[i];
				buf[j+1]='\0';
				j++;
			}
		}
		result=strdup(buf);
		free (buf);
	}
	return result;
}

const char * filter_html_code (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		int j;
		int n=strlen (s);
		char *buf;
		buf=(char *)malloc (1);
		strcpy (buf,"");
		j=0;
		for (int i=0;i<n;i++)
		{
			char temp[10];
			switch (s[i])
			{
				case '<': strcpy (temp, "&lt;"); break;
				case '>': strcpy (temp, "&gt;"); break;
				case ' ': (i>0 && s[i-1]==' ')?strcpy (temp, "&nbsp;"):strcpy (temp, " "); break;
				case '\"': strcpy (temp, "&quot;"); break;
				case '&': strcpy (temp, "&amp;"); break;
				case '\n': strcpy (temp, "<br>"); break;
				default: sprintf (temp, "%c", s[i]);
			}
			buf = (char*)realloc (buf, strlen (buf)+strlen(temp)+1);
			strcat (buf, temp);
		}
		result=strdup(buf);
		free (buf);
	}
	return result;
}

const char * filter_html_code_pre (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		int j;
		int n=strlen (s);
		char *buf;
		buf=strdup ("<p align=justify>");
		j=0;
		for (int i=0;i<n;i++)
		{
			char temp[10];
			switch (s[i])
			{
				case '<': strcpy (temp, "&lt;"); break;
				case '>': strcpy (temp, "&gt;"); break;
				case ' ': (i>0 && s[i-1]==' ')?strcpy (temp, "&nbsp;"):strcpy (temp, " "); break;
				case '\"': strcpy (temp, "&quot;"); break;
				case '&': strcpy (temp, "&amp;"); break;
				case '\n': strcpy (temp, "<p align=justify>"); break;
				default: sprintf (temp, "%c", s[i]);
			}
			buf = (char*)realloc (buf, strlen (buf)+strlen(temp)+1);
			strcat (buf, temp);
		}
		result=strdup(buf);
		free (buf);
	}
	return result;
}

const char * filter_html_code_textarea (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		int j;
		int n=strlen (s);
		char *buf;
		buf=(char *)malloc (1);
		strcpy (buf,"");
		j=0;
		for (int i=0;i<n;i++)
		{
			char temp[10];
			switch (s[i])
			{
				case '<': strcpy (temp, "&lt;"); break;
				case '>': strcpy (temp, "&gt;"); break;
				case ' ': (i>0 && s[i-1]==' ')?strcpy (temp, "&nbsp;"):strcpy (temp, " "); break;
				default: sprintf (temp, "%c", s[i]);
			}
			buf = (char*)realloc (buf, strlen (buf)+strlen(temp)+1);
			strcat (buf, temp);
		}
		result=strdup(buf);
		free (buf);
	}
	return result;
}

int getquery ()
{
    char *s=getenv("QUERY_STRING");
	if (s!=NULL)
	{
		if (strlen(s)>255) s[256]='\0';
		strcpy (query, "?");
		strcat (query,(char*)s);
	}
	return 0;
}

int getpost ()
{
	long n=-1;
	long i=0;
	char *s1=getenv ("CONTENT_LENGTH");
	if (s1!=NULL) 
	{	
		sscanf (s1,"%ld",&n);
		n=n+1;
	}
	else n=0;
	int max_post = MAX_POST;
	if (upload) max_post = MAX_UPLOAD;
	if (n>max_post) n=max_post;
	strcpy (buffer,"?");
	while (!feof (stdin) && i<n)
	{
		i++;
		char c;
		scanf ("%c",&c);
		buffer[i]=c;
	}
	buffer[i]='\0';
	buffer_size=n;
	return 0;
}

char * get_query_var (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		char *buf=(char*)malloc (strlen(s)+3);
		strcpy (buf, "&");
		strcat (buf, s);
		int t=strlen(buf);
		buf[t]='=';
		buf[t+1]='\0';
		s=strdup (buf);
		char *s1=strstr (query,s);
		if (s1==NULL)
		{
			buf[0]='?';
			s=strdup (buf);
			s1=strstr (query,s);
		}
		if (s1!=NULL)
		{
			s1=s1+strlen (s);
			if (s1!=NULL)
			{
				char *buf=strdup ("");
				unsigned int n=0;
				while (n<strlen (s1) && s1[n]!='&')
				{
					buf = (char*)realloc (buf, strlen (buf)+2);
					buf[n]=s1[n];
					n++;
				}
				buf[n]='\0';
				if (strlen (buf)==0) result = NULL;
				else result = strdup (buf);
			}
		}
	}
	return filter_UTF_8(result);
}

char * get_post_var (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		char *buf=(char*)malloc (strlen(s)+3);
		strcpy (buf, "&");
		strcat (buf, s);
		int t=strlen(buf);
		buf[t]='=';
		buf[t+1]='\0';
		s=strdup (buf);
		char *s1=strstr (buffer,s);
		if (s1==NULL)
		{
			buf[0]='?';
			s=strdup (buf);
			s1=strstr (buffer,s);
		}
		//debug ("buffer", buffer);
		if (s1!=NULL)
		{
			s1=s1+strlen (s);
			if (s1!=NULL)
			{
				char *buf=strdup ("");
				unsigned int n=0;
				while (n<strlen (s1) && s1[n]!='&')
				{
					buf = (char*)realloc (buf, strlen(buf)+2);
					buf[n]=s1[n];
					n++;
				}
				buf[n]='\0';
				if (strlen (buf)==0) result = NULL;
				else result = strdup (buf);
			}
		}
	}
	return filter_UTF_8(result);
}

int setcookie (const char *nume, const char *date, const char *expira)
{
	if (nume!=NULL && date!=NULL && expira!=NULL) 
	{	
		printf ("Set-Cookie: %s=%s;\n",nume,date); // mai vine adaugata faza cu expirarea
		return 1;
	}
	else return 0;
}

char * getcookie (const char *s)
{
	char *s1=getenv ("HTTP_COOKIE");
	char *result=NULL;
	if (s1!=NULL && s!=NULL)
	{
		char *s2=(char*)malloc (strlen(s)+2);
		strcpy (s2,s);
		strcat (s2,"=");
		s=strdup (s2);
		free (s2);
		s1=strstr (s1,s);
		if (s1!=NULL)
		{
			s1=s1+strlen (s);
			if (s1!=NULL)
			{
				char *buf=strdup("");
				unsigned int n=0;
				while (n<strlen (s1) && s1[n]!=';')
				{
					buf = (char*)realloc (buf, strlen(buf)+2);
					buf[n]=s1[n];
					n++;
				}
				buf[n]='\0';
				if (strlen (buf)==0) result = NULL;
				else result = strdup (buf);
			}
		}
	}
	return filter_UTF_8 (result);
}

void use_upload ()
{
	upload = true;
}

char *readline_from (const char *data, long n, int start, int &stop)
{
	//printf ("start :%d\n", start);
	if (!data || n<0) return NULL;
	char *line = NULL;
	char s[1000];
	int i=start;
	int j=-1;
	do
	{
		i++;
		if (data[i]!='\n' && data[i]!='\r' && i<n) 
		{
			j++;
			s[j]=data[i];
		}
	} while (data[i]!='\n' && data[i]!='\r' && i<n);
	if (data[i+1]=='\r' || data[i+1]=='\n') i++;
	s[j+1]='\0';
	//printf ("s: (%s)\n", s);
	line = strdup (s);
	stop = i;
	return line;
}

char * get_upload_data (const char *filename, const char *accept, long &n)
{
	//content ("text/plain");
	if (filename==NULL) return NULL;
	char *data = NULL;
	char *delimit;
	n=0;
	int p;
	if ((delimit = readline_from (buffer, buffer_size, 1, p)));
		else return NULL;
	int gasit = 0;
	int finish=0;
	while (!finish)
	{
		char *date = readline_from (buffer, buffer_size, p, p);
		if (p>buffer_size) finish=1;
		else
		if (date!=NULL)
		{
			//printf ("(%s)\n", date);
			if (strncasecmp ("Content-Disposition:", date, 20)==0) 
			{
				char t[100];
				sprintf (t, "name=\"%s\"", filename);
				if (strstr (date, t)) gasit=1;
			}
			if (strncasecmp ("Content-Type:", date, 13)==0)
			{
				char t[100];
				if (accept!=NULL)
				{
					sprintf (t, "%s", accept);
					if (gasit==1 && strstr (date, t)==NULL) finish=1;
				}
			}
			if (strcmp (date, "")==0)
			{
				//printf ("Data\n");
				int st=p+1;
				int l=strlen (delimit);
				int citit=0;
				while (p+l-2<buffer_size && !citit)
				{
					if (memcmp (delimit, &buffer[p], l)==0) citit=1;
					p++;
				}
				if (gasit && citit) 
				{	
					//printf ("Loaded\n");
					n=p-st-4;
					data = (char*)malloc (n);
					memcpy (data, &buffer[st], n);
					finish=1;
				}
			}
			free (date);
		}
	}
	free (delimit);
	//printf ("delimit: %s\n", delimit);
	//fwrite (buffer, buffer_size, 1, stdout);
	return data;
}

int session_new ()
{
	int result = 0;
	session_close ();
	char new_id[100];
	time_t timp;
	time (&timp);
	srand (time(0));
	long nr = (int)(999999999.0*rand()/RAND_MAX+1);
	char *ip = get_client_ip ();
	sprintf (new_id, "%ld%ld", timp, nr);
	char fs[1000];
	sprintf (fs, "%s/sessions/%s-%s.ps_id", DATA_PATH, ip, new_id);
	FILE *f = fopen (fs, "wb");
	if (f!=NULL)
	{
		setcookie ("PS_ID", new_id, "");
		strcpy (session_id, new_id);
		result = 1;
		fclose (f);
	} else strcpy (new_id,"");
	return result;
}

int session_init ()
{
	int r=1;
	char *id = getsession ();
	if (id!=NULL) strcpy (session_id, id);
		else
		{			
			strcpy (session_id, "");
			r=0;
		}
	return r;
}

void session_var_set (const char *var, const char *val)
{
	if (var!=NULL && val!=NULL && strcmp(session_id,"")!=0)
	{
		session_var_del (var);
		char *date = NULL;
		long n=0;
		long n2=0;
		char fs[1000];
		char *ip = get_client_ip ();
		sprintf (fs, "%s/sessions/%s-%s.ps_id", DATA_PATH, ip, session_id);
		gzFile f = gzopen (fs, "rb");
		if (f!=NULL)
		{	
			gzread (f, &n, 4);
			if (n>0 && n<2*MAX_POST) 
			{	
				date = (char*)malloc (n);
				if (date) gzread (f, date, n);
					else n=0;
			}
			else n=0;
			gzclose (f);
		}
		if (n>=0)
		{
			unsigned char nchar=strlen (var);
			long nlong=strlen (val);
			n2=n+nchar+1+nlong+4;
			gzFile f = gzopen (fs, "wb");
			if (f!=NULL)
			{
				gzwrite (f, &n2, 4);
				if (date!=NULL) gzwrite (f, date, n);
				gzwrite (f, &nchar, 1);
				gzwrite (f, var, nchar);
				gzwrite (f, &nlong, 4);
				gzwrite (f, val, nlong);
				gzclose (f);
			}
		}
		if (date!=NULL) free (date);
	}
}

char * session_var_get (const char *_var)
{
	char *result = NULL;
	char *date = NULL;
	unsigned char nchar;
	long nlong, n;
	char *var = NULL;
	char *val = NULL;
	if (_var!=NULL && strcmp(session_id,"")!=0)
	{
		char fs[1000];
		char *ip = get_client_ip ();
		sprintf (fs, "%s/sessions/%s-%s.ps_id", DATA_PATH, ip, session_id);
		gzFile f = gzopen (fs, "rb");
		if (f!=NULL)
		{	
			gzread (f, &n, 4);
			if (n>0 && n<2*MAX_POST) 
			{	
				date = (char*)malloc (n);
				if (date) gzread (f, date, n);
					else n=0;
			}
			else n=0;
			gzclose (f);
		}
		int gasit = 0;
		if (n>0 && date!=NULL)
		{
			// cautare
			long pos = 0;
			while (pos<n && !gasit)
			{
				if (pos+1<=n)
				{
					memcpy (&nchar, &date[pos], 1);
				} else nchar=0;
				pos=pos+1;
				if (pos+nchar<=n)
				{
					var = (char*)malloc (nchar+1);
					memcpy (var, &date[pos], nchar);
					var[nchar]='\0';
				}
				pos=pos+nchar;
				if (pos+4<=n)
				{
					memcpy (&nlong, &date[pos], 4);
				} else nlong=0;
				pos=pos+4;
				if (pos+nlong<=n)
				{
					val = (char*)malloc (nlong+1);
					memcpy (val, &date[pos], nlong);
					val[nlong]='\0';
				}
				pos=pos+nlong;
				if (var!=NULL && strcasecmp (_var, var)==0) 
				{
					gasit = 1;
					if (val!=NULL) result = strdup (val);
				}
				if (var!=NULL) free (var);
				if (val!=NULL) free (val);
			}
		}
	}
	return result;
}

void session_var_del (const char *_var)
{
	char *date = NULL;
	unsigned char nchar;
	long nlong, n, n2;
	char *var = NULL;
	char *val = NULL;
	if (_var!=NULL && strcmp(session_id,"")!=0)
	{
		char fs[1000];
		char *ip = get_client_ip ();
		sprintf (fs, "%s/sessions/%s-%s.ps_id", DATA_PATH, ip, session_id);
		gzFile f = gzopen (fs, "rb");
		if (f!=NULL)
		{	
			gzread (f, &n, 4);
			if (n>0 && n<2*MAX_POST) 
			{	
				date = (char*)malloc (n);
				if (date) gzread (f, date, n);
					else n=0;
			}
			else n=0;
			gzclose (f);
		}
		if (n>0 && date!=NULL)
		{
			// cautare
			n2 = n;
			long pos = 0;
			while (pos<n)
			{
				if (pos+1<=n)
				{
					memcpy (&nchar, &date[pos], 1);
				} else nchar=0;
				pos=pos+1;
				if (pos+nchar<=n)
				{
					var = (char*)malloc (nchar+1);
					memcpy (var, &date[pos], nchar);
					var[nchar]='\0';
				}
				pos=pos+nchar;
				if (pos+4<=n)
				{
					memcpy (&nlong, &date[pos], 4);
				} else nlong=0;
				pos=pos+4;
				if (pos+nlong<=n)
				{
					val = (char*)malloc (nlong+1);
					memcpy (val, &date[pos], nlong);
					val[nlong]='\0';
				}
				pos=pos+nlong;
				if (var!=NULL && strcasecmp (_var, var)==0) n2=n2-nchar-1-nlong-4;
				if (var!=NULL) free (var);
				if (val!=NULL) free (val);
			}
			// scriere
			f = gzopen (fs, "wb");
			if (f!=NULL && n2>0)
			{
				gzwrite (f, &n2, 4);
				pos = 0;
				while (pos<n)
				{
					if (pos+1<=n)
					{
						memcpy (&nchar, &date[pos], 1);
					} else nchar=0;
					pos=pos+1;
					if (pos+nchar<=n)
					{
						var = (char*)malloc (nchar+1);
						memcpy (var, &date[pos], nchar);
						var[nchar]='\0';
						//printf ("var: %s\n", var);
					}
					pos=pos+nchar;
					if (pos+4<=n)
					{
						memcpy (&nlong, &date[pos], 4);
					} else nlong=0;
					pos=pos+4;
					if (pos+nlong<=n)
					{
						val = (char*)malloc (nlong+1);
						memcpy (val, &date[pos], nlong);
						val[nlong]='\0';
						//printf ("val: %s\n", val);
					}
					pos=pos+nlong;
					if (var!=NULL && val!=NULL && strcasecmp (_var, var)!=0)
					{
						gzwrite (f, &nchar, 1);
						gzwrite (f, var, nchar);
						gzwrite (f, &nlong, 4);
						gzwrite (f, val, nlong);
					}
					if (var!=NULL) free (var);
					if (val!=NULL) free (val);
				}
				gzclose (f);
			}
			if (date!=NULL) free (date);
		}
	}
}

void session_close ()
{
	char fs[1000];
	char *old_id = getcookie ("PS_ID");
	if (old_id!=NULL) 
	{	
		char *ip = get_client_ip ();
		sprintf (fs, "%s/sessions/%s-%s.ps_id", DATA_PATH, ip, old_id);
		remove (fs);
		setcookie ("PS_ID", "", "");
		free (old_id);
	}
}

char *get_client_ip ()
{
	char *s=getenv("REMOTE_ADDR");
	char *ip=NULL;
	if (s!=NULL)
	{
		if (strlen(s)>255) s[256]='\0';
		ip=strdup (s);
	}
	return ip;
}
