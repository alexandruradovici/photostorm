#include "db.h"
#include "album.h"
#include "misc.h"
#include "quotes.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

int filter_psa (const dirent *namelist)
{
	int r=0;
	char *ext=NULL;
	if (rindex (namelist->d_name, '.')!=NULL) ext=strdup(rindex (namelist->d_name, '.'));
	if (ext!=NULL &&  strcasecmp (ext,".psa")==0) r=1;
	return r;
}

void update_db ()
{
	MYSQL db = get_db ();
	char qs[1000];
	/*sprintf (qs, "DROP TABLE categorii");
	mysql_query (&db, qs);
	sprintf (qs, "CREATE TABLE categorii (cat_id TINYINT DEFAULT '0' NOT NULL AUTO_INCREMENT, nume TINYTEXT, KEY (cat_id))");
	mysql_query (&db, qs);
	sprintf (qs, "DELETE FROM albume");
	mysql_query (&db, qs);*/
	struct dirent **namelist;
	int n = scandir (psw_album_path, &namelist, filter_psa, alphasort); 
	if (n>0)
	{
		while (n--)
			{
				long fsz = 0;
				FILE *f = fopen (album_path_(namelist[n]->d_name), "rb");
				if (f!=NULL)
				{
					fseek (f, 0, SEEK_END);
					fsz = ftell (f);
					fclose (f);
				}
				_ps_album *date_album = ps_load_album_data (album_path_ (namelist[n]->d_name), true);
				//printf ("%s\n", album_path_ (namelist[n]->d_name));
				if (date_album!=NULL)
				{
					if (!category_exists (date_album->categoria))
					{
						sprintf (qs, "INSERT INTO categories (c_name) VALUES (\"%s\")", filter_mysql_code (date_album->categoria));
						mysql_query (&db, qs);
					}
					int cat_id = get_category_id (date_album->categoria);
					if (cat_id>0)
					{
						if (album_exists (namelist[n]->d_name))
							sprintf (qs, "UPDATE albums SET a_name=\"%s\", a_category=\"%d\", a_author=\"%s\", a_description=\"%s\", a_nr_photos=\"%d\", a_size=\"%ld\", WHERE a_file=\"%s\"", filter_mysql_code(date_album->nume), cat_id, filter_mysql_code(date_album->autor), filter_mysql_code(date_album->descriere), date_album->nr_poze, fsz, filter_mysql_code(namelist[n]->d_name));
						else
							sprintf (qs, "INSERT INTO albums SET a_name=\"%s\", a_category=\"%d\", a_author=\"%s\", a_description=\"%s\", a_nr_photos=\"%d\", a_size=\"%ld\", a_file=\"%s\"", filter_mysql_code(date_album->nume), cat_id, filter_mysql_code(date_album->autor), filter_mysql_code(date_album->descriere), date_album->nr_poze, fsz, filter_mysql_code(namelist[n]->d_name));
						//printf ("%s\n", qs);
						mysql_query (&db, qs);
					}
					int album_id = get_album_id (namelist[n]->d_name);
					if (album_id > 0)
					for (int i=1;i<=date_album->nr_poze;i++)
					{
						_ps_photo *date_poza = ps_load_photo_nr_from_album_memory (date_album, i);
						if (date_poza!=NULL)
						{
							if (photo_exists (album_id, i))
								sprintf (qs, "UPDATE photos SET p_name=\"%s\", p_author=\"%s\", p_description=\"%s\", p_size=\"%ld\", WHERE p_album=\"%d\" AND p_photo=\"%d\"", filter_mysql_code(date_poza->nume), filter_mysql_code(date_poza->autor), filter_mysql_code(date_poza->descriere), date_poza->n_poza, album_id, i);
							else
								sprintf (qs, "INSERT INTO photos SET p_name=\"%s\", p_author=\"%s\", p_description=\"%s\", p_size=\"%ld\", p_album=\"%d\", p_photo=\"%d\"", filter_mysql_code(date_poza->nume), filter_mysql_code(date_poza->autor), filter_mysql_code(date_poza->descriere), date_poza->n_poza, album_id, i);
							//printf ("%s\n", qs);
							mysql_query (&db, qs);
							ps_photo_free (date_poza);
						}
					}
				}
				ps_album_free (date_album);
			}
	}
	sprintf (qs, "DELETE FROM quotes");
	mysql_query (&db, qs);
	int i=1;
	_ps_quote *q;
	while ((q=ps_get_quote_nr (psw_quotes_data, i)))
	{
		i++;
		sprintf (qs, "INSERT INTO quotes SET q_author=\"%s\", q_keys=\"%s\", q_quote=\"%s\"", filter_mysql_code(q->author), filter_mysql_code(q->keywords), filter_mysql_code(q->quote));
		mysql_query (&db, qs);
	}
}

int main()
{
	db_init ();
	update_db ();
	db_close ();
	return 0;
}
