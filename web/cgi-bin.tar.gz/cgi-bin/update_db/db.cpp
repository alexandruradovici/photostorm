
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <mysql.h>

#include "db.h"
#include "misc.h"

static MYSQL db;

int db_init ()
{
	if (mysql_init (&db)) 
	{	
		if (mysql_real_connect (&db, "localhost", "root", "", "photostorm", 0, NULL, 0)) return 1;
//		if (mysql_real_connect (&db, "db.sparetimegroup.net", "photostorm", "center", "photostorm", 0, NULL, 0)) return 1;
	}
	else return 0;
}

MYSQL get_db ()
{
	return db;
}

void db_close ()
{
	mysql_close (&db);
}

// ---------------- albumdb.cpp -------------------
_ps_category_list categorii[1000];
_ps_album_list albume[1000];
_ps_wallpaper_list poze[1000];

void edit_album ()
{
	
}

int published (int user_id, const char *album_file, int photo_id)
{
	if (user_id<=0 || !album_file) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	if (photo_id<0) sprintf (qs, "SELECT pub_id FROM publicatii WHERE user_id='%d' AND album_file='%s'", user_id, album_file);
		else sprintf (qs, "SELECT pub_id FROM publicatii WHERE user_id='%d' AND album_file='%s' AND photo_id='%d'", user_id, album_file, photo_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int publish (int user_id, const char *album_file, int photo_id)
{
	if (published (user_id, album_file, photo_id)) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "INSERT INTO publicatii (user_id, album_file, photo_id) VALUES ('%d', '%s', %d)", user_id, album_file, photo_id);
	if (mysql_query (&db, qs)) return 1;
	return 0;
}

int category_exists (const char *cat)
{
	MYSQL db = get_db ();
	if (!cat) return 0;
	char qs[1000];
	sprintf (qs, "SELECT c_name FROM categories WHERE c_name='%s'", cat);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int get_category_id (const char *cat)
{
	MYSQL db = get_db ();
	if (!cat) return 0;
	char qs[1000];
	sprintf (qs, "SELECT c_id FROM categories WHERE c_name=\"%s\";", cat);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = ps_strtoint (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

char * get_category_name (int cat_id)
{
	char *res = NULL;
	if (cat_id<0) return NULL;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT c_name FROM categories WHERE c_id='%d';", cat_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = strdup (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return res;
}

int get_album_id_from_file (const char *albumul)
{
	MYSQL db = get_db ();
	if (!albumul) return 0;
	char qs[1000];
	sprintf (qs, "SELECT a_id FROM albums WHERE a_file='%s';", albumul);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = ps_strtoint (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int get_album_id (const char *albumul)
{
	MYSQL db = get_db ();
	if (!albumul) return 0;
	char qs[1000];
	sprintf (qs, "SELECT a_id FROM albums WHERE a_file='%s';", albumul);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = ps_strtoint (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

char * get_album_name (int album_id)
{
	char *res = NULL;
	if (album_id<0) return NULL;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT a_name FROM albums WHERE a_id='%d';", album_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = strdup (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return res;
}

char * get_album_file (int album_id)
{
	char *res = NULL;
	if (album_id<0) return NULL;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT a_file FROM albums WHERE a_id='%d';", album_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = strdup (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return res;
}

int album_exists (const char *album_file)
{
	MYSQL db = get_db ();
	if (!album_file) return 0;
	char qs[1000];
	sprintf (qs, "SELECT a_name FROM albums WHERE a_file=\"%s\"", album_file);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int photo_exists (int album_id, int photo_id)
{
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT p_name FROM photos WHERE p_album=\"%d\" AND p_photo=\"%d\"", album_id, photo_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

/*int filter_psa (const dirent *namelist)
{
	int r=0;
	char *ext=NULL;
	if (rindex (namelist->d_name, '.')!=NULL) ext=strdup(rindex (namelist->d_name, '.'));
	if (ext!=NULL &&  strcasecmp (ext,".psa")==0) r=1;
	return r;
}*/

int get_categories()
{
	int nr=0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT c_id, c_name FROM categories ORDER BY c_name ASC");
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while (row = mysql_fetch_row (result))
			{
				categorii[nr].cat_id = ps_strtoint (row[0]);
				strcpy (categorii[nr].nume, row[1]);
				nr++;
			}
			mysql_free_result (result);
		}
	}
	return nr;
}

_ps_category_list * get_categories_list ()
{
	return categorii;
}

int get_albums(int cat_id)
{
	int nr=0;
	if (cat_id<=0) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT a_id, a_name, file FROM albums WHERE a_category='%d' ORDER BY name ASC", cat_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while (row = mysql_fetch_row (result))
			{
				albume[nr].album_id = ps_strtoint (row[0]);
				strcpy (albume[nr].nume, row[1]);
				strcpy (albume[nr].file, row[2]);
				nr++;
			}
			mysql_free_result (result);
		}
	}
	return nr;
}

int get_new_albums(int n)
{
	int nr=0;
	if (n<=0) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT a_id, a_name, a_file FROM albums ORDER BY a_date DESC LIMIT 0,%d", n);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while (row = mysql_fetch_row (result))
			{
				albume[nr].album_id = ps_strtoint (row[0]);
				strcpy (albume[nr].nume, row[1]);
				strcpy (albume[nr].file, row[2]);
				nr++;
			}
			mysql_free_result (result);
		}
	}
	return nr;
}

_ps_album_list * get_albums_list ()
{
	return albume;
}

int get_wallpaper_score (int album_id, int photo_id)
{
	int score=-1;
	if (album_id<0 || photo_id<=0) return -1;
	MYSQL db = get_db ();
	char qs[1000];
	int scor_vechi;
	sprintf (qs, "SELECT p_score FROM photos WHERE p_album='%d' AND p_photo='%d'", album_id, photo_id);
	if (mysql_query (&db, qs)) return -1;
	MYSQL_RES *result = mysql_store_result (&db);
	if (result)
	{
		MYSQL_ROW row;
		if (row = mysql_fetch_row (result))
		{
			score = ps_strtoint (row[0]);
		}
		mysql_free_result (result);
	}
	return score;
}


void score_add (int album_id, int photo_id, int score)
{
	if (album_id<0 || photo_id<=0 || score==0) return;
	MYSQL db = get_db ();
	char qs[1000];
	int scor_vechi = get_wallpaper_score (album_id, photo_id);
	if (scor_vechi>-1)
	{
		sprintf (qs, "UPDATE photos SET p_score='%d' WHERE p_album='%d' AND p_photo='%d'", scor_vechi+score, album_id, photo_id);
	}
	if (mysql_query (&db, qs)) return;
}

int get_top_wallpapers(int n)
{
	int nr=0;
	if (n<=0) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT p_album, p_photo FROM photos ORDER BY p_score DESC LIMIT 0,%d", n);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while ((row = mysql_fetch_row (result)) && n>0)
			{
				poze[nr].album_id = ps_strtoint (row[0]);
				poze[nr].photo_id = ps_strtoint (row[1]);
				nr++;
				n--;
			}
			mysql_free_result (result);
		}
	}
	return nr;
}

_ps_wallpaper_list * get_top_wallpapers_list ()
{
	return poze;
}

//---------------------- userdb.cpp --------------

int user_exists (const char *username)
{
	MYSQL db = get_db ();
	if (!username) return 0;
	char qs[100];
	sprintf (qs, "SELECT user_id FROM users WHERE username='%s';", username);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int user_add (_ps_user *user)
{
	MYSQL db = get_db ();
	if (!user) return 0;
	char qs[100000];
	sprintf (qs, "INSERT INTO users (username, password, first_name, last_name, email, birthdate, city, country, ocupation, website, description, space, credits) values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d')",
	user->username, user->password, user->first_name, user->last_name, user->email, user->birthdate, user->city, user->country, user->ocupation, user->website, user->description, user->space, user->credits);
	if (!mysql_query (&db, qs)) return 1;
	return 0;
}

_ps_user * get_user_info (const char *username)
{
	MYSQL db = get_db ();
	if (!username) return NULL;
	_ps_user *user = NULL;
	char qs[1000];
	sprintf (qs, "SELECT user_id, username, password, first_name, last_name, email, birthdate, city, country, ocupation, website, description, space, credits FROM users WHERE username='%s'", username);
	if (mysql_query (&db, qs)) return NULL;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			if (mysql_num_rows (result) != 1) user=NULL;
			else
			{
				MYSQL_ROW row = mysql_fetch_row (result);
				if (row && (user=(_ps_user*)malloc (sizeof(_ps_user))))
				{
					int n;
					user->user_id = ps_strtoint (row [0]);
					// username
					n = strlen (row[1]);
					if (n>USER_MAX_L) n=USER_MAX_L;
					strcpy (user->username, row[1]);
					user->username[n]='\0';
					// password
					n = strlen (row[2]);
					if (n>PASSWORD_MAX_L) n=PASSWORD_MAX_L;
					strcpy (user->password, row[2]);
					user->password[n]='\0';
					// fisrt_name
					n = strlen (row[3]);
					if (n>FNAME_MAX_L) n=FNAME_MAX_L;
					strcpy (user->first_name, row[3]);
					user->first_name[n]='\0';
					// last_name
					n = strlen (row[4]);
					if (n>LNAME_MAX_L) n=LNAME_MAX_L;
					strcpy (user->last_name, row[4]);
					user->last_name[n]='\0';
					// email
					n = strlen (row[5]);
					if (n>EMAIL_MAX_L) n=EMAIL_MAX_L;
					strncpy (user->email, row[5], n);
					user->email[n]='\0';
					// date
					strncpy (user->birthdate, row[6], 11);
					user->birthdate[11]='\0';
					// city
					n = strlen (row[7]);
					if (n>CITY_MAX_L) n=CITY_MAX_L;
					strncpy (user->city, row[7], n);
					user->city[n]='\0';
					// country
					n = strlen (row[8]);
					if (n>COUNTRY_MAX_L) n=COUNTRY_MAX_L;
					strncpy (user->country, row[8], n);
					user->country[n]='\0';
					// occup
					n = strlen (row[9]);
					if (n>OCCUP_MAX_L) n=OCCUP_MAX_L;
					strncpy (user->ocupation, row[9], n);
					user->ocupation[n]='\0';
					// website
					n = strlen (row[10]);
					if (n>WEBSITE_MAX_L) n=WEBSITE_MAX_L;
					strncpy (user->website, row[10], n);
					user->website[n]='\0';
					// description
					n = strlen (row[11]);
					if (n>DESCRIPTION_MAX_L) n=DESCRIPTION_MAX_L;
					strncpy (user->description, row[11], n);
					user->description[n]='\0';
					user->space = ps_strtoint (row[12]);
					user->credits = ps_strtoint (row[13]);
					/*printf ("Content-type: text/html\n\nok");
					printf ("<br>user_id: %s", user->ocupation);
					abort ();*/
				}
			}
			mysql_free_result (result);
			return user;
		}
	}
	return user;
}

// ------------ quotesdb.cpp -------------
int get_quotes_count ()
{
	int nr = 0;
	char qs[1000];
	sprintf (qs, "select count(*) as q_nr from quotes");
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				nr = ps_strtoint (row[0]);
			}
			mysql_free_result (result);
		}
	}
	return nr;
}

_ps_quote * get_quote_nr (int nr)
{
	_ps_quote *q = NULL;
	char qs[1000];
	sprintf (qs, "select q_author, q_quote from quotes where q_id=%d", nr);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				q = ps_quote_create (row[1], row[0], "");
			}
			mysql_free_result (result);
		}
	}
	return q;
}

// ------------ filters ------------

const char * filter_mysql_code (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		int j;
		int n=strlen (s);
		char *buf;
		buf=(char *)malloc (1);
		strcpy (buf,"");
		j=0;
		for (int i=0;i<n;i++)
		{
			char temp[10];
			switch (s[i])
			{
				case '\"': strcpy (temp, "\\\""); break;
				case '\'': strcpy (temp, "\\\'"); break;
				default: sprintf (temp, "%c", s[i]);
			}
			buf = (char*)realloc (buf, strlen (buf)+strlen(temp)+1);
			strcat (buf, temp);
		}
		result=strdup(buf);
		free (buf);
	}
	return result;
}
