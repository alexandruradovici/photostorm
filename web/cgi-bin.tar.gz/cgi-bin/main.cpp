
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "data.h"
#include "cgi_cpp.h"
#include "db.h"
#include "htmls.h"
#include "misc.h"

void page_not_found ()
{
	printf ("The page you have requested was not found.");
}

void run_download ()
{
	
}

void welcome_page ()
{
	int n = get_top_wallpapers (7);
	_ps_wallpaper_list *poze = get_top_wallpapers_list ();
	printf (
// picture of the week
		"<table width=100%% border=0 cellspadding=0 cellspacing=0>"
		"<tr><td>"
        	"<table border=0 cellspacing=\"0\" cellpadding=\"0\" width=\"460\" border=0>"
          	"<tr>"
            	"<td colspan=\"3\"><img height=\"28\" src=\"/images/sus.jpg\" width=\"460\" border=\"0\"></td>"
          	"</tr>"
          	"<tr>"
            	"<td><img height=\"300\" src=\"/images/st.jpg\" width=\"30\" border=\"0\"></td>"
            	"<td><a href=/cgi-bin/artstorm.cgi?page=albums&album_id=%d&photo_id=%d><img src=\"/cgi-bin/get_photo.cgi?album_id=%d&photo_id=%d&x=400&y=300\" border=0 height=300 width=400 alt=\"&quot;Photo of the week&quot;\"></a></td>"
            	"<td><img height=\"300\" src=\"/images/dr.jpg\" width=\"30\" border=\"0\"></td>"
          	"</tr>"
          	"<tr>"
            	"<td colspan=\"3\"><img height=\"11\" src=\"/images/jos.jpg\" width=\"460\" border=\"0\"></td>"
          	"</tr>"
        	"</table>"
      "</td>",
	  poze[0].album_id, poze[0].photo_id, poze[0].album_id, poze[0].photo_id);
	  printf (
// All-time top 6
	  "<td width=260 valign=top align=center>"
	    "<img height=67 src=\"/images/top6.jpg\" width=260 border=0 align=center><br><br>"
		"<table cellspacing=3 cellpadding=0 border=0 align=center>"
		 );
		 for (int top6_nr=1;top6_nr<n;top6_nr++)
		 {
			 if (top6_nr%2==1) printf ("<tr>");
			  printf ("<td>");
			  char link[1000];
			  sprintf (link, "/cgi-bin/artstorm.cgi?page=albums&album_id=%d&photo_id=%d", poze[top6_nr].album_id, poze[top6_nr].photo_id);
			  char alt_text[100];
			  sprintf (alt_text, "Position %d", top6_nr+1);
			  show_very_small_photo (poze[top6_nr].album_id, poze[top6_nr].photo_id, alt_text, link, "");
			  printf ("</td>");
			  if (top6_nr%2==0) printf ("</tr>");
		 }
	  printf ("</table></td></tr>");
	// Quote
	_ps_quote *q = get_quote_nr (ps_random (get_quotes_count())+1);
	if (q!=NULL)
	{
		printf (
		"<tr>"
			"<td colspan=2 align=left>"
	  			"<img src=\"/images/quote.jpg\" border=0><br>"
	  			"<table cellspacing=0 cellpadding=0 width=50%% border=0 class=\"text_normal\" align=left>"
	    		"<tr>"
	      			"<td class=\"quote\"><p align=justify>"
		);
		printf ("%s", q->quote);
		printf (
					"</td></tr>"
					"<tr><td align=right class=\"autor\">"
		);
		printf ("%s", q->author);
		printf ("</td></tr></table>");
		ps_quote_free (q);
	}
	printf ("</td></tr></table>");
}

void photo_page (int album_id, int photo_id)
{
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT p_photo, p_name, p_author, p_description, a_name, a_category, c_id, c_name, a_nr_photos, p_download_photo, p_download_image, p_online_wallpaper, p_displayed FROM photos, albums, categories WHERE p_album=\"%d\" AND a_category=c_id AND p_album=a_id AND p_photo=\"%d\"", album_id, photo_id);
	if (mysql_query (&db, qs)==0)
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				int nr_photos = ps_strtoint (row[8]);
				char links[10000];
				sprintf (links, "<a href=/cgi-bin/get_photo.cgi?page=download_photo&album_id=%d&photo_id=%d><font class=\"large_photo_text\">Download Photo</font></a> | <a href=/cgi-bin/get_photo.cgi?album_id=%d&photo_id=%d&save=yes><font class=\"large_photo_text\">Download Image</font></a> | <a href=%d%d><font class=\"large_photo_text\">Make Wallpaper</font></a>", album_id, photo_id, album_id, photo_id, album_id, photo_id);
				// Location
				printf ("<a href=\"/cgi-bin/artstorm.cgi?page=category&category_id=%d\">%s</a> <b>/</b> <a href=\"/cgi-bin/artstorm.cgi?page=albums&album_id=%d\">%s</a> <b>/</b> <font color=#FFFF00>%s</font>", ps_strtoint (row[6]), filter_html_code (row[7]), album_id, filter_html_code (row[4]), filter_html_code (row[1]));
				// Photos
				printf (
				"<table cellspacing=0 cellpadding=2 width=100%%  class=\"window_white_border\">"
		  		"<th bgcolor=#9c9c9c valign=top align=left><i>&copy; %s</i></th><th bgcolor=#9c9c9c valign=top align=right><i>Photo %d of %d&nbsp;</i></th><tr><td colspan=2><br><br></td></tr>"
				, filter_html_code (row[2]), photo_id, nr_photos);
				printf ("<tr><td colspan=2 align=center><table border=0><tr>");
					if (photo_id>1) printf ("<td valign=middle><a href=/cgi-bin/artstorm.cgi?page=albums&album_id=%d&photo_id=%d>Previous</a></td>", album_id, photo_id-1);
						else printf ("<td valign=middle>Previous</td>");;
					printf ("<td valign=middle>");
					show_large_photo (album_id, photo_id, "", "", links);
					printf ("</td>");
					if (photo_id<nr_photos) printf ("<td valign=middle><a href=/cgi-bin/artstorm.cgi?page=albums&album_id=%d&photo_id=%d>Next</a></td>", album_id, photo_id+1);
						else printf ("<td valign=middle>Next</td>");;
				printf ("</tr></table></td></tr>");
				printf ("</table>");
				if (strcmp (row[3], "")!=0)
				{
					printf (
					"<table cellspacing=0 cellpadding=2 width=100%%  class=\"window_white_border\">"
		  			"<th colspan=4 bgcolor=#9c9c9c valign=top align=left><i>More Information</i></th><tr><td colspan=4><br></td></tr>"
					);
					printf ("<tr><td valign=top align=left width=750>%s</td></tr>", filter_html_code_pre (row[3]));
					printf ("</table>");
				}
				printf (
				"<table cellspacing=0 cellpadding=2 width=100%%  class=\"window_white_border\">"
		  		"<th colspan=4 bgcolor=#9c9c9c valign=top align=left><i>Statistics</i></th><tr><td colspan=4><br></td></tr>"
				);
				long score = 0;
				long pd_photo = ps_strtoint (row[9]);
				long pd_image = ps_strtoint (row[10]);
				long po_wall = ps_strtoint (row[11]);
				long p_disp = ps_strtoint (row[12]);
				score  = 10*pd_photo + 5*pd_image + po_wall;
				printf ("<tr><td valign=top align=left width=750>Score: <i><b>%d</b> points</i><br>Downloaded: <i><b>%d</b> times</i><br>&nbsp;&nbsp;&nbsp;Photo: <i>%d times</i><br>&nbsp;&nbsp;&nbsp;Image: <i>%d times</i><br>Set as online wallpaper: <i><b>%d</b> times</i><br>Displayed: <i><b>%d</b> times</b></td></tr>", score, pd_photo + pd_image, pd_photo, pd_image, po_wall, p_disp);
				printf ("</table>");
			}
			mysql_free_result (result);
			score_add (album_id, photo_id, 0);
		}
	}	
}

void album_page (int album_id)
{
	const char* photo_id = get_query_var ("photo_id");
	if (photo_id!=NULL) 
	{
		photo_page (album_id, ps_strtoint (photo_id));
		return;
	}
	//printf ("<img src=\"/images/album.jpg\" border=0 align=center><br><br>");
	int nr = 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT p_photo, p_name, p_author, a_name, a_author, a_description, a_category, c_name, a_nr_photos FROM photos, albums, categories WHERE p_album=\"%d\" AND a_category=c_id AND p_album=a_id ORDER BY p_photo ASC", album_id);
	if (mysql_query (&db, qs)==0)
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			MYSQL_ROW lastrow;
			while (row = mysql_fetch_row (result))
			{
				if (nr==0)
				{
					// Location
					printf ("<a href=\"/cgi-bin/artstorm.cgi?page=category&category_id=%d\">%s</a> <b>/</b> <font color=#FFFF00>%s</font>", ps_strtoint (row[6]), filter_html_code (row[7]), filter_html_code (row[3]));
					// Photos
					printf (
					"<table cellspacing=0 cellpadding=2 width=100%%  class=\"window_white_border\">"
		  			"<th colspan=2 bgcolor=#9c9c9c valign=top align=left><i>&copy; %s</i></th><th colspan=2 bgcolor=#9c9c9c valign=top align=right><i>%d photos</i></th><tr><td colspan=4 valign=top align=center><a href=get_photo.cgi?page=download_album&album_id=%d><font color=#FFFF00>Download the album</font></a><br><br></td></tr>"
					, filter_html_code (row[4]), ps_strtoint (row[8]), album_id);
				}
				int photo_id = ps_strtoint (row[0]);
				nr++;
				if (nr%4==1) printf ("<tr>");
				char link[1000];
				sprintf (link, "/cgi-bin/artstorm.cgi?page=albums&album_id=%d&photo_id=%d", album_id, photo_id);
				char text[1000];
				sprintf (text, "%s<br><i>&copy; %s</i>", filter_html_code (row[1]), filter_html_code (row[2]));
				printf ("<td width=25%% valign=top align=center>");
				show_small_photo (album_id, photo_id, filter_html_code (row[1]), link, text);
				printf ("</td>");
				if (nr%4==0) printf ("</tr>");
				lastrow = row;
			}
			printf ("</table>");
			if (lastrow!=NULL && strcmp (lastrow[5], "")!=0)
			{
					printf (
					"<table cellspacing=0 cellpadding=2 width=100%%  class=\"window_white_border\">"
		  			"<th colspan=4 bgcolor=#9c9c9c valign=top align=left><i>More Information</i></th><tr><td colspan=4><br></td></tr>"
					);
					printf ("<tr><td valign=top align=left width=750>%s</td></tr>", filter_html_code_pre (lastrow[5]));
					printf ("</table>");
			}		
			printf (
			"<table cellspacing=0 cellpadding=2 width=100%%  class=\"window_white_border\">"
		  	"<th colspan=4 bgcolor=#9c9c9c valign=top align=left><i>Statistics</i></th><tr><td colspan=4><br></td></tr>"
			);
			MYSQL_ROW statsrow = NULL;
			sprintf (qs, "SELECT a_downloaded, sum(p_download_photo) as a_download_photos, sum(p_download_image) as a_download_images, sum(p_online_wallpaper) as a_online_wallpapers, a_displayed, sum(p_displayed) as ap_displayed, a_nr_photos FROM photos, albums WHERE p_album=\"%d\" AND p_album=a_id GROUP BY a_id", album_id);
			if (mysql_query (&db, qs)==0)
			{
				MYSQL_RES *result = mysql_store_result (&db);
				if (result)
				{
					statsrow = mysql_fetch_row (result);
				}
				mysql_free_result (result);
			}
			if (statsrow!=NULL)
			{
					long score = 0;
					long a_downloaded = ps_strtoint (statsrow[0]);
					long ad_photo = ps_strtoint (statsrow[1]);
					long ad_image = ps_strtoint (statsrow[2]);
					long ao_wall = ps_strtoint (statsrow[3]);
					long a_disp = ps_strtoint (statsrow[4]);
					long ap_disp = ps_strtoint (statsrow[5]);
					long nr_photos = ps_strtoint (statsrow[6]);
					ad_photo = ad_photo - (a_downloaded*nr_photos);
					score  = 10*a_downloaded + 5*ad_photo + 2*ad_image;
					printf ("<tr><td valign=top align=left width=750>Score: <i><b>%d</b> points</i><br>Downloaded:<br>&nbsp;&nbsp;&nbsp;Album: <i>%d times</i><br>&nbsp;&nbsp;&nbsp;Photos: <i>%d times</i><br>&nbsp;&nbsp;&nbsp;Images: <i>%d times</i><br>Online Wallpapers Set: <i><b>%d</b> times</i><br>Displayed: <br>&nbsp;&nbsp;&nbsp;Album: <i><b>%d</b> times</b><br>&nbsp;&nbsp;&nbsp;Photos: <i><b>%d</b> times</b></td></tr>", score, a_downloaded, ad_photo, ad_image, ao_wall, a_disp, ap_disp);
					printf ("</table>");
			}
			mysql_free_result (result);
			score_add (album_id, 0);
		}
	}	
}

void albums_page ()
{
	const char* album_id = get_query_var ("album_id");
	if (album_id!=NULL) 
	{
		album_page (ps_strtoint(album_id));
		return;
	}
	//printf ("<img src=\"/images/albums.jpg\" border=0 align=center><br><br>");
	printf ("Newest Albums");
	printf (
		"<table cellspacing=0 cellpadding=2 width=100%%  class=\"window_white_border\">"
		  "<th colspan=4 bgcolor=#9c9c9c valign=top align=left><i>There are some photos here...</i></th><tr><td colspan=4><br><br></td></tr>"
		);
	const int n = 12;
	int nr = 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT a_id, a_name, a_author, a_nr_photos FROM albums ORDER BY a_id DESC LIMIT 0,%d", n);
	if (mysql_query (&db, qs)==0)
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while (row = mysql_fetch_row (result))
			{
				int album_id = ps_strtoint (row[0]);
				nr++;
				if (nr%4==1) printf ("<tr>");
				char link[1000];
				sprintf (link, "/cgi-bin/artstorm.cgi?page=albums&album_id=%d", album_id);
				printf ("<td width=25%% valign=top align=center>");
				write_small_album (album_id, row[1], row[2], ps_strtoint (row[3]), link);
				printf ("</td>");
				if (nr%4==0) printf ("</tr>");
			}
			mysql_free_result (result);
		}
	}	
	printf ("</table>");
}

void category_page ()
{
	int category_id = ps_strtoint (get_query_var ("category_id"));
	//printf ("<img src=\"/images/albums.jpg\" border=0 align=center><br><br>");
	int nr = 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT a_id, a_name, a_author, a_nr_photos, c_name FROM albums, categories WHERE a_category=\"%d\" AND a_category=c_id ORDER BY a_id DESC", category_id);
	if (mysql_query (&db, qs)==0)
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while (row = mysql_fetch_row (result))
			{
				if (nr==0)
				{
					printf ("<font color=#FFFF00>%s</font>", filter_html_code (row[4]));
					printf (
					"<table cellspacing=0 cellpadding=2 width=100%%  class=\"window_white_border\">"
		  			"<th colspan=4 bgcolor=#9c9c9c valign=top align=left><i>Albums</i></th><tr><td colspan=4><br><br></td></tr>"
					);
				}
				int album_id = ps_strtoint (row[0]);
				nr++;
				if (nr%4==1) printf ("<tr>");
				char link[1000];
				sprintf (link, "/cgi-bin/artstorm.cgi?page=albums&album_id=%d", album_id);
				printf ("<td width=25%% valign=top align=center>");
				write_small_album (album_id, row[1], row[2], ps_strtoint (row[3]), link);
				printf ("</td>");
				if (nr%4==0) printf ("</tr>");
			}
			mysql_free_result (result);
		}
	}	
	printf ("</table>");
}

void write_page (char *page)
{
	if (page==NULL) return;
	if (strcmp (page, "")==0) welcome_page ();
	else
	if (strcmp (page, "albums")==0) albums_page ();
	else
	if (strcmp (page, "category")==0) category_page ();
	else
	page_not_found ();
}

void run_html_page (char *page)
{
	content ("text/html");
	printf ("<html>");
		write_header ();
		printf ("<body>");
		printf ("<center>");
			printf ("<table width=1000 cellpadding=0 cellspacing=0>");
			printf ("<tr><td width=750 valign=top align=left>");
			write_page (page);
			printf ("</td>");
			write_vertical_line ();
			printf ("<td valign=top align=center>");
			write_album_categories ();
			write_login ();
			write_download ();
			printf ("</td></tr>");
			write_horizontal_line ();
			printf ("</table>");
			printf ("<br>");
			write_menu_copyright ();
		printf ("</center>");
		printf ("</body>");
	printf ("</html>");
}

int main ()
{
	db_init ();
	srand (time(0));	
	if (!session_init()) session_new();
	getquery ();
	char * page = get_query_var ("page");
	if (page==NULL) page = strdup ("");
	if (strcmp (page, "download")==0) run_download ();
	else run_html_page (page);	
	db_close ();
	free (page);
	return 0;
}
