
#include "cgi_cpp.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

static char query [256];
static char buffer [MAX_POST];

void content (const char *s)
{
	printf ("Content-type: %s\n\n",s);
}

int convert16 (char v)
{
	int result=-1;
	v=toupper (v);
	if (v>=48 && v<=57) result=v-48;
	if (v>=65 && v<=70) result=v-55;
	return result;
}

char * filter_UTF_8 (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		int j;
		int n=strlen (s);
		char *buf;
		buf=(char *)malloc (strlen(s)+1);
		strcpy (buf,"");
		j=0;
		for (int i=0;i<n;i++)
		{
			if (s[i]=='%')
			{
				char v=convert16(s[i+1])*16+convert16(s[i+2]);
				buf[j]=v;
				buf[j+1]='\0';
				j++;
				i=i+2;
			}
			else
			{
				if (s[i]=='+') buf[j]=' ';
				else buf[j]=s[i];
				buf[j+1]='\0';
				j++;
			}
		}
		result=strdup(buf);
		free (buf);
	}
	return result;
}

const char * filter_html_code (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		int j;
		int n=strlen (s);
		char *buf;
		buf=(char *)malloc (1);
		strcpy (buf,"");
		j=0;
		for (int i=0;i<n;i++)
		{
			char temp[10];
			switch (s[i])
			{
				case '<': strcpy (temp, "&lt;"); break;
				case '>': strcpy (temp, "&gt;"); break;
				case ' ': strcpy (temp, "&nbsp;"); break;
				case '&': strcpy (temp, "&amp;"); break; // 
				default: sprintf (temp, "%c", s[i]);
			}
			buf = (char*)realloc (buf, strlen (buf)+strlen(temp)+1);
			strcat (buf, temp);
		}
		result=strdup(buf);
		free (buf);
	}
	return result;
}

int getquery ()
{
    char *s=getenv("QUERY_STRING");
	if (s!=NULL)
	{
		if (strlen(s)>255) s[256]='\0';
		strcpy (query,(char*)s);
	}
	return 0;
}

int getpost ()
{
	long n=-1;
	long i=-1;
	char *s1=getenv ("CONTENT_LENGTH");
	if (s1!=NULL) sscanf (s1,"%u",&n);
	else n=0;
	if (n<MAX_POST) n=MAX_POST;
	strcpy (buffer,"");
	while (!feof (stdin) && i<n)
	{
		i++;
		char c;
		scanf ("%c",&c);
		buffer[i]=c;
	}
	buffer[i]='\0';
	return 0;
}

char * get_query_var (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		char *buf=(char*)malloc (strlen(s)+2);
		strcpy (buf, s);
		int t=strlen(buf);
		buf[t]='=';
		buf[t+1]='\0';
		s=strdup (buf);
		char *s1=strstr (query,s);
		if (s1!=NULL)
		{
			s1=s1+strlen (s);
			if (s1!=NULL)
			{
				char *buf=strdup ("");
				int n=0;
				while (n<strlen (s1) && s1[n]!='&')
				{
					buf = (char*)realloc (buf, strlen (buf)+2);
					buf[n]=s1[n];
					n++;
				}
				buf[n]='\0';
				if (strlen (buf)==0) result = NULL;
				else result = strdup (buf);
			}
		}
	}
	return filter_UTF_8(result);
}

char * get_post_var (const char *s)
{
	char *result=NULL;
	if (s!=NULL)
	{
		char *buf=(char*)malloc (strlen(s)+2);
		strcpy (buf, s);
		int t=strlen(buf);
		buf[t]='=';
		buf[t+1]='\0';
		s=strdup (buf);
		char *s1=strstr (buffer,s);
		if (s1!=NULL)
		{
			s1=s1+strlen (s);
			if (s1!=NULL)
			{
				char *buf=strdup ("");
				int n=0;
				while (n<strlen (s1) && s1[n]!='&')
				{
					buf = (char*)realloc (buf, strlen(buf)+2);
					buf[n]=s1[n];
					n++;
				}
				buf[n]='\0';
				if (strlen (buf)==0) result = NULL;
				else result = strdup (buf);
			}
		}
	}
	return filter_UTF_8(result);
}

int setcookie (const char *nume, const char *date, const char *expira)
{
	if (nume!=NULL && date!=NULL && expira!=NULL) 
	{	
		printf ("Set-Cookie: %s=%s;\n",nume,date); // mai vine adaugata faza cu expirarea
		return 1;
	}
	else return 0;
}

char * getcookie (const char *s)
{
	char *s1=getenv ("HTTP_COOKIE");
	char *result=NULL;
	if (s1!=NULL && s!=NULL)
	{
		char *s2=(char*)malloc (strlen(s)+2);
		strcpy (s2,s);
		strcat (s2,"=");
		s=strdup (s2);
		free (s2);
		s1=strstr (s1,s);
		if (s1!=NULL)
		{
			s1=s1+strlen (s);
			if (s1!=NULL)
			{
				char *buf=strdup("");
				int n=0;
				while (n<strlen (s1) && s1[n]!=';')
				{
					buf = (char*)realloc (buf, strlen(buf)+2);
					buf[n]=s1[n];
					n++;
				}
				buf[n]='\0';
				if (strlen (buf)==0) result = NULL;
				else result = strdup (buf);
			}
		}
	}
	return filter_UTF_8 (result);
}

char *get_client_ip ()
{
	char *s=getenv("REMOTE_ADDR");
	char *ip=NULL;
	if (s!=NULL)
	{
		if (strlen(s)>255) s[256]='\0';
		ip=strdup (s);
	}
	return ip;
}
