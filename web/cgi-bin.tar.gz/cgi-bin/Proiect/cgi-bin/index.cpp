
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <crypt.h>
#include "cgi_cpp.h"
#include "functii.h"

int main()
{
	int eroare=0;
	getpost ();
	char *user= get_post_var("user");
	char *password = get_post_var ("pass");
	char *fname = get_post_var("fnam");
	char *lname = get_post_var("lnam");
	char *email = get_post_var ("email");
	char *date = get_post_var("date");
	char *occup = get_post_var("occ");
	char *npoze = get_post_var("nopic");
	char *name = NULL;
	char *domain = NULL;
	char *d=NULL;
	char *m=NULL;
	char *y=NULL;
	int nrpoze=0;
	if (email!=NULL && password !=NULL && fname!=NULL && lname!=NULL && user!=NULL && date!=NULL && occup!=NULL)
	{
		name = strtok (email, "@");
		domain = strtok (NULL, "\0");
		if (name==NULL || domain==NULL) eroare=1;
	d=strtok(date, "/");
	m=strtok(NULL, "/");
	y=strtok(NULL, "\0");
	if (d==NULL || m==NULL || y==NULL) 
	eroare=3;
	if (strlen(password)<4)
	eroare=4;
	if (strcmp(user, password)==0 || strcmp(fname, password)==0 || strcmp(lname, password)==0)
	eroare=5;
	sscanf(npoze, "%d", &nrpoze);
	if(nrpoze<3)
	eroare=6;
	}
	else eroare = 2;
	content ("text/html");
	printf ("<html>");
	if (eroare==2) printf("Error, one of the fields is not completed");
	if (eroare==1) printf ("Error, the email address is incorect<br>");
	if (eroare==3) printf("Error, the date is incorect");
	if (eroare==4) printf("Error, the password must have at least 4 characters");
	if (eroare==5) printf("Error, the password must be different from one of your names");	
	if (eroare==6) printf("Error, the nr of pictures must be above 3 in order to apply");
	if (eroare==0) printf ("Username: %s<br>Password: %s<br>FirstName: %s<br> LastName %s<br> Name(email): %s<br> Provider: %s<br> Birth Date: %s/%s/%s <br>Occupation: %s<br> Credits: 30<br> Space(MB): 2<br> No. of Photos %s ", user, password , fname, lname, name, domain, d, m, y, occup, npoze);
	char s[100];
	sprintf (s, "../date/users/%s.psu", user);
	if (eroare==0)
	{
	FILE *f;
	f = fopen (s, "wa");
		fprintf(f, " Username: %s \n Password: %s \n FirstName: %s \n LastName %s \n Name(email): %s \n Provider: %s \n Birth Date: %s/%s/%s \n Occupation: %s \n Credits: 30 \n Space(MB): 2 \n No. of Photos %s ", user, password , fname, lname, name, domain, d, m, y, occup, npoze);
	fclose (f);
	}
	printf ("</html>");
}
