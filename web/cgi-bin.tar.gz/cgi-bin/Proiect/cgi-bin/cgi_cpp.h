
#ifndef _CGI_CPP__H
#define _CGI_CPP__H

#define CGI_CPP

// dimensiunea maxima adminsa pentru POST (x*1024 = x KB)
const int MAX_POST = 100*1024;

// tipareste "Content-type"
void content (const char *s);

// functii de filtrare
char * filter_UTF_8 (const char *s);
const char * filter_html_code (const char *s);

// functii de preluarea a datelor de la server
// ATENTIE! Se apeleaza o singura data
int getquery ();
int getpost ();

// functii pentru preloarea valorii variabilelor
char * get_query_var (const char *s);
char * get_post_var (const char *s);

// cookies (prajiturele)
int setcookie (const char *nume, const char *date, const char *expira);
char * getcookie (const char *s);

// informatii despre client
char *get_client_ip ();

#endif
