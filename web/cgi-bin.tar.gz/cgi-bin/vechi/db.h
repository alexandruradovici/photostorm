
#ifndef _DB__H
#define _DB__H

#include <mysql.h>

int db_init ();
MYSQL get_db ();
void db_close ();

#endif
