
#include <stdio.h>
#include <mysql.h>

static MYSQL db;

int db_init ()
{
	if (mysql_init (&db)) 
	{	
//		if (mysql_real_connect (&db, "localhost", "root", "", "photostorm", 0, NULL, 0)) return 1;
		if (mysql_real_connect (&db, "db.sparetimegroup.net", "photostorm", "center", "photostorm", 0, NULL, 0)) return 1;
	}
	else return 0;
}

MYSQL get_db ()
{
	return db;
}

void db_close ()
{
	mysql_close (&db);
}
