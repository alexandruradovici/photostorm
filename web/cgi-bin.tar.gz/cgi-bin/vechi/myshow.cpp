
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <dirent.h>
#include "data.h"
#include "cgi_cpp.h"
#include "htmls.h"
#include "album.h"
#include "photo.h"
#include "misc.h"

const int FOUND_MAX = 27;

static char psw_user_album_path[10000];
static char *login_name;

const char * user_album_path (const char *album)
{
    char s[1000];
    strcpy (s,"");
    if (album!=NULL) sprintf (s, "%s/%s.psa", psw_user_album_path, album);
    return strdup (s);
}

const char * user_album_path_ (const char *album)
{
    char s[1000];
    strcpy (s,"");
    if (album!=NULL) sprintf (s, "%s/%s", psw_user_album_path, album);
    return strdup (s);
}

void search_page (const char *keywords, const char *all_keywords, const char *s_name,
				  const char *s_author, const char *s_description)
{
	printf (
		"<table width=100%% border=0 cellspacing=0 cellpadding=0 class=\"afis_tabel4\">"
		"<form action=\"/cgi-bin/show.cgi\" method=GET>"
		"<th colspan=2 bgcolor=#9c9c9c>Search Photos</th><tr><td colspan=2><br></dt></tr>"
		"<tr valign=top>"
			"<td width=100%% valign=top colspan=2>"
			"<center>Keywords <input type=text name=\"search\" class=\"campuri2\" value=\"%s\"><input type=image src=\"/images/go.jpg\" border=0 align=center width=35><center>"
			"</td>"
		"</tr>"
		"<th colspan=2 bgcolor=#9c9c9c>Advanced Search</th><tr><td colspan=2><br></dt></tr>"
		"<tr>"
			"<td align=left valign=middle><input type=checkbox name=\"all_keywords\" %s>Find only photos matching all the keywords</input></td>"
			"<td align=left valign=middle><input type=checkbox name=\"s_name\" %s>Search names</input></td>"
		"</tr>"
		"<tr>"
			"<td align=left valign=middle><input type=checkbox name=\"s_author\" %s>Search author's names</input></td>"
			"<td align=left valign=middle><input type=checkbox name=\"s_description\" %s>Search descriptions</input></td>"
		"</tr>"
		"</form>"
		"</table>"
	,(keywords!=NULL)?filter_html_code(keywords):"", (all_keywords!=NULL && strcasecmp (all_keywords, "on")==0)?"checked":""
	,(s_name!=NULL && strcasecmp (s_name, "on")==0)?"checked":"", (s_author!=NULL && strcasecmp (s_author, "on")==0)?"checked":""
	,(s_description!=NULL && strcasecmp (s_description, "on")==0)?"checked":"");
}

int filter_psa (const dirent *namelist)
{
	int r=0;
	char *ext=NULL;
	if (rindex (namelist->d_name, '.')!=NULL) ext=strdup(rindex (namelist->d_name, '.'));
	if (ext!=NULL &&  strcasecmp (ext,".psa")==0) r=1;
	return r;
}

void photo_index (const char *keywords, int skips, const char *all_keywords, char *s_name,
				  const char *s_author, const char *s_description)
{
	if ((s_name==NULL || (s_name!=NULL && strcasecmp (s_name, "on")!=0)) &&
		(s_author==NULL || (s_author!=NULL && strcasecmp (s_author, "on")!=0)) &&
		(s_description==NULL || (s_description!=NULL && strcasecmp (s_description, "on")!=0)))
		s_name = strdup ("on");
	int wallpapers=0;
	if (keywords==NULL) 
	{	
		wallpapers=1;
		keywords = strdup ("");
	}
	printf (
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/wallpapers.jpg\" border=0 align=center><br><br>"
	);
	search_page (keywords, all_keywords, s_name, s_author, s_description);
	printf ("<br><br>");
	printf (
	"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
	"<th colspan=4 bgcolor=#9c9c9c>Searching \"%s\"</th><tr><td colspan=4><br></dt></tr>"
	, filter_html_code(keywords));
	struct dirent **namelist;
	int n = scandir (psw_user_album_path, &namelist, filter_psa, alphasort); 
	int found=0;
	int albums = 0;
	if (n>0)
	{
		while (n-- && found<FOUND_MAX)
			{
				_ps_album *date_album = ps_load_album (user_album_path_ (namelist[n]->d_name));
				if (date_album!=NULL)
				{
				  albums++;
				  if (albums>skips)
				  {
					char albumul[1000];
					strncpy (albumul, namelist[n]->d_name, strlen (namelist[n]->d_name)-4);
					albumul [strlen (namelist[n]->d_name)-4]='\0';
					for (int i=0;i<date_album->nr_poze;i++)
					{
						_ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, i+1, 0);
						if (date_poza!=NULL)
						{
							if (search_keywords ((char*)keywords, date_album->nume) ||
								search_keywords ((char*)keywords, date_album->categoria) ||
								search_keywords ((char*)keywords, date_album->descriere) ||
								search_keywords ((char*)keywords, date_poza->nume) ||
								search_keywords ((char*)keywords, date_poza->autor) ||
								search_keywords ((char*)keywords, date_poza->descriere));
							int gasit = wallpapers;
							if (all_keywords!=NULL && strcasecmp(all_keywords, "on")==0)
							{
								if (!gasit)
									if (s_name!=NULL && strcasecmp (s_name, "on")==0) 
									gasit = search_keywords_ ((char*)keywords, date_album->nume) ||
									  	    search_keywords_ ((char*)keywords, date_poza->nume);
								if (!gasit)
									if (s_author!=NULL && strcasecmp (s_author, "on")==0) 
									gasit = search_keywords_ ((char*)keywords, date_album->autor) ||
									  	    search_keywords_ ((char*)keywords, date_poza->autor);
								if (!gasit)
									if (s_description!=NULL && strcasecmp (s_description, "on")==0) 
									gasit = search_keywords_ ((char*)keywords, date_album->descriere) ||
									  	    search_keywords_ ((char*)keywords, date_poza->descriere);
							}
							else
							{
								if (!gasit)
									if (s_name!=NULL && strcasecmp (s_name, "on")==0) 
									gasit = search_keywords ((char*)keywords, date_album->nume) ||
									  	    search_keywords ((char*)keywords, date_poza->nume);
								if (!gasit)
									if (s_author!=NULL && strcasecmp (s_author, "on")==0) 
									gasit = search_keywords ((char*)keywords, date_album->autor) ||
									  	    search_keywords ((char*)keywords, date_poza->autor);
								if (!gasit)
									if (s_description!=NULL && strcasecmp (s_description, "on")==0) 
									gasit = search_keywords ((char*)keywords, date_album->descriere) ||
									  	    search_keywords ((char*)keywords, date_poza->descriere);
							}
							if (gasit)
							{
								found++;
								if (found%4==1) printf ("<tr>");
									char text_poza[1000];
								sprintf (text_poza, "%s<br><i>(C) %s</i>",
			 					 		(date_poza->nume!=NULL)?date_poza->nume:"", 
			 							(date_poza->autor!=NULL)?date_poza->autor:"");
								printf (
								"<td width=25%% align=center valign=top>"
     							"<table cellspacing=0 cellpadding=0 width=110 border=0>"
     							"<tr>"
      								"<td><a href=\"/cgi-bin/show.cgi?album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?album_name=%s&photo_id=%d&x=100&y=75\" border=0 height=75 width=100></a></td>"
      								"<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     							"</tr>"
     							"<tr>"
      								"<td colspan=3><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     							"</tr>"
     							"<tr>"
      								"<td colspan=3><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     							"</tr>"
	 							"</table>"
	 							"</td>"
								, albumul, i+1, albumul, i+1, text_poza);
								if (found%4==0) printf ("</tr>");
							}
							ps_photo_free (date_poza);
						}
					}
					ps_album_free (date_album);
				}
			}
		}
		if (found%4!=0) printf ("</tr>");
	}
	if (found>0) printf ("<th colspan=4 bgcolor=#9c9c9c align=right><a href=\"/cgi-bin/show.cgi?search=%s&skips=%d\">Search More</a></th>"
				 , filter_html_code (code_UTF_8(keywords)), albums);
	if (found==0) printf ("<tr><td class=\"afis_tabel4\">Sorry, but there was no photo found matching your keywords</td></tr>");
	printf ("</table>");
	printf ("<br><br>");
}

void download_image (const char *album_name, const char *photo_id)
{
	_ps_album *date_album = ps_load_album (user_album_path (album_name));
	int id = ps_strtoint (photo_id);
	if (date_album!=NULL)
	{
		_ps_photo *date_poza = ps_load_photo_nr_from_album_memory (date_album, id);
		if (date_poza!=NULL)
		{
			content ("image/jpeg");
			fwrite (date_poza->date, date_poza->n_poza, 1, stdout);
			ps_photo_free (date_poza);
		}
		ps_album_free (date_album);
	}
}

void download_photo (const char *album_name, const char *photo_id)
{
	_ps_album *dwl = NULL;
	_ps_album *date_album = ps_load_album (user_album_path (album_name));
	int id = ps_strtoint (photo_id);
	if (date_album!=NULL)
	{
		_ps_photo *date_poza = ps_load_photo_nr_from_album_memory (date_album, id);
		if (date_poza!=NULL)
		{
			dwl = ps_create_new_album_in_memory (date_album->nume, date_album->autor,
												 date_album->categoria, date_album->descriere,
												 "$import", "");
			if (dwl!=NULL)
			{
				ps_add_photo_to_album_from_memory_into_memory (date_poza, dwl);
				content ("photo_album/psp");
				long n;
				char *date = NULL;
				date = ps_pack_album (dwl, n);
				fwrite (date, n, 1, stdout);
				if (date!=NULL) free (date);
				ps_album_free (dwl);
			}
			ps_photo_free (date_poza);
		}
		ps_album_free (date_album);
	}
}

void download_album (const char *album_name)
{
	_ps_album *date_album = ps_load_album (user_album_path (album_name));
	if (date_album!=NULL)
	{
		content ("photo_album/psa");
		long n;
		char *date = NULL;
		date = ps_pack_album (date_album, n);
		fwrite (date, n, 1, stdout);
		if (date!=NULL) free (date);
		ps_album_free (date_album);
	}
}

void show_photo (const char *album_name, const char *photo_id)
{
	printf (
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/wallpaper.jpg\" border=0 align=center><br><br>"
	);
	int id = ps_strtoint (photo_id);
	_ps_album *date_album = ps_load_album (user_album_path (album_name));
	if (date_album!=NULL)
	{
		_ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, id, 0);
		if (date_poza!=NULL)
		{
			printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		  "<th colspan=4 bgcolor=#9c9c9c>Photo Information</th>"
     	  "<tr>"
			"<td width=100%% align=center valign=middle>"
			"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
     		"<tr>"
      		"<td colspan=2 width=50%% align=center>"
		      "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      		    "<tr><td align=center>%s</td></tr>"
			    "<tr><td align=center>Album <a href=\"/cgi-bin/myshow.cgi?album_name=%s\">%s</a></td></tr>"
      	      "</table>"
      		"</td>"
      		"<td colspan=2 width=50%% align=center>"
	          "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      			"<tr><td align=center>(C) %s</td></tr>"
      			"<tr><td align=center>Size %d KB</td></tr>"
      		  "</table>"
      "</td>"
     "</tr>"
     "<th colspan=4 bgcolor=#9c9c9c>Photo Preview</th>"
     "<tr>"
     "<td colspan=4><br></td>"
     "</tr>"
     "<tr>"
	 "<td colspan=4 valign=middle align=center>"
	 ,filter_html_code (date_poza->nume), album_name, filter_html_code (date_album->nume), filter_html_code (date_poza->autor), date_poza->n_poza / 1024);
			printf (
			"<table cellspacing=0 cellpadding=5 width=400 border=0 class=\"afis_poza\">"
     		"<tr>"
      			"<td><table border=0 cellspacing=0 cellpadding=0 class=\"afis_poza\"><tr><td><a href=\"/cgi-bin/myshow.cgi?download=1&album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?myalbum_name=%s&photo_id=%d&x=400&y=300\" border=0 height=300 width=400></a></td></tr></table></td>"
     		"</tr>"
     		"<tr>"
      			"<td width=310 height=10> </td>"
     		"</tr>"
     		"<tr>"
      			"<td><center><a href=\"/cgi-bin/myshow.cgi?download=1&album_name=%s&photo_id=%d\"><font class=\"text_poza\">Download Photo</font></a> | <a href=\"/cgi-bin/myshow.cgi?download=2&album_name=%s&photo_id=%d\" target=_blank><font class=\"text_poza\">Download Image</font></a></center></td>"
     		"</tr>"
	 		"</table><br>"
			, filter_html_code(album_name), id, filter_html_code(album_name), id, filter_html_code (album_name), id, filter_html_code(album_name), id);
			printf (
    "</td>"
	"</tr>"
	"</table>"
	);
			ps_photo_free (date_poza);
		}
		ps_album_free (date_album);
	}
	printf (
    "</td>"
	"</tr>"
	"</table>"
	 );
	
}

void show_album (const char *album_id)
{
	printf (
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/myalbum.jpg\" border=0 align=center><br><br>"
	);
	_ps_album *date_album = ps_load_album (user_album_path (album_id));
	if (date_album!=NULL)
	{
		char data_album [1000];
		tm *info_data_album = localtime (&date_album->data);
		strftime (data_album, sizeof (data_album), "%A, %B %d, %G", info_data_album);
		printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		"<form action=/cgi-bin/myshow.cgi?page=save_album method=POST><input type=hidden name=\"myalbum_name\" value=\"%s\">"
		  "<th colspan=4 bgcolor=#9c9c9c>Album Information</th>"
     	  "<tr>"
			"<td width=100%% align=center valign=middle>"
			"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
     		"<tr>"
      		"<td colspan=2 width=50%% align=center>"
		      "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      		    "<tr><td align=center>Name: <input name=\"nume\" value=\"%s\" maxlength=255 class=\"campuri3\" size=20 ></td></tr>"
			    "<tr><td align=center>Created on %s</td></tr>"
      	      "</table>"
      		"</td>"
      		"<td colspan=2 width=50%% align=center>"
	          "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      			"<tr><td align=center>Author: <input name=\"autor\" value=\"%s\" maxlength=255 class=\"campuri3\" size=20 ></td></tr>"
      			"<tr><td align=center>Size %d KB</td></tr>"
      		  "</table>"
      "</td>"
     "</tr>"
     "<th colspan=4 bgcolor=#9c9c9c>Photos contained in the album</th>"
     "<tr>"
     "<td colspan=4><br></td>"
     "</tr>"
     "<tr>"
	 , filter_html_code (album_id), filter_html_code (date_album->nume), data_album, filter_html_code (date_album->autor), date_album->n_poze / 1024);
	 int i=0;
	 for (i=1;i<=date_album->nr_poze;i++)
	 {
		 char text_poza[1000];
		 sprintf (text_poza, "");
		 _ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, i, 0);
		 if (date_poza!=NULL)
		 {
			 sprintf (text_poza, "%s<br><i>(C) %s</i>",
			 (date_poza->nume!=NULL)?date_poza->nume:"", 
			 (date_poza->autor!=NULL)?date_poza->autor:"");
			 ps_photo_free (date_poza);
		 }
		 if (i%4==1) printf ("<tr>");
		 printf (
     "<td width=25%% align=center valign=top>"
     "<table cellspacing=0 cellpadding=0 width=110 border=0>"
     "<tr>"
      "<td><a href=\"/cgi-bin/myshow.cgi?album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?myalbum_name=%s&photo_id=%d&x=100&y=75\" border=0 height=75 width=100></a></td>"
      "<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     "</tr>"
     "<tr>"
      "<td colspan=4><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     "</tr>"
     "<tr>"
      "<td colspan=4><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     "</tr>"
	 "</table>"
	 "</td>"
	, album_id, i, album_id, i, text_poza); 
		 if (i%4==0) printf ("</tr>");
	 }
	 	if (i%4!=0) printf ("</tr>");
		printf ("</table>");
		printf (
    	"</td>"
		"</tr>"
		"<th colspan=4 bgcolor=#9c9c9c>Description</th>"
		"<tr><td colspan=4 valign=top align=center><textarea name=\"descriere\" cols=90 rows=10 class=\"campuri3\">%s</textarea></td></tr>"
		"<tr><td colspan=4 valign=top align=left><input type=image src=/images/save.jpg></td></tr>"
		"<th colspan=4 bgcolor=#9c9c9c><a href=\"/cgi-bin/show.cgi?download=1&album_name=%s\">Download the album</a></th>"
		"<tr><td colspan=4><br></td></tr>"
		"</form>"
		"</table>"
		, (date_album->descriere)?date_album->descriere:"", filter_html_code (album_id));
		ps_album_free (date_album);
	}
}

void save_album ()
{
	getpost ();
	char *myalbum_name = get_post_var ("myalbum_name");
	char *nume = get_post_var ("nume");
	char *autor = get_post_var ("autor");
	char *descriere = get_post_var ("descriere");
	_ps_album *date_album = ps_load_album_data (user_album_path (myalbum_name), 0);
	ps_modify_album_from_file (user_album_path (myalbum_name), nume, autor, date_album->categoria, descriere, "");
	show_album (myalbum_name);
}

void table_categorie (const char* categorie)
{
	FILE *f = fopen (categories_path_ (categorie), "r");
	char *cat = NULL;
	if (f!=NULL) cat = readline (f);
	if (f!=NULL && cat!=NULL)
	{
		printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		  "<th colspan=4 bgcolor=#9c9c9c>%s</th><tr><td colspan=4><br><br></td></tr>"
     	  "<tr>"
			/*"<td width=100%% align=center valign=middle>"
			"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
     		"<tr>"
      		"<td colspan=2 width=50%% align=center>"
		      "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      		    "<tr><td align=center>%s</td></tr>"
			    "<tr><td align=center>Created on %s</td></tr>"
      	      "</table>"
      		"</td>"
      		"<td colspan=2 width=50%% align=center>"
	          "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      			"<tr><td align=center>(C) %s</td></tr>"
      			"<tr><td align=center>Size %d KB</td></tr>"
      		  "</table>"
      "</td>"
     "</tr>"*/
		, cat);
		char *albumul = NULL;
		_ps_album *date_album = NULL;
		int i=1;
		while (!feof(f))
		{
			albumul = readline (f);
			date_album = ps_load_album_data (user_album_path (albumul), 0);
			if (date_album!=NULL)
			{
				char text_album[1000];
		 		sprintf (text_album, "%s<br><i>(C) %s</i><br>%d photos", date_album->nume, date_album->autor, date_album->nr_poze);
		 		if (i%4==1) printf ("<tr>");
				printf (
					"<td width=25%% align=center valign=top>"
     				"<table cellspacing=0 cellpadding=0 width=110 border=0>"
     				"<tr>"
      					"<td><a href=\"/cgi-bin/show.cgi?album_name=%s\"><img src=\"/cgi-bin/get_photo.cgi?album_name=%s&photo_id=0&x=100&y=75\" border=0 height=75 width=100></a></td>"
      					"<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     				"</tr>"
     				"<tr>"
      					"<td colspan=3><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     				"</tr>"
     				"<tr>"
      					"<td colspan=3><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     				"</tr>"
	 				"</table>"
	 				"</td>"
				, albumul, albumul, text_album);
				if (i%4==0) printf ("</tr>");
				ps_album_free (date_album);
				i++;
			}
		}
		if (i%4!=0) printf ("</tr>");
		printf ("</table><br>");
	}
}

void show_categorie (const char *categorie)
{
	printf (
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/albums.jpg\" border=0 align=center><br><br>"
	);
	table_categorie (categorie);
	printf (
    	"</td>"
	);
}

int filter_ps_cat (const dirent *namelist)
{
	int r=0;
	char *ext=NULL;
	if (rindex (namelist->d_name, '.')!=NULL) ext=strdup(rindex (namelist->d_name, '.'));
	if (ext!=NULL &&  strcasecmp (ext,".ps_cat")==0) r=1;
	return r;
}

void show_albums ()
{
	printf (
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/myalbums2.jpg\" border=0 align=center><br><br>"
	"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
	"<th colspan=4 bgcolor=#9c9c9c>%s's albums</th><tr><td colspan=4><br><br></td></tr>"
	, session_var_get ("login_name"));
	struct dirent **namelist;
	int n;
	int i=0;
 	n = scandir (psw_user_album_path, &namelist, filter_psa, alphasort);
    if (n>0)
	while(n--) 
	{
		char albumul[1000];
		int t = strlen (namelist[n]->d_name)-4;
		strncpy (albumul, namelist[n]->d_name, t);
		albumul[t]='\0';
		_ps_album *date_album = NULL;
		date_album = ps_load_album_data (user_album_path_(namelist[n]->d_name), 0);
		if (date_album!=NULL)
		{
			i++;
			char text_album[1000];
			sprintf (text_album, "%s<br><i>(C) %s</i><br>%d photos", date_album->nume, date_album->autor, date_album->nr_poze);
			if (i%4==1) printf ("<tr>");
			printf (
				"<td width=25%% align=center valign=top>"
     			"<table cellspacing=0 cellpadding=0 width=110 border=0>"
     			"<tr>"
      				"<td><a href=\"/cgi-bin/myshow.cgi?album_name=%s\"><img src=\"/cgi-bin/get_photo.cgi?myalbum_name=%s&photo_id=0&x=100&y=75\" border=0 height=75 width=100></a></td>"
      				"<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     			"</tr>"
     			"<tr>"
      				"<td colspan=3><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     			"</tr>"
     				"<tr>"
      				"<td colspan=3><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     			"</tr>"
	 			"</table>"
	 			"</td>"
			, albumul, albumul, text_album);
			if (i%4==0) printf ("</tr>");
			ps_album_free (date_album);
		}
		 free (namelist[n]);
    }
	free (namelist);
	printf ("</table><br>");
	printf (
    	"</td>"
	);
}

int main()
{
	if (!session_init()) session_new();
	login_name = session_var_get ("login_name");
	if (login_name!=NULL) sprintf (psw_user_album_path, "%s/%s/albums", psw_users_path, login_name);
		else exit (0);
	getquery ();
	const char *download = get_query_var ("download");
	const char *album_name = get_query_var ("album_name");
	const char *photo_id = get_query_var ("photo_id");
	const char *categorie = get_query_var ("categorie");
	const char *search = get_query_var ("search");
	const char *all_keywords = get_query_var ("all_keywords");
	char *s_name = get_query_var ("s_name");
	const char *s_author = get_query_var ("s_author");
	const char *s_description = get_query_var ("s_description");
	const char *page = get_query_var ("page");
	int skips = ps_strtoint (get_query_var ("skips"));
	if (download!=NULL)
	{
		if (strcmp (download, "1")==0)
			if (photo_id!=NULL) download_photo (album_name, photo_id);
			else download_album (album_name);
		if (strcmp (download, "2")==0)
			if (photo_id!=NULL) download_image (album_name, photo_id);
	}
	content ("text/html");
	printf ("<html>");
// head
	printf ("<head>");
	style ("/css/ps_style.css");
	printf ("</head>");
	main_display_init ();
	
	if (album_name!=NULL && photo_id!=NULL)
	{
		show_photo (album_name, photo_id);
	}
	else
	if (album_name!=NULL) show_album (album_name);
	else
	if (categorie!=NULL) show_categorie (categorie);
	else
	if (search!=NULL) 
	{
		//int fl = 0;
		photo_index (search, skips, all_keywords, s_name, s_author, s_description);
	}
	else
	if (page!=NULL && strcmp (page, "search")==0) 
	{
		printf (
		"<td width=720 align=center valign=top>"
		"<img src=\"/images/search.jpg\" border=0 align=center><br><br>"
		);
		search_page (search, all_keywords, s_name, s_author, s_description);
		printf (
    	"</td>"
		);		
	}
	else
	if (page!=NULL && strcmp (page, "wallpapers")==0)
	{
		photo_index (NULL, 0, NULL, NULL, NULL, NULL);
	}
	else
	if (page!=NULL && strcmp (page, "save_album")==0)
	{
		save_album ();
	}
	else show_albums ();
	
	write_vertical_line ();
	write_right_start ();
	write_login ();
	write_download ();
	write_right_end ();
	main_display_deinit ();
	main_display_close ();
	return 0;
}
