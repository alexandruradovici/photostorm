
#include <stdio.h>
#include <stdlib.h>
#include "cgi_cpp.h"

int main ()
{
	content ("text/plain");
	use_upload ();
	getpost ();
	long n;
	char *fis_data = get_upload_data ("poza_1", "image/jpeg", n);
	if (fis_data && n>0)
	{
		FILE *f = fopen ("test_file.ulp", "wb");
		if (f!=NULL)
		{
			fwrite (fis_data, n, 1, f);
			fclose (f);
		}
	}
	printf ("Uploaded\n");
	return 0;
}
