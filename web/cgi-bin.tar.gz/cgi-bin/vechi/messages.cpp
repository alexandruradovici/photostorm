
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <zlib.h>
#include "data.h"
#include "cgi_cpp.h"
#include "htmls.h"
#include "album.h"
#include "photo.h"
#include "misc.h"
#include "db.h"
#include "userdb.h"

const int MSG_NR_MAX=1000;
static const char *login_name;

void login_page ()
{
	printf (
	"<center>"
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/createnewa.jpg\" border=0 align=center><br><br>"
	"<form action=\"/cgi-bin/users.cgi?action=login\" method=\"POST\">"
	"<table cellspacing=0 cellpadding=0 width=300 class=\"afis_tabel4\">"
    "<th colspan=3 bgcolor=#9c9c9c>There was an error while trying to login. Please try again.</th>"
    "<tr>"
     "<td colspan=2><br></td>"
     "</tr>"
	 "<tr height=25>"
      "<td width=30%% align=left>Username</td>"
      "<td width=70%% align=left><input type=text name=\"username\" class=\"campuri3\" value=\"\" size=15 maxlength=20></td>"
     "</tr>"
	 "<tr height=25>"
      "<td width=30%% align=left>Password</td>"
      "<td width=70%% align=left><input type=password name=\"password\" class=\"campuri3\" value=\"\" size=15 maxlength=30></td>"
     "</tr>"
	 "<tr height=25>"
      "<td colspan=2 align=right><input type=image src=\"/images/signin.jpg\"></td>"
     "</tr>"
	"</table>"
	"</form>"
	"</center>"
	"</td>"
	);
}

int filter_ps_msg (const dirent *namelist)
{
	int r=0;
	char *ext=NULL;
	if (rindex (namelist->d_name, '.')!=NULL) ext=strdup(rindex (namelist->d_name, '.'));
	if (ext!=NULL &&  strcasecmp (ext,".ps_msg")==0) r=1;
	return r;
}

char *messages_path (const char *msg)
{
	char t[10000];
	strcpy (t,"");
	if (msg!=NULL) sprintf (t, "%s/%s/messages/%s.ps_msg", psw_users_path, session_var_get ("login_name"), msg);
	return strdup (t);
}

char *messages_to_path (const char *user, const char *msg)
{
	char t[10000];
	strcpy (t,"");
	if (msg!=NULL) sprintf (t, "%s/%s/messages/%s.ps_msg", psw_users_path, user, msg);
	return strdup (t);
}

char *messages_path_ (const char *msg)
{
	char t[10000];
	strcpy (t,"");
	if (msg!=NULL) sprintf (t, "%s/%s/messages/%s", psw_users_path, session_var_get ("login_name"), msg);
	return strdup (t);
}

void display (const char *message)
{
	printf (
	"<center>"
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/message.jpg\" border=0 align=center><br><br>"
	"<table cellspacing=0 cellpadding=0 width=100%% class=\"afis_tabel4\">"
	);
	if (message!=NULL)
	{
		FILE *f = fopen (messages_path (message), "r");
		if (f!=NULL)
		{
			readline (f);
			const char *from = filter_html_code (readline (f));
			const char *from_id = filter_html_code(readline (f));
			const char *subject = filter_html_code (readline (f));
			time_t data = ps_strtoint (readline (f));
			tm *info_data = localtime (&data);
			char data_text[1000];
			strftime (data_text, sizeof(data_text), "%A, %B %d, %G", info_data);
			printf (
			"<tr><th colspan=2 align=left bgcolor=#9c9c9c><b>From</b>: <a href=/cgi-bin/users.cgi?profiles=%s>%s</a></th></tr>"
			"<tr><th colspan=2 align=left bgcolor=#9c9c9c><b>Date</b>: %s</th><tr>"
			"<tr><th colspan=2 align=left bgcolor=#9c9c9c><b>Subject</b>: %s</th></tr>"
			"<tr><td colspan=2><br></td></tr>"
			"<tr><td colspan=2 valign=top align=left>"
			, from_id, from, data_text, subject);
			while (!feof(f))
			{
				char *msg_txt = readline (f);
				if (msg_txt!=NULL) 
				{	
					printf (filter_html_code (msg_txt));
					printf ("<br>");
					free (msg_txt);
				}
			}
			printf ("</td></tr>");
			fclose (f);
			printf ("<tr><td colspan=2 valign=top align=left><a href=/cgi-bin/messages.cgi?action=compose&to=%s&subject=Re:+%s><img src=/images/reply.jpg border=0></a></td><tr>",
					 from_id, subject);
		}
		f = fopen (messages_path (message), "r+");
		if (f!=NULL)
		{
			fwrite ("0", 1, 1, f);
			fclose (f);
		}
	}
	printf ("</table></td>");
}

int send_message (const char *to_user, const char *from, const char *from_id, const char *subject, const char *message)
{
	int r=0;
	time_t data;
	time (&data);
	if (to_user!=NULL && from!=NULL && from_id!=NULL)
	{
		long nr = (int)(999999999.0*rand()/RAND_MAX+1);
		char msg_id[1000];
		sprintf (msg_id, "%ld_%ld",data, nr);
		FILE *f = fopen (messages_to_path (to_user, msg_id), "w");
		if (f!=NULL)
		{
			fprintf (f, "1\n");
			fprintf (f, "%s\n", from);
			fprintf (f, "%s\n", from_id);
			fprintf (f, "%s\n", subject?subject:"(no subject)");
			fprintf (f, "%u\n", data);
			fprintf (f, "%s", message?message:" ");
			fclose (f);
			r=1;
		}
	}
	return r;
}

void send ()
{
	getpost ();
	const char *to = get_post_var ("to");
	const char *subject = get_post_var ("subject");
	const char *msg_text = get_post_var ("msg_text");
	_ps_user *user = get_user_info (login_name);
	if (user==NULL) 
	{	
		printf (
		"<center>"
		"<td width=720 align=center valign=top>"
		"Error"
		"</td>"
		);
		return;
	}
	char from[1000];
	sprintf (from, "%s %s", user->first_name, user->last_name);
	free (user);
	srand (time(0));
	printf (
	"<center>"
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/inbox.jpg\" border=0 align=center><br><br>"
	"<table cellspacing=0 cellpadding=0 width=100%% class=\"afis_tabel4\">"
	"<th colspan=2 align=center bgcolor=#9c9c9c>Sending Report</th>"
	"<tr><td colspan=2><br></td></tr>"
	);
	char *to_user = strtok (strdup(to), " ;,");
	while (to_user!=NULL)
	{
		if (send_message (to_user, from, login_name, subject, msg_text))
			printf ("<tr><td align=left valign=top><b>%s</b></td><td valign=top align=left>Message successfuly sent</td>", to_user);
		else
			printf ("<tr><td align=left valign=top>%s</td><td valign=top align=left>There was an error while sending the message.</td>", to_user);
		to_user = strtok (NULL, " ;,");
	}
	printf (
	"</table>"
	);
}

void compose (const char *to_user, const char *subject_)
{
	printf (
	"<center>"
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/inbox.jpg\" border=0 align=center><br><br>"
	"<table cellspacing=0 cellpadding=0 width=100%% class=\"afis_tabel4\">"
	"<form action=/cgi-bin/messages.cgi?action=send method=POST>"
	"<th colspan=2 align=center bgcolor=#9c9c9c>Compose</th>"
	"<tr><td colspan=2><br></td></tr>"
	"<tr height=25><td algin=left>To: </td><td><input type=text name=\"to\" value=\"%s\" class=\"campuri2\" maxlength=255></td></tr>"
	"<tr height=25><td algin=left>Subject: </td><td><input type=text name=\"subject\" value=\"%s\" class=\"campuri2\" maxlength=255></td></tr>"
	"<th colspan=2 align=center bgcolor=#9c9c9c>Message</th>"
	"<tr><td></td><td align=left><textarea name=\"msg_text\" rows=10 cols=20 class=\"campuri2\"></textarea></td></tr>"
	"<tr><td colspan=2 valign=top align=left><input type=image src=/images/send.jpg></td></tr>"
	"</form>"
	"</table>"
	, (to_user!=NULL)?filter_html_code(to_user):"", (subject_!=NULL)?filter_html_code(subject_):"");
}

void inbox (int skip_)
{
	if (skip_<0) skip_=0;
	printf (
	"<center>"
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/inbox.jpg\" border=0 align=center><br><br>"
	"<table cellspacing=0 cellpadding=0 width=100%% class=\"afis_tabel4\">"
	"<form action=/cgi-bin/messages.cgi?action=delete method=POST>"
		"<tr>"
			"<td colspan=4 align=left><a href=/cgi-bin/messages.cgi?action=compose><img border=0 src=/images/compose.jpg></a>"
			"&nbsp;&nbsp;"
			"<input type=image src=/images/delete.jpg></td>"
		"</tr>"
    "<th bgcolor=#9c9c9c>&nbsp;</th><th bgcolor=#9c9c9c>From</th><th bgcolor=#9c9c9c>Subject</th><th bgcolor=#9c9c9c>Date</th>"
	);
	struct dirent **namelist;
	int n = scandir (messages_path_(""), &namelist, filter_ps_msg, alphasort); 
	int skip=MSG_NR_MAX*skip_;
	int msg=0;
	int count=0;
	if (n>0)
	{
		while (n-- && count<MSG_NR_MAX)
		{
			msg++;
			if (msg>skip)
			{
				count++;
				FILE *f = fopen (messages_path_ (namelist[n]->d_name), "r");
				if (f!=NULL)
				{
					int msg_new = ps_strtoint (readline (f));
					const char *from = filter_html_code (readline (f));
					const char *from_id = readline (f);
					const char *subject = filter_html_code (readline (f));
					if (from!=NULL && from_id!=NULL && subject!=NULL)
					{
						time_t data = ps_strtoint (readline (f));
						tm *info_data = localtime (&data);
						char data_text[1000];
						strftime (data_text, sizeof(data_text), "%A, %B %d, %G", info_data);
						char msg_id[1000];
						int t=strlen (namelist[n]->d_name)-7;
						strncpy (msg_id, namelist[n]->d_name, t);
						msg_id[t]='\0';
						printf (
						"<tr class=\"%s\">"
							"<td align=center valign=middle><input type=checkbox name=\"m%s\"></td>"
							"<td align=left valign=middle><a href=/cgi-bin/users.cgi?profile=%s>%s</a></td>"
							"<td align=left valign=middle><a href=/cgi-bin/messages.cgi?action=display&message=%s>%s</a></td>"
							"<td width=180 align=left valign=middle>%s</td>"
						"</tr>"
						, (msg_new)?"afis_tabel5":"afis_tabel4"
						, filter_html_code (msg_id), filter_html_code (from_id), from
						, filter_html_code (msg_id), subject
						, filter_html_code (data_text));
					}
					fclose (f);
				}
			}
		}
	}
	if (count==0) printf ("<tr><td colspan=4 align=center>You have no messages</td></tr>");
	printf ("</form></table>");
	printf ("<br><br>");
}

void del_msg ()
{
	getpost ();
	struct dirent **namelist;
	int n = scandir (messages_path_(""), &namelist, filter_ps_msg, alphasort); 
	if (n>0)
	{
		while (n--)
		{
			char msg_id[1000];
			int t=strlen (namelist[n]->d_name)-7;
			strncpy (msg_id, namelist[n]->d_name, t);
			msg_id[t]='\0';
			char msg[1000];
			sprintf (msg, "m%s", msg_id);
			const char *m = get_post_var (msg);
			if (m!=NULL && strcasecmp (m, "on")==0) remove (messages_path_ (namelist[n]->d_name));
			free (namelist[n]);
		}
	}
	inbox (0);
}

int main()
{
	db_init ();
	if (!session_init()) session_new();
	getquery ();
	
	const char *action = get_query_var ("action");
	
	content ("text/html");
	printf ("<html>");
// head
	printf ("<head>");
	style ("/css/ps_style.css");
	printf ("</head>");
	main_display_init ();
	
	login_name = session_var_get ("login_name");
	
	if (login_name==NULL)
	{
		login_page ();
	}
	else
	{
		if (action!=NULL)
		{
			if (strcmp (action, "compose")==0) compose (get_query_var("to"), get_query_var("subject"));
			if (strcmp (action, "send")==0) send ();
			if (strcmp (action, "display")==0) display (get_query_var ("message"));
			if (strcmp (action, "delete")==0) del_msg ();
		}
		else inbox (0);
	}
	
	/*{
		printf (
		"<td width=720 align=center valign=top>"
		"<img src=\"/images/search.jpg\" border=0 align=center><br><br>"
		);
		search_page (search, all_keywords, s_name, s_author, s_description);
		printf (
    	"</td>"
		);		
	}
	else
	if (page!=NULL && strcmp (page, "wallpapers")==0)
	{
		photo_index (NULL, 0, NULL, NULL, NULL, NULL);
	}
	else show_albums ();*/
	
	write_vertical_line ();
	write_right_start ();
	write_album_categories ();
	write_login ();
	write_download ();
	write_right_end ();
	main_display_deinit ();
	main_display_close ();
	db_close ();
	return 0;
}
