
#include <stdio.h>
#include "cgi_cpp.h"

int create_topic (const char *topic)
{
	if (topic!=NULL)
	{
		
	}
	return 0;
}

int main()
{
	getpost ();
	getquery ();
	session_new ();
	content ("text/plain");
	session_var_set ("name", "numele");
	session_var_set ("email", "email@mail.com");
	session_var_set ("name", "numele acesta");
	printf ("nume: %s\n", session_var_get ("name"));
	printf ("email: %s\n", session_var_get ("email"));
	printf ("<html>msgstorm</html>");
	//char *psuid = getcookie ("PSU_ID");
	return 0;
}
