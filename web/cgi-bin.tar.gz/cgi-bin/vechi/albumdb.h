
#ifndef _ALBUMDB__H
#define _ALBUMDB__H

struct _ps_category_list
{
	int  cat_id;
	char nume[256];
};

struct _ps_album_list
{
	int  album_id;
	char nume[256];
	char file[1000];
};

struct _ps_wallpaper_list
{
	char album_file [1000];
	int photo_id;
};

int published (int user_id, const char *album_file, int photo_id);
int publish (int user_id, const char *album_file, int photo_id);
int category_exists (const char *cat);
int get_category_id (const char *cat);
char * get_category_name (int cat_id);
int get_album_id (const char *albumul);
int get_album_id_from_file (const char *albumul);
char * get_album_name (int album_id);
char * get_album_file (int album_id);
int album_exists (const char *album, int cat_id);
int get_categories();
_ps_category_list * get_categories_list ();
int get_albums(int cat_id);
int get_new_albums(int n);
_ps_album_list * get_albums_list ();
int get_wallpaper_score (const char *album_name, int photo_id);
void score_add (const char *album_name, int photo_id, int score);
int get_top_wallpapers(int n);
_ps_wallpaper_list * get_top_wallpapers_list ();

#endif
