#include "db.h"
#include "album.h"
#include "misc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

int filter_psa (const dirent *namelist)
{
	int r=0;
	char *ext=NULL;
	if (rindex (namelist->d_name, '.')!=NULL) ext=strdup(rindex (namelist->d_name, '.'));
	if (ext!=NULL &&  strcasecmp (ext,".psa")==0) r=1;
	return r;
}

int category_exists (const char *cat)
{
	MYSQL db = get_db ();
	if (!cat) return 0;
	char qs[100];
	sprintf (qs, "SELECT nume FROM categorii WHERE nume='%s'", cat);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int get_category_id (const char *cat)
{
	MYSQL db = get_db ();
	if (!cat) return 0;
	char qs[100];
	sprintf (qs, "SELECT cat_id FROM categorii WHERE nume='%s';", cat);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			MYSQL_ROW row;
			if ((row = mysql_fetch_row (result)))
			{
				res = ps_strtoint (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int album_exists (const char *album, int cat_id)
{
	MYSQL db = get_db ();
	if (!album || cat_id<=0) return 0;
	char qs[100];
	sprintf (qs, "SELECT name FROM albume WHERE name='%s' AND category='%d'", album, cat_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

void update_db ()
{
	MYSQL db = get_db ();
	char qs[1000];
	/*sprintf (qs, "DROP TABLE categorii");
	mysql_query (&db, qs);
	sprintf (qs, "CREATE TABLE categorii (cat_id TINYINT DEFAULT '0' NOT NULL AUTO_INCREMENT, nume TINYTEXT, KEY (cat_id))");
	mysql_query (&db, qs);
	sprintf (qs, "DELETE FROM albume");
	mysql_query (&db, qs);*/
	struct dirent **namelist;
	int n = scandir (psw_album_path, &namelist, filter_psa, alphasort); 
	if (n>0)
	{
		while (n--)
			{
				_ps_album *date_album = ps_load_album_data (album_path_ (namelist[n]->d_name), 0);
				if (date_album!=NULL)
				{
					if (!category_exists (date_album->categoria))
					{
						sprintf (qs, "INSERT INTO categorii (nume) VALUES ('%s')", date_album->categoria);
						mysql_query (&db, qs);
					}
					int cat_id = get_category_id (date_album->categoria);
					if (cat_id>0)
					{
						if (album_exists (date_album->nume, get_category_id (date_album->categoria)))
							sprintf (qs, "UPDATE albume SET name='%s' category='%d' file='%s'", date_album->nume, cat_id, namelist[n]->d_name);
						else
							sprintf (qs, "INSERT INTO albume (name, category, file) VALUES ('%s', '%d', '%s')", date_album->nume, cat_id, namelist[n]->d_name);
						mysql_query (&db, qs);
					}
				}
			}
	}
}

int main()
{
	db_init ();
	update_db ();
	db_close ();
	return 0;
}
