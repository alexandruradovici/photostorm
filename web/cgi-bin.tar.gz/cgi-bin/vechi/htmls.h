
#ifndef _HTMS__H
#define _HTMS__H

void write_login ();
void write_download ();
void write_album_categories();
void write_right_start();
void write_right_end();
void write_menu_copyright ();
void main_display_init ();
void main_display_deinit ();
void write_vertical_line ();
void write_horizontal_line ();
void main_display_close ();
#endif
