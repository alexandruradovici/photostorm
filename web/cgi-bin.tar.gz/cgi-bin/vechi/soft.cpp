
#include <stdio.h>
#include <stdlib.h>
#include "data.h"
#include "cgi_cpp.h"
#include "htmls.h"
#include <time.h>

int main()
{
	return 0;
}
