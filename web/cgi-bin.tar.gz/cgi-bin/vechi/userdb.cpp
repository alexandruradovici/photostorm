
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql.h>
#include "db.h"
#include "userdb.h"
#include "misc.h"

int user_exists (const char *username)
{
	MYSQL db = get_db ();
	if (!username) return 0;
	char qs[100];
	sprintf (qs, "SELECT user_id FROM users WHERE username='%s';", username);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int user_add (_ps_user *user)
{
	MYSQL db = get_db ();
	if (!user) return 0;
	char qs[100000];
	sprintf (qs, "INSERT INTO users (username, password, first_name, last_name, email, birthdate, city, country, ocupation, website, description, space, credits) values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d')",
	user->username, user->password, user->first_name, user->last_name, user->email, user->birthdate, user->city, user->country, user->ocupation, user->website, user->description, user->space, user->credits);
	if (!mysql_query (&db, qs)) return 1;
	return 0;
}

_ps_user * get_user_info (const char *username)
{
	MYSQL db = get_db ();
	if (!username) return NULL;
	_ps_user *user = NULL;
	char qs[1000];
	sprintf (qs, "SELECT user_id, username, password, first_name, last_name, email, birthdate, city, country, ocupation, website, description, space, credits FROM users WHERE username='%s'", username);
	if (mysql_query (&db, qs)) return NULL;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			if (mysql_num_rows (result) != 1) user=NULL;
			else
			{
				MYSQL_ROW row = mysql_fetch_row (result);
				if (row && (user=(_ps_user*)malloc (sizeof(_ps_user))))
				{
					int n;
					user->user_id = ps_strtoint (row [0]);
					// username
					n = strlen (row[1]);
					if (n>USER_MAX_L) n=USER_MAX_L;
					strcpy (user->username, row[1]);
					user->username[n]='\0';
					// password
					n = strlen (row[2]);
					if (n>PASSWORD_MAX_L) n=PASSWORD_MAX_L;
					strcpy (user->password, row[2]);
					user->password[n]='\0';
					// fisrt_name
					n = strlen (row[3]);
					if (n>FNAME_MAX_L) n=FNAME_MAX_L;
					strcpy (user->first_name, row[3]);
					user->first_name[n]='\0';
					// last_name
					n = strlen (row[4]);
					if (n>LNAME_MAX_L) n=LNAME_MAX_L;
					strcpy (user->last_name, row[4]);
					user->last_name[n]='\0';
					// email
					n = strlen (row[5]);
					if (n>EMAIL_MAX_L) n=EMAIL_MAX_L;
					strncpy (user->email, row[5], n);
					user->email[n]='\0';
					// date
					strncpy (user->birthdate, row[6], 11);
					user->birthdate[11]='\0';
					// city
					n = strlen (row[7]);
					if (n>CITY_MAX_L) n=CITY_MAX_L;
					strncpy (user->city, row[7], n);
					user->city[n]='\0';
					// country
					n = strlen (row[8]);
					if (n>COUNTRY_MAX_L) n=COUNTRY_MAX_L;
					strncpy (user->country, row[8], n);
					user->country[n]='\0';
					// occup
					n = strlen (row[9]);
					if (n>OCCUP_MAX_L) n=OCCUP_MAX_L;
					strncpy (user->ocupation, row[9], n);
					user->ocupation[n]='\0';
					// website
					n = strlen (row[10]);
					if (n>WEBSITE_MAX_L) n=WEBSITE_MAX_L;
					strncpy (user->website, row[10], n);
					user->website[n]='\0';
					// description
					n = strlen (row[11]);
					if (n>DESCRIPTION_MAX_L) n=DESCRIPTION_MAX_L;
					strncpy (user->description, row[11], n);
					user->description[n]='\0';
					user->space = ps_strtoint (row[12]);
					user->credits = ps_strtoint (row[13]);
					/*printf ("Content-type: text/html\n\nok");
					printf ("<br>user_id: %s", user->ocupation);
					abort ();*/
				}
			}
			mysql_free_result (result);
			return user;
		}
	}
	return user;
}
