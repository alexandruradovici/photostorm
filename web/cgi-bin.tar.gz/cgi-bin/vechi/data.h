/**************************************************************
*		File: data.h                                           *
*		ID: PS_data_h                                          *
*		Author: Alexandru Radovici                             *
*		Date: February 5, 2004                                 *
*		Modified: February 6, 2004                             *
*		This file is copyrighted to Alexandru Radovici         *
*		and complies to the terms of PSLA v0.1                 *
*                                                             *
*		Comment: This file is the main configuration header.   *
**************************************************************/

#ifndef _DATA__H
#define _DATA__H

#define LINUX
#define PHOTOSTORM_PROGRAM
#define PHOTOSTORM_WEBSITE

#define psw_album_path "../date/albums"
#define psw_categories_path "../date/albums/categories"
#define psw_photo_index "../date/albums/photos.psi"
#define psw_fonts_path "../date/fonts"
#define psw_users_path "../date/users"
#define psw_quotes_data "../date/quotes/quotes.psq"
#define psw_config_default "../date/wallpaper/default.cfg"
#define psw_htmls_path "../date/html"

#define __(str) str

#endif
