
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "data.h"
#include "cgi_cpp.h"
#include "quotes.h"
#include "misc.h"
#include "htmls.h"
#include "db.h"
#include "albumdb.h"
#include <time.h>

int main()
{
	db_init ();
	if (!session_init()) session_new();
	int world=0;
// get quotes
	srand (time(0));
	_ps_quote *q =  ps_get_quote (psw_quotes_data, "", true);
	content ("text/html");
	printf ("<html>");
// head
	printf ("<head>");
	style ("/css/ps_style.css");
	printf ("</head>");
	main_display_init ();
	
	getquery ();
	
	const char * page = get_query_var ("page");

	printf ("<td width=460 valign=top align=center><br>");
	
if (page==NULL)
{
	int n = get_top_wallpapers (6);
	_ps_wallpaper_list *poze = get_top_wallpapers_list ();
	printf (
// picture of the week
		"<table border=0 cellspadding=0 cellspacing=0>"
		"<tr><td>"
        "<table cellspacing=\"0\" cellpadding=\"0\" width=\"460\" border=0>"
          "<tr>"
            "<td colspan=\"3\"><img height=\"28\" src=\"/images/sus.jpg\" width=\"460\" border=\"0\"></td>"
          "</tr>"
          "<tr>"
            "<td><img height=\"300\" src=\"/images/st.jpg\" width=\"30\" border=\"0\"></td>"
            "<td><a href=/cgi-bin/show.cgi?album_name=%s&photo_id=%d><img src=\"/cgi-bin/get_photo.cgi?album_name=%s&photo_id=%d&x=400&y=300\" border=0 height=300 width=400 alt=\"&quot;Photo of the week&quot;\"></a></td>"
            "<td><img height=\"300\" src=\"/images/dr.jpg\" width=\"30\" border=\"0\"></td>"
          "</tr>"
          "<tr>"
            "<td colspan=\"3\"><img height=\"11\" src=\"/images/jos.jpg\" width=\"460\" border=\"0\"></td>"
          "</tr>"
        "</table>"
      "</td>",
	  filter_html_code(poze[0].album_file), poze[0].photo_id, filter_html_code(poze[0].album_file), poze[0].photo_id);
	  printf (
// All-time top 6
	  "<td width=260 valign=top align=center>"
	    "<img height=\"67\" src=\"/images/top6.jpg\" width=\"260\" border=\"0\" align=center><br><br>"
		"<table cellspacing=\"3\" cellpadding=\"0\" width=\"230\" border=0 align=center>"
		 );
		 for (int top6_nr=0;top6_nr<n;top6_nr++)
		 {
			 if (top6_nr%2==0) printf ("<tr>");
			  printf (
			   "<td>"
				"<table cellspacing=\"0\" cellpadding=\"0\" width=\"110\" border=0>"
     				"<tr>"
      					"<td><a href=/cgi-bin/show.cgi?album_name=%s&photo_id=%d><img src=\"/cgi-bin/get_photo.cgi?album_name=%s&photo_id=%d&x=75&y=100\" border=0 height=75 width=100 alt=\"Position %d\"></a></td>"
      					"<td><img height=\"75\" src=\"/images/dr_m.jpg\" width=\"10\" border=\"0\"></td>"
     				"</tr>"
     				"<tr>"
      					"<td colspan=\"2\"><img height=\"10\" src=\"/images/jos_m.jpg\" width=\"110\" border=\"0\"></td>"
				    "</tr>"
    			"</table>"
			  "</td>",
			  filter_html_code(poze[top6_nr].album_file), poze[top6_nr].photo_id, filter_html_code(poze[top6_nr].album_file), poze[top6_nr].photo_id, top6_nr+1);
			  if (top6_nr%2==1) printf ("</tr>");
		 }
	  printf (
	  "</table></td></tr>");
	printf (
	"<tr>"
	"<td colspan=2 align=left>"
	  "<img src=\"/images/quote.jpg\" border=0><br>"
	  "<table cellspacing=0 cellpadding=0 width=50%% border=0 class=\"text_normal\" align=left>"
	    "<tr>"
	      "<td class=\"quote\"><p align=justify>"
	);
		if (q!=NULL && q->quote!=NULL) printf ("%s", q->quote);
		printf (
		"</td></tr>"
		"<tr><td align=right class=\"autor\">"
		);
	if (q!=NULL && q->author!=NULL) printf ("%s", q->author);
		printf ("</td></tr></table>");
	printf ("</td></tr></table>");
}
else
if (strcmp (page, "soft")==0)
{
	show_html ("software");
}
else
if (strcmp (page, "about")==0)
{
	show_html ("about");
}
else
if (strcmp (page, "world")==0)
{
	show_html ("worldwide");
	world=1;
}

	printf ("</td>");		

	if (!world)
	{
		write_vertical_line ();
		write_right_start ();
		write_album_categories ();
		write_login ();
		write_download ();
		write_right_end ();
	}
	main_display_deinit ();
	main_display_close ();
	//"</center> "
  //"</tr></td></table>");
	//printf ("</body>");
	//printf ("</html>");
	db_close ();
	return 0;
}
