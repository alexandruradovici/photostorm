
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <crypt.h>
#include "cgi_cpp.h"
#include "functii.h"

#define USER_MAX_L 20
#define PASSWORD_MIN_L 4
#define PASSWORD_MAX_L 30
#define FNAME_MAX_L 40
#define LNAME_MAX_L 40
#define EMAIL_MAX_L 255
#define OCCUP_MAX_L 41
#define DESCRIPTION_MAX_L 32000
#define INIT_USER_CREDITS 30
#define INIT_USER_SPACE 2 //MB

struct _ps_user
{
	char user[USER_MAX_L+1];
	char password[PASSWORD_MAX_L+1];
	char fname[FNAME_MAX_L+1];
	char lname[LNAME_MAX_L+1];
	char email[EMAIL_MAX_L+1];
	char date[11];
	char occup[OCCUP_MAX_L+1];
	int credits;
	int space;
	int albums;
	int photos;
};

int pagina = 0;

_ps_user * ps_create_user (const char *user, const char *password, const char *fname,
						   const char *lname, const char *email, const char *date,
						   const char *occup)
{
	_ps_user *result = (_ps_user*)malloc (sizeof (_ps_user));
	if (result)
	{
		// username
		if (user!=NULL) 
		{
			strncpy (result->user, user, USER_MAX_L);
			result->user[USER_MAX_L]='\0';
		} else strcpy (result->user, "");
		// password
		if (password!=NULL && strlen(password) > PASSWORD_MIN_L) 
		{
			strncpy (result->password, password, PASSWORD_MAX_L);
			result->password[PASSWORD_MAX_L]='\0';
		} else strcpy (result->password, "");
		// email
		if (email!=NULL) 
		{
			char *name = strtok ((char*)email, "@");
			char *domain = strtok (NULL, "\0");
			if (name==NULL || domain==NULL) strcpy (result->email, "");
			else
			{
				strncpy (result->email, email, EMAIL_MAX_L);
				result->email[EMAIL_MAX_L]='\0';
			}
			if (name!=NULL) free (name);
			if (domain!=NULL) free (domain);
		} else strcpy (result->email, "");
		// fname
		if (fname!=NULL) 
		{
			strncpy (result->fname, fname, FNAME_MAX_L);
			result->fname[FNAME_MAX_L]='\0';
		} else strcpy (result->fname, "");
		// lname
		if (lname!=NULL) 
		{
			strncpy (result->lname, lname, LNAME_MAX_L);
			result->lname[LNAME_MAX_L]='\0';
		} else strcpy (result->lname, "");
		// occup
		if (occup!=NULL) 
		{
			strncpy (result->occup, occup, OCCUP_MAX_L);
			result->occup[OCCUP_MAX_L]='\0';
		} else strcpy (result->occup, "");
		// date
		if (date!=NULL) 
		{
			strcpy (result->date, "10/10/1988");
			//sscanf (date, "%d/%d/%d")
		} else strcpy (result->date, "");
		result->credits = INIT_USER_CREDITS;
		result->space = INIT_USER_SPACE;
		result->albums = 0;
		result->photos = 0;
	} else return NULL;
}

/*
	-1 - eroare
	0 - login + sign-up
	1 - pagina user
*/
char *action = NULL;

int useradd(_ps_user *user)
{
	/*int eroare=0;
	char *user= get_post_var("user");
	char *password = get_post_var ("pass");
	char *fname = get_post_var("fnam");
	char *lname = get_post_var("lnam");
	char *email = get_post_var ("email");
	char *date = get_post_var("date");
	char *occup = get_post_var("occ");
	char *name = NULL;
	char *domain = NULL;
	char *d=NULL;
	char *m=NULL;
	char *y=NULL;
	int nrpoze=0;
	if (email!=NULL && password !=NULL && fname!=NULL && lname!=NULL && user!=NULL && date!=NULL && occup!=NULL)
	{
		name = strtok (email, "@");
		domain = strtok (NULL, "\0");
		if (name==NULL || domain==NULL) eroare=1;
		d=strtok(date, "/");
		m=strtok(NULL, "/");
		y=strtok(NULL, "\0");
		if (d==NULL || m==NULL || y==NULL) eroare=3;
		if (strlen(password)<4) eroare=4;
		if (strcasecmp(user, password)==0 || strcasecmp(fname, password)==0 || strcasecmp(lname, password)==0) eroare=5;
	}
	else eroare = 2;
	//content ("text/html");
	//printf ("<html>");
	/*if (eroare==2) printf("Error, one of the fields is not completed");
	if (eroare==1) printf ("Error, the email address is incorect<br>");
	if (eroare==3) printf("Error, the date is incorect");
	if (eroare==4) printf("Error, the password must have at least 4 characters");
	if (eroare==5) printf("Error, the password must be different from one of your names");	
	if (eroare==6) printf("Error, the nr of pictures must be above 3 in order to apply");
	if (eroare==0) printf ("Username: %s<br>Password: %s<br>FirstName: %s<br> LastName %s<br> Name(email): %s<br> Provider: %s<br> Birth Date: %s/%s/%s <br>Occupation: %s<br> Credits: 30<br> Space(MB): 2<br> No. of Photos %s ", user, password , fname, lname, name, domain, d, m, y, occup, npoze);*/
	char s[100];
	sprintf (s, "../date/users/%s.psu", user->user);
	if (eroare==0)
	{
		FILE *f;
		f = fopen (s, "w");
		if (f!=NULL)
		{
			fprintf(f, "%s\n%s\n%s\n%s%s\n%s/%s/%s\n%s\n30\n2 ", user, password , fname, lname, email, d, m, y, occup);
			fclose (f);
		}
		else eroare = 7;
	}
	return eroare;
}

int main ()
{
	getquery ();
	action = get_query_var ("action");
	if (action!=NULL)
	{
		getpost ();
		if (strcmp(action, "useradd")==0)
		{
			pagina = useradd ();
		}
	}
	content ("text/html");
}
