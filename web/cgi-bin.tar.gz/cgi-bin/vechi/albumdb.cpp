
#include <unistd.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql.h>
#include "albumdb.h"
//#include "album.h"
#include "misc.h"
#include "db.h"

_ps_category_list categorii[1000];
_ps_album_list albume[1000];
_ps_wallpaper_list poze[1000];

void edit_album ()
{
	
}

int published (int user_id, const char *album_file, int photo_id)
{
	if (user_id<=0 || !album_file) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	if (photo_id<0) sprintf (qs, "SELECT pub_id FROM publicatii WHERE user_id='%d' AND album_file='%s'", user_id, album_file);
		else sprintf (qs, "SELECT pub_id FROM publicatii WHERE user_id='%d' AND album_file='%s' AND photo_id='%d'", user_id, album_file, photo_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int publish (int user_id, const char *album_file, int photo_id)
{
	if (published (user_id, album_file, photo_id)) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "INSERT INTO publicatii (user_id, album_file, photo_id) VALUES ('%d', '%s', %d)", user_id, album_file, photo_id);
	if (mysql_query (&db, qs)) return 1;
	return 0;
}

int category_exists (const char *cat)
{
	MYSQL db = get_db ();
	if (!cat) return 0;
	char qs[1000];
	sprintf (qs, "SELECT nume FROM categorii WHERE nume='%s'", cat);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int get_category_id (const char *cat)
{
	MYSQL db = get_db ();
	if (!cat) return 0;
	char qs[1000];
	sprintf (qs, "SELECT cat_id FROM categorii WHERE nume='%s';", cat);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = ps_strtoint (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

char * get_category_name (int cat_id)
{
	char *res = NULL;
	if (cat_id<0) return NULL;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT nume FROM categorii WHERE cat_id='%d';", cat_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = strdup (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return res;
}

int get_album_id_from_file (const char *albumul)
{
	MYSQL db = get_db ();
	if (!albumul) return 0;
	char qs[1000];
	sprintf (qs, "SELECT album_id FROM albume WHERE file='%s.psa';", albumul);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = ps_strtoint (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int get_album_id (const char *albumul)
{
	MYSQL db = get_db ();
	if (!albumul) return 0;
	char qs[1000];
	sprintf (qs, "SELECT album_id FROM albume WHERE name='%s';", albumul);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = ps_strtoint (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

char * get_album_name (int album_id)
{
	char *res = NULL;
	if (album_id<0) return NULL;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT name FROM albume WHERE album_id='%d';", album_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = strdup (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return res;
}

char * get_album_file (int album_id)
{
	char *res = NULL;
	if (album_id<0) return NULL;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT file FROM albume WHERE album_id='%d';", album_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			if (row = mysql_fetch_row (result))
			{
				res = strdup (row[0]);
			}
			mysql_free_result (result);
			return res;
		}
	}
	return res;
}

int album_exists (const char *album, int cat_id)
{
	MYSQL db = get_db ();
	if (!album || cat_id<=0) return 0;
	char qs[1000];
	sprintf (qs, "SELECT name FROM albume WHERE name='%s' AND category='%d'", album, cat_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			int res=0;
			if (mysql_num_rows (result) > 0) res=1;
			mysql_free_result (result);
			return res;
		}
	}
	return 0;
}

int filter_psa (const dirent *namelist)
{
	int r=0;
	char *ext=NULL;
	if (rindex (namelist->d_name, '.')!=NULL) ext=strdup(rindex (namelist->d_name, '.'));
	if (ext!=NULL &&  strcasecmp (ext,".psa")==0) r=1;
	return r;
}

int get_categories()
{
	int nr=0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT cat_id, nume FROM categorii ORDER BY nume ASC");
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while (row = mysql_fetch_row (result))
			{
				categorii[nr].cat_id = ps_strtoint (row[0]);
				strcpy (categorii[nr].nume, row[1]);
				nr++;
			}
			mysql_free_result (result);
		}
	}
	return nr;
}

_ps_category_list * get_categories_list ()
{
	return categorii;
}

int get_albums(int cat_id)
{
	int nr=0;
	if (cat_id<=0) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT album_id, name, file FROM albume WHERE category='%d' ORDER BY name ASC", cat_id);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while (row = mysql_fetch_row (result))
			{
				albume[nr].album_id = ps_strtoint (row[0]);
				strcpy (albume[nr].nume, row[1]);
				strcpy (albume[nr].file, row[2]);
				nr++;
			}
			mysql_free_result (result);
		}
	}
	return nr;
}

int get_new_albums(int n)
{
	int nr=0;
	if (n<=0) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT album_id, name, file FROM albume ORDER BY date DESC LIMIT 0,%d", n);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while (row = mysql_fetch_row (result))
			{
				albume[nr].album_id = ps_strtoint (row[0]);
				strcpy (albume[nr].nume, row[1]);
				strcpy (albume[nr].file, row[2]);
				nr++;
			}
			mysql_free_result (result);
		}
	}
	return nr;
}

_ps_album_list * get_albums_list ()
{
	return albume;
}

int get_wallpaper_score (const char *album_name, int photo_id)
{
	int score=-1;
	if (!album_name || photo_id<=0) return -1;
	MYSQL db = get_db ();
	char qs[1000];
	int scor_vechi;
	sprintf (qs, "SELECT score FROM wallpapers WHERE album_id='%d' AND photo_id='%d'", get_album_id_from_file (album_name), photo_id);
	if (mysql_query (&db, qs)) return -1;
	MYSQL_RES *result = mysql_store_result (&db);
	if (result)
	{
		MYSQL_ROW row;
		if (row = mysql_fetch_row (result))
		{
			score = ps_strtoint (row[0]);
		}
		mysql_free_result (result);
	}
	return score;
}


void score_add (const char *album_name, int photo_id, int score)
{
	if (!album_name || photo_id<=0 || score==0) return;
	int album_id = get_album_id_from_file (album_name);
	if (album_id<=0) return;
	MYSQL db = get_db ();
	char qs[1000];
	int scor_vechi = get_wallpaper_score (album_name, photo_id);
	if (scor_vechi>-1)
	{
		sprintf (qs, "UPDATE wallpapers SET score='%d' WHERE album_id='%d' AND photo_id='%d'", scor_vechi+score, album_id, photo_id);
	}
	else
		sprintf (qs, "INSERT INTO wallpapers (album_id, photo_id, score) VALUES ('%d', '%d', '%d')", album_id, photo_id, score);
	if (mysql_query (&db, qs)) return;
}

int get_top_wallpapers(int n)
{
	int nr=0;
	if (n<=0) return 0;
	MYSQL db = get_db ();
	char qs[1000];
	sprintf (qs, "SELECT album_id, photo_id FROM wallpapers ORDER BY score DESC LIMIT 0,%d", n);
	if (mysql_query (&db, qs)) return 0;
	{
		MYSQL_RES *result = mysql_store_result (&db);
		if (result)
		{
			MYSQL_ROW row;
			while ((row = mysql_fetch_row (result)) && n>0)
			{
				char * fis = get_album_file (ps_strtoint(row[0]));
				if (fis!=NULL)
				{
					int l = strlen (fis)-4;
					strncpy (poze[nr].album_file, fis, l);
					poze[nr].album_file[l]='\0';
					poze[nr].photo_id = ps_strtoint (row[1]);
					nr++;
					n--;
				}
			}
			mysql_free_result (result);
		}
	}
	return nr;
}

_ps_wallpaper_list * get_top_wallpapers_list ()
{
	return poze;
}

/*int main()
{
	db_init ();
	//update_db ();
	int nr=get_categories ();
	for (int i=0;i<nr;i++) printf ("%d\t%s\n", categorii[i].cat_id, categorii[i].nume);
	db_close ();
	return 0;
}*/
