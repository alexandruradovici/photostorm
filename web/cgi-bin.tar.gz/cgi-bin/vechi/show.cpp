
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <dirent.h>
#include "data.h"
#include "cgi_cpp.h"
#include "htmls.h"
#include "album.h"
#include "photo.h"
#include "misc.h"
#include "db.h"
#include "albumdb.h"
#include "userdb.h"

static char psw_user_album_path[10000];
static char *login_name;

const int FOUND_MAX = 12;

void show_user_album (const char *album_id);

const char * user_album_path (const char *album)
{
    char s[1000];
    strcpy (s,"");
    if (album!=NULL) sprintf (s, "%s/%s.psa", psw_user_album_path, album);
    return strdup (s);
}

const char * user_album_path_ (const char *album)
{
    char s[1000];
    strcpy (s,"");
    if (album!=NULL) sprintf (s, "%s/%s", psw_user_album_path, album);
    return strdup (s);
}

int write_album_categories_select (const char *name, const char *cat_def)
{
	int gasit = 0;
	if (name!=NULL && cat_def!=NULL)
	{
		printf ("<select name=\"%s\" class=\"campuri3\">", name);
		int nr = get_categories ();
		_ps_category_list *categorii = get_categories_list ();
		printf ("<option value=\"0\">--- Custom ---</option>");
		char st[1000];
		for (int i=0;i<nr;i++) 
		{	
			sprintf (st, "%s", (strcasecmp (categorii[i].nume, cat_def))?"":" selected");
			if (strcmp (st,"")) gasit = 1;
			printf ("<option value=\"%d\"%s>%s</option>", categorii[i].cat_id, st, categorii[i].nume);
		}
		printf ("</select>");
	}
	return gasit;
}

void search_page (const char *keywords, const char *all_keywords, const char *s_name,
				  const char *s_author, const char *s_description)
{
	printf (
		"<table width=100%% border=0 cellspacing=0 cellpadding=0 class=\"afis_tabel4\">"
		"<form action=\"/cgi-bin/show.cgi\" method=GET>"
		"<th colspan=2 bgcolor=#9c9c9c>Search Photos</th><tr><td colspan=2><br></dt></tr>"
		"<tr valign=top>"
			"<td width=100%% valign=top colspan=2>"
			"<center>Keywords <input type=text name=\"search\" class=\"campuri2\" value=\"%s\"><input type=image src=\"/images/go.jpg\" border=0 align=center width=35><center>"
			"</td>"
		"</tr>"
		"<th colspan=2 bgcolor=#9c9c9c>Advanced Search</th><tr><td colspan=2><br></dt></tr>"
		"<tr>"
			"<td align=left valign=middle><input type=checkbox name=\"all_keywords\" %s>Find only photos matching all the keywords</input></td>"
			"<td align=left valign=middle><input type=checkbox name=\"s_name\" %s>Search names</input></td>"
		"</tr>"
		"<tr>"
			"<td align=left valign=middle><input type=checkbox name=\"s_author\" %s>Search author's names</input></td>"
			"<td align=left valign=middle><input type=checkbox name=\"s_description\" %s>Search descriptions</input></td>"
		"</tr>"
		"</form>"
		"</table>"
	,(keywords!=NULL)?filter_html_code(keywords):"", (all_keywords!=NULL && strcasecmp (all_keywords, "on")==0)?"checked":""
	,(s_name!=NULL && strcasecmp (s_name, "on")==0)?"checked":"", (s_author!=NULL && strcasecmp (s_author, "on")==0)?"checked":""
	,(s_description!=NULL && strcasecmp (s_description, "on")==0)?"checked":"");
}

int filter_psa_ (const dirent *namelist)
{
	int r=0;
	char *ext=NULL;
	if (rindex (namelist->d_name, '.')!=NULL) ext=strdup(rindex (namelist->d_name, '.'));
	if (ext!=NULL &&  strcasecmp (ext,".psa")==0) r=1;
	return r;
}

void photo_index (const char *keywords, int skips, const char *all_keywords, char *s_name,
				  const char *s_author, const char *s_description)
{
	if ((s_name==NULL || (s_name!=NULL && strcasecmp (s_name, "on")!=0)) &&
		(s_author==NULL || (s_author!=NULL && strcasecmp (s_author, "on")!=0)) &&
		(s_description==NULL || (s_description!=NULL && strcasecmp (s_description, "on")!=0)))
		s_name = strdup ("on");
	int wallpapers=0;
	if (keywords==NULL) 
	{	
		wallpapers=1;
		keywords = strdup ("");
	}
	printf (
	"<img src=\"/images/wallpapers.jpg\" border=0 align=center><br><br>"
	);
	search_page (keywords, all_keywords, s_name, s_author, s_description);
	printf ("<br><br>");
	printf (
	"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
	"<th colspan=4 bgcolor=#9c9c9c>Searching \"%s\"</th><tr><td colspan=4><br></dt></tr>"
	, filter_html_code(keywords));
	struct dirent **namelist;
	int n = scandir (psw_album_path, &namelist, filter_psa_, alphasort); 
	int found=0;
	int albums = 0;
	if (n>0)
	{
		while (n-- && found<FOUND_MAX)
			{
				_ps_album *date_album = ps_load_album (album_path_ (namelist[n]->d_name));
				if (date_album!=NULL)
				{
				  albums++;
				  if (albums>skips)
				  {
					char albumul[1000];
					strncpy (albumul, namelist[n]->d_name, strlen (namelist[n]->d_name)-4);
					albumul [strlen (namelist[n]->d_name)-4]='\0';
					for (int i=0;i<date_album->nr_poze;i++)
					{
						_ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, i+1, 0);
						if (date_poza!=NULL)
						{
							if (search_keywords ((char*)keywords, date_album->nume) ||
								search_keywords ((char*)keywords, date_album->categoria) ||
								search_keywords ((char*)keywords, date_album->descriere) ||
								search_keywords ((char*)keywords, date_poza->nume) ||
								search_keywords ((char*)keywords, date_poza->autor) ||
								search_keywords ((char*)keywords, date_poza->descriere));
							int gasit = wallpapers;
							if (all_keywords!=NULL && strcasecmp(all_keywords, "on")==0)
							{
								if (!gasit)
									if (s_name!=NULL && strcasecmp (s_name, "on")==0) 
									gasit = search_keywords_ ((char*)keywords, date_album->nume) ||
									  	    search_keywords_ ((char*)keywords, date_poza->nume);
								if (!gasit)
									if (s_author!=NULL && strcasecmp (s_author, "on")==0) 
									gasit = search_keywords_ ((char*)keywords, date_album->autor) ||
									  	    search_keywords_ ((char*)keywords, date_poza->autor);
								if (!gasit)
									if (s_description!=NULL && strcasecmp (s_description, "on")==0) 
									gasit = search_keywords_ ((char*)keywords, date_album->descriere) ||
									  	    search_keywords_ ((char*)keywords, date_poza->descriere);
							}
							else
							{
								if (!gasit)
									if (s_name!=NULL && strcasecmp (s_name, "on")==0) 
									gasit = search_keywords ((char*)keywords, date_album->nume) ||
									  	    search_keywords ((char*)keywords, date_poza->nume);
								if (!gasit)
									if (s_author!=NULL && strcasecmp (s_author, "on")==0) 
									gasit = search_keywords ((char*)keywords, date_album->autor) ||
									  	    search_keywords ((char*)keywords, date_poza->autor);
								if (!gasit)
									if (s_description!=NULL && strcasecmp (s_description, "on")==0) 
									gasit = search_keywords ((char*)keywords, date_album->descriere) ||
									  	    search_keywords ((char*)keywords, date_poza->descriere);
							}
							if (gasit)
							{
								found++;
								if (found%4==1) printf ("<tr>");
									char text_poza[1000];
								sprintf (text_poza, "%s<br><i>(C) %s</i>",
			 					 		(date_poza->nume!=NULL)?date_poza->nume:"", 
			 							(date_poza->autor!=NULL)?date_poza->autor:"");
								printf (
								"<td width=25%% align=center valign=top>"
     							"<table cellspacing=0 cellpadding=0 width=110 border=0>"
     							"<tr>"
      								"<td><a href=\"/cgi-bin/show.cgi?album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?album_name=%s&photo_id=%d&x=100&y=75\" border=0 height=75 width=100></a></td>"
      								"<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     							"</tr>"
     							"<tr>"
      								"<td colspan=3><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     							"</tr>"
     							"<tr>"
      								"<td colspan=3><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     							"</tr>"
	 							"</table>"
	 							"</td>"
								, albumul, i+1, albumul, i+1, text_poza);
								if (found%4==0) printf ("</tr>");
							}
							ps_photo_free (date_poza);
						}
					}
					ps_album_free (date_album);
				}
			}
		}
		if (found%4!=0) printf ("</tr>");
	}
	if (found>0) printf ("<th colspan=4 bgcolor=#9c9c9c align=right><a href=\"/cgi-bin/show.cgi?search=%s&skips=%d\">Search More</a></th>"
				 , filter_html_code (code_UTF_8(keywords)), albums);
	if (found==0) printf ("<tr><td class=\"afis_tabel4\">Sorry, but there was no photo found matching your keywords</td></tr>");
	printf ("</table>");
	printf ("<br><br>");
}

void download_image (const char *album_name, const char *photo_id)
{
	_ps_album *date_album = ps_load_album (album_path (album_name));
	int id = ps_strtoint (photo_id);
	if (date_album!=NULL)
	{
		_ps_photo *date_poza = ps_load_photo_nr_from_album_memory (date_album, id);
		if (date_poza!=NULL)
		{
			char filename[1000];
			sprintf (filename, "%s___%s.jpg", ps_strfilter_filename(date_poza->autor), ps_strfilter_filename(date_poza->nume));
			printf ("Pragma: public\n");
			printf ("Cache-Control: no-store, max-age=0, no-cache, must-revalidate\n");
			printf ("Cache-Control: post-check=0, pre-check=0\n");
			printf ("Cache-control: private\n");
			printf ("Content-Disposition: inline; filename=\"%s\"\n", filename);
			printf ("Content-Length: %ld\n",date_poza->n_poza);
			printf ("Content-Type: application/octet-stream; name=\"%s\"\n\n", filename);
			fwrite (date_poza->date, date_poza->n_poza, 1, stdout);
			ps_photo_free (date_poza);
		}
		ps_album_free (date_album);
		score_add (album_name, id, 2);
	}
	exit (0);
}

void download_photo (const char *album_name, const char *photo_id)
{
	_ps_album *dwl = NULL;
	_ps_album *date_album = ps_load_album (album_path (album_name));
	int id = ps_strtoint (photo_id);
	if (date_album!=NULL)
	{
		_ps_photo *date_poza = ps_load_photo_nr_from_album_memory (date_album, id);
		if (date_poza!=NULL)
		{
			dwl = ps_create_new_album_in_memory (date_album->nume, date_album->autor,
												 date_album->categoria, date_album->descriere,
												 "", "");
			if (dwl!=NULL)
			{
				ps_add_photo_to_album_from_memory_into_memory (date_poza, dwl);
				long n;
				char *date = NULL;
				date = ps_pack_album (dwl, n);
				char filename[1000];
				sprintf (filename, "psp_%ld%d.psp", time(0), (1 + (int) (100000000.0 * rand()/(RAND_MAX + 1.0))));
				printf ("Pragma: public\n");
				printf ("Cache-Control: no-store, max-age=0, no-cache, must-revalidate\n");
				printf ("Cache-Control: post-check=0, pre-check=0\n");
				printf ("Cache-control: private\n");
				printf ("Content-Disposition: inline; filename=\"%s\"\n", filename);
				printf ("Content-Length: %ld\n",n);
				printf ("Content-Type: photo_album/psp; name=\"%s\"\n\n", filename);
				fwrite (date, n, 1, stdout);
				if (date!=NULL) free (date);
				ps_album_free (dwl);
				score_add (album_name, id, 3);
			}
			ps_photo_free (date_poza);
		}
		ps_album_free (date_album);
	}
}

void download_album (const char *album_name)
{
	_ps_album *date_album = ps_load_album (album_path (album_name));
	if (date_album!=NULL)
	{
		long n;
		char *date = NULL;
		date = ps_pack_album (date_album, n);
		char filename[1000];
		sprintf (filename, "psa_%ld%d.psa", time(0), (1 + (int) (100000000.0 * rand()/(RAND_MAX + 1.0))));
		printf ("Pragma: public\n");
		printf ("Cache-Control: no-store, max-age=0, no-cache, must-revalidate\n");
		printf ("Cache-Control: post-check=0, pre-check=0\n");
		printf ("Cache-control: private\n");
		printf ("Content-Disposition: inline; filename=\"%s\"\n", filename);
		printf ("Content-Length: %ld\n",n);
		printf ("Content-Type: photo_album/psa; name=\"%s\"\n\n", filename);
		fwrite (date, n, 1, stdout);
		if (date!=NULL) free (date);
		for (int i=0;i<date_album->nr_poze;i++) score_add (album_name, i, 3);
		ps_album_free (date_album);
	}
}

void show_photo (const char *album_name, const char *photo_id)
{
	printf (
	"<img src=\"/images/wallpaper.jpg\" border=0 align=center><br><br>"
	);
	int id = ps_strtoint (photo_id);
	_ps_album *date_album = ps_load_album (album_path (album_name));
	if (date_album!=NULL)
	{
		_ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, id, 0);
		if (date_poza!=NULL)
		{
			printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		  "<th colspan=4 bgcolor=#9c9c9c>Photo Information</th>"
     	  "<tr>"
			"<td width=100%% align=center valign=middle>"
			"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
     		"<tr>"
      		"<td colspan=2 width=50%% align=center>"
		      "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      		    "<tr><td align=center>%s</td></tr>"
			    "<tr><td align=center><a href=\"/cgi-bin/show.cgi?cat_id=%d\"><b>%s</b></a> -> <a href=\"/cgi-bin/show.cgi?album_name=%s\">%s</a></td></tr>"
      	      "</table>"
      		"</td>"
      		"<td colspan=2 width=50%% align=center>"
	          "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      			"<tr><td align=center>(C) %s</td></tr>"
      			"<tr><td align=center>Size %ld KB</td></tr>"
      		  "</table>"
      "</td>"
     "</tr>"
     "<th colspan=4 bgcolor=#9c9c9c>Photo Preview</th>"
     "<tr>"
     "<td colspan=4><br></td>"
     "</tr>"
     "<tr>"
	 "<td colspan=4 valign=middle align=center><table border=0 cellpadding=0 cellspacing=7><tr>"
	 ,filter_html_code (date_poza->nume), get_category_id (date_album->categoria), filter_html_code (date_album->categoria), album_name, filter_html_code (date_album->nume), filter_html_code (date_poza->autor), date_poza->n_poza / 1024);
	 if (id>1) 
		 printf ("<td valign=middle align=center><a href=\"/cgi-bin/show.cgi?album_name=%s&photo_id=%d\">Previous</a></td>", filter_html_code (album_name), id-1);
	 else printf ("<td valign=middle align=center><font color=#FFFFFF>Previous</font></td>");
			printf (
			"<td valign=middle align=center>"
			"<table cellspacing=0 cellpadding=5 width=400 border=0 class=\"afis_poza\">"
     		"<tr>"
      			"<td><table border=0 cellspacing=0 cellpadding=0 class=\"afis_poza\"><tr><td><a href=\"/cgi-bin/show.cgi?%spage=configw&album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?album_name=%s&photo_id=%d&x=400&y=300\" border=0 height=300 width=400></a></td></tr></table></td>"
     		"</tr>"
     		"<tr>"
      			"<td width=310 height=10> </td>"
     		"</tr>"
     		"<tr>"
      			"<td><center><a href=\"/cgi-bin/show.cgi?download=1&album_name=%s&photo_id=%d\"><font class=\"text_poza\">Download Photo</font></a> | <a href=\"/cgi-bin/show.cgi?download=2&album_name=%s&photo_id=%d\"><font class=\"text_poza\">Download Image</font></a> | <a href=\"/cgi-bin/show.cgi?%spage=configw&album_name=%s&photo_id=%d\"><font class=\"text_poza\">Make Wallpaper</font></a></center></td>"
     		"</tr>"
	 		"</table><br>"
	 		"</td>"
			, (login_name!=NULL)?"data=user&":"", album_name, id, album_name, id, album_name, id, album_name, id, (login_name!=NULL)?"data=user&":"", album_name, id);
	 if (id<date_album->nr_poze) 
		 printf ("<td valign=middle align=center><a href=\"/cgi-bin/show.cgi?album_name=%s&photo_id=%d\">Next</a></td>", filter_html_code (album_name), id+1);
	 else printf ("<td valign=middle align=center><font color=#FFFFFF>Next</font></td>");
			printf (
    "</tr></table>"
	"</td>"
	"</tr>"
	 );
	 if (strcmp (date_poza->descriere, "")!=0)
	 {
		 printf (
	 	"<th colspan=4 bgcolor=#9c9c9c>Description</th>"
     	"<tr>"
     	"<td colspan=4 align=center><textarea cols=60 rows=6 readonly class=\"campuri3\">%s</textarea></td>"
     	"</tr>"
		"<tr>"
     	"<td colspan=4><br></td>"
     	"</tr>"
		, filter_html_code_textarea (date_poza->descriere));	 
	}
	printf (
	"</table>"
	);
	
			ps_photo_free (date_poza);
		}
		ps_album_free (date_album);
	}
	printf (
    "<br><center><i>When the download window apperas, chose <b>Open file</b> and select photostorm binary file to open it (usualy \"<b>/usr/local/bin/photostorm</b>\" for Linux and \"<b>C:\\Program Files\\PhotoStorm\\photostorm.exe</b>\" for Microsoft<sup>TM</sup> Windows<sup>TM</sup>).</i></center><br>"
    "</td>"
	"</tr>"
	"</table>"
	 );
	
}

void show_album (const char *album_id)
{
	printf (
	"<img src=\"/images/album.jpg\" border=0 align=center><br><br>"
	);
	_ps_album *date_album = ps_load_album (album_path (album_id));
	if (date_album!=NULL)
	{
		char data_album [1000];
		tm *info_data_album = localtime (&date_album->data);
		strftime (data_album, sizeof (data_album), "%A, %B %d, %G", info_data_album);
		printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		  "<th colspan=4 bgcolor=#9c9c9c>Album Information</th>"
     	  "<tr>"
			"<td width=100%% align=center valign=middle>"
			"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
     		"<tr>"
      		"<td colspan=2 width=50%% align=center>"
		      "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      		    "<tr><td align=center><a href=/cgi-bin/show.cgi?cat_id=%d><b>%s</b></a> -> %s</td></tr>"
			    "<tr><td align=center>Created on %s</td></tr>"
      	      "</table>"
      		"</td>"
      		"<td colspan=2 width=50%% align=center>"
	          "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      			"<tr><td align=center>(C) %s</td></tr>"
      			"<tr><td align=center>Size %ld KB</td></tr>"
      		  "</table>"
      "</td>"
     "</tr>"
     "<th colspan=4 bgcolor=#9c9c9c>Photos contained in the album</th>"
     "<tr>"
     "<td colspan=4><br></td>"
     "</tr>"
     "<tr>"
	 ,get_category_id (date_album->categoria), filter_html_code (date_album->categoria), filter_html_code (date_album->nume), data_album, filter_html_code (date_album->autor), date_album->n_poze / 1024);
	 int i=0;
	 for (i=1;i<=date_album->nr_poze;i++)
	 {
		 char text_poza[1000];
		 strcpy (text_poza, "");
		 _ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, i, 0);
		 if (date_poza!=NULL)
		 {
			 sprintf (text_poza, "%s<br><i>(C) %s</i>",
			 (date_poza->nume!=NULL)?date_poza->nume:"", 
			 (date_poza->autor!=NULL)?date_poza->autor:"");
			 ps_photo_free (date_poza);
		 }
		 if (i%4==1) printf ("<tr>");
		 printf (
     "<td width=25%% align=center valign=top>"
     "<table cellspacing=0 cellpadding=0 width=110 border=0>"
     "<tr>"
      "<td width=120 height=85 class=\"afis_poza\" valign=middle align=center><a href=\"/cgi-bin/show.cgi?album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?album_name=%s&photo_id=%d&x=100&y=75\" border=0 height=75 width=100 class=\"afis_poza\"></a></td>"
      //"<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     "</tr>"
     "<tr>"
      //"<td colspan=4><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     "</tr>"
     "<tr>"
      "<td colspan=4><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     "</tr>"
	 "</table>"
	 "</td>"
	, album_id, i, album_id, i, text_poza); 
		 if (i%4==0) printf ("</tr>");
	 }
	 printf ("</table>");
	 	if (i%4!=0) printf ("</tr>");
	printf (
    "</td>"
	"</tr>"
	);
	if (strcmp (date_album->descriere, "")!=0)
	 {
		 printf (
	 	"<th colspan=4 bgcolor=#9c9c9c>Description</th>"
     	"<tr>"
     	"<td colspan=4 align=center><textarea cols=60 rows=6 readonly class=\"campuri3\">%s</textarea></td>"
     	"</tr>"
		"<tr>"
     	"<td colspan=4><br></td>"
     	"</tr>"
		, filter_html_code_textarea (date_album->descriere));	 
	}
	printf (
	"<th colspan=4 bgcolor=#9c9c9c><a href=\"/cgi-bin/show.cgi?download=1&album_name=%s\">Download the album</a></th><tr><td><br></td></tr>"
	, album_id);
	printf (
	"<tr><td><br><center><i>When the download window apperas, chose <b>Open file</b> and select photostorm binary file to open it (usualy \"<b>/usr/local/bin/photostorm</b>\" and \"<b>C:\\Program Files\\PhotoStorm\\photostorm.exe</b>\" for Microsoft<sup>TM</sup> Windows<sup>TM</sup>).</i></center><br></td></tr>"
	"</table>"
	);
	ps_album_free (date_album);
	}
}

void table_categorie (int cat_id)
{
	char * cat = get_category_name (cat_id);
	if (cat==NULL) return;
	printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		  "<th colspan=4 bgcolor=#9c9c9c>%s</th><tr><td colspan=4><br><br></td></tr>"
     	  "<tr>"
		, filter_html_code (cat));
		_ps_album *date_album = NULL;
		int nr = get_albums (cat_id);
		_ps_album_list *albume = get_albums_list ();
		int i=0;
		for (i=0;i<nr;i++)
		{
			char album_id[1000];
			int n=strlen (albume[i].file)-4;
			strncpy (album_id, albume[i].file, n);
			album_id [n]='\0';
			date_album = ps_load_album_data (album_path_ (albume[i].file), 0);
			if (date_album!=NULL)
			{
				char text_album[1000];
		 		sprintf (text_album, "%s<br><i>(C) %s</i><br>%d photos", date_album->nume, date_album->autor, date_album->nr_poze);
		 		if (i%4==0) printf ("<tr>");
				printf (
					"<td width=25%% align=center valign=top>"
     				"<table cellspacing=0 cellpadding=0 width=110 border=0>"
     				"<tr>"
      					"<td><a href=\"/cgi-bin/show.cgi?album_name=%s\"><img src=\"/cgi-bin/get_photo.cgi?album_name=%s&photo_id=0&x=100&y=75\" border=0 height=75 width=100></a></td>"
      					"<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     				"</tr>"
     				"<tr>"
      					"<td colspan=3><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     				"</tr>"
     				"<tr>"
      					"<td colspan=3><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     				"</tr>"
	 				"</table>"
	 				"</td>"
				, album_id, album_id, text_album);
				if (i%4==3) printf ("</tr>");
				ps_album_free (date_album);
			}
		}
		if (i%4!=0) printf ("</tr>");
		printf ("</table><br>");
}

void show_categorie (int cat_id)
{
	printf (
	"<img src=\"/images/albums.jpg\" border=0 align=center><br><br>"
	);
	table_categorie (cat_id);
	printf (
    	"</td>"
	);
}

int filter_ps_cat (const dirent *namelist)
{
	int r=0;
	char *ext=NULL;
	if (rindex (namelist->d_name, '.')!=NULL) ext=strdup(rindex (namelist->d_name, '.'));
	if (ext!=NULL &&  strcasecmp (ext,".ps_cat")==0) r=1;
	return r;
}

void show_albums ()
{
	printf (
	"<img src=\"/images/albums.jpg\" border=0 align=center><br><br>"
	);
	
	printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		  "<th colspan=4 bgcolor=#9c9c9c>Newest Albums</th><tr><td colspan=4><br><br></td></tr>"
     	  "<tr>"
		);
		_ps_album *date_album = NULL;
		int nr = get_new_albums (12);
		_ps_album_list *albume = get_albums_list ();
		int i=0;
		for (i=0;i<nr;i++)
		{
			char album_id[1000];
			int n=strlen (albume[i].file)-4;
			strncpy (album_id, albume[i].file, n);
			album_id [n]='\0';
			date_album = ps_load_album_data (album_path_ (albume[i].file), 0);
			if (date_album!=NULL)
			{
				char text_album[1000];
		 		sprintf (text_album, "%s<br><i>(C) %s</i><br>%d photos", date_album->nume, date_album->autor, date_album->nr_poze);
		 		if (i%4==0) printf ("<tr>");
				printf (
					"<td width=25%% align=center valign=top>"
     				"<table cellspacing=0 cellpadding=0 width=110 border=0>"
     				"<tr>"
      					"<td><a href=\"/cgi-bin/show.cgi?album_name=%s\"><img src=\"/cgi-bin/get_photo.cgi?album_name=%s&photo_id=0&x=100&y=75\" border=0 height=75 width=100></a></td>"
      					"<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     				"</tr>"
     				"<tr>"
      					"<td colspan=3><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     				"</tr>"
     				"<tr>"
      					"<td colspan=3><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     				"</tr>"
	 				"</table>"
	 				"</td>"
				, album_id, album_id, text_album);
				if (i%4==3) printf ("</tr>");
				ps_album_free (date_album);
			}
		}
		if (i%4!=0) printf ("</tr>");
		printf ("</table>");
	
	printf (
    	"</td>"
	);
}

int sum_album_space ()
{
	int dim = 0;
	int n;
	dirent **namelist;
	n = scandir (psw_user_album_path, &namelist, filter_psa_, alphasort);
    if (n>0)
	while(n--) 
	{
		char albumul[1000];
		int t = strlen (namelist[n]->d_name)-4;
		strncpy (albumul, namelist[n]->d_name, t);
		albumul[t]='\0';
		FILE *f = fopen (user_album_path (albumul), "r");
		if (f!=NULL)
		{
			fseek (f, 0, SEEK_END);
			dim = dim + ftell (f);
			fclose (f);
		}
		free (namelist[n]);
	}
	return dim;
}

void user_album_toolbar (const char *album_name)
{
	_ps_user *user = get_user_info (login_name);
	if (!user) return;
	printf ("<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\"><tr>");
		printf ("<td valign=bottom><a href=/cgi-bin/show.cgi?data=user&page=new_album><img src=/images/album.png border=0> Create Album </a></td>");
		printf ("<td valign=bottom><a href=/cgi-bin/show.cgi?data=user&album_name=%s&page=new_photos><img src=/images/photos.png border=0> Add Photos </a></td>", album_name?album_name:"");
		printf ("<td valign=bottom><a href=/cgi-bin/show.cgi?data=user&album_name=%s&action=edit><img src=/images/info.png border=0> Edit Album </a></td>", album_name?album_name:"");
		printf ("<td valign=bottom><a href=/cgi-bin/show.cgi?data=user&album_name=%s&page=delete><img src=/images/delete.png border=0> Delete Album </a></td>", album_name?album_name:"");	
		if (!published (user->user_id, album_name, 0)) printf ("<td><a href=/cgi-bin/show.cgi?data=user&album_name=%s&action=publish><img src=/images/website.png border=0> Publish </a></td>", album_name?album_name:"");
	printf ("</tr></table>");
	free (user);
}

void user_photo_toolbar (const char *album_name, int id)
{
	_ps_user *user = get_user_info (login_name);
	if (!user) return;
	printf ("<table cellspacing=0 cellpadding=0 width=100%%><tr>");
		printf ("<td><a href=/cgi-bin/show.cgi?data=user&album_name=%s&photo_id=%d&action=edit><font class=\"text_poza\"><img src=/images/info_alb.png border=0> Edit Photo </a></font></td>", album_name?album_name:"", id);
		printf ("<td><a href=/cgi-bin/show.cgi?data=user&album_name=%s&photo_id=%d&action=delete><font class=\"text_poza\"><img src=/images/delete_alb.png border=0> Delete Photo </a></font></td>", album_name?album_name:"", id);
		if (!published (user->user_id, album_name, id)) printf ("<td><a href=/cgi-bin/show.cgi?data=user&album_name=%s&photo_id=%d&action=publish><font class=\"text_poza\"><img src=/images/website_alb.png border=0> Publish </a></font></td>", album_name?album_name:"", id);
	printf ("</tr></table>");
}

void new_photo_from (const char *album_id)
{
	if (album_id==NULL) return;
	printf (
	"<img src=\"/images/addphotos.jpg\" border=0 align=center><br><br>"
	"<table width=100%% cellspacing=2 cellpadding=5 class=\"afis_tabel4\">"
	"<form action=\"/cgi-bin/show.cgi?data=user&album_name=%s&page=new_photos&action=upload\" enctype=\"multipart/form-data\" method=POST>"
//	"<form action=\"/cgi-bin/test.cgi\" enctype=\"multipart/form-data\" method=POST>"
	"<th bgcolor=#9c9c9c>Upload Photos</th>"
	"<tr><td valign=top align=center><i>All photos have to be in JPEG format and not to exceed 5 MB and your storage space.</td></tr>"
	, album_id);
	printf (
	"<tr class=\"afis_tabel3\">"
		"<td valign=top align=left>Photo 1&nbsp;&nbsp;&nbsp;"
			"<input type=file name=\"poza_1\" value=\"\" class=\"campuri3\">"
		"</td>"
	"</tr>"
	);
	printf (
	"<tr class=\"afis_tabel4\">"
		"<td valign=top align=left>Photo 2&nbsp;&nbsp;&nbsp;"
			"<input type=file name=\"poza_2\" value=\"\" class=\"campuri3\">"
		"</td>"
	"</tr>"
	);
	printf (
	"<tr class=\"afis_tabel3\">"
		"<td valign=top align=left>Photo 3&nbsp;&nbsp;&nbsp;"
			"<input type=file name=\"poza_3\" value=\"\" class=\"campuri3\">"
		"</td>"
	"</tr>"
	);
	printf (
	"<tr class=\"afis_tabel4\">"
		"<td valign=top align=left>Photo 4&nbsp;&nbsp;&nbsp;"
			"<input type=file name=\"poza_4\" value=\"\" class=\"campuri3\">"
		"</td>"
	"</tr>"
	);
	printf (
	"<tr class=\"afis_tabel3\">"
		"<td valign=top align=left>Photo 5&nbsp;&nbsp;&nbsp;"
			"<input type=file name=\"poza_5\" value=\"\" class=\"campuri3\">"
		"</td>"
	"</tr>"
	);
	printf ("<th bgcolor=#828282 valign=top align=center><input type=submit name=\"buton\" value=\"Upload Photos\" class=\"buton_alb\"></th>");
	printf ("</form></table>");
}

void upload_photos (const char *album_id)
{
	if (album_id==NULL) abort ();
	_ps_album *date_album = ps_load_album (user_album_path (album_id));
	long dim = sum_album_space ();
	if (date_album!=NULL)
	{
		_ps_user *user = get_user_info (login_name);
		use_upload ();
		getpost ();
		long n;
		char *poza=NULL;
		_ps_photo *date_poza;
		for (int i=0;i<5;i++)
		{
			char t[100];
			sprintf (t, "poza_%d", i+1);
			n=0;
			poza = get_upload_data (t, "image/jpeg", n);
			if (poza == NULL) get_upload_data (t, "image/pjpeg", n);
			if (poza!=NULL && n>0 && (dim+n <= user->space*1024*1024))
			{
				char t1[100];
				sprintf (t1, "/Photo %d", i+1);
				date_poza = ps_create_photo_from_memory (t1, poza, n);
				if (date_poza!=NULL)
				{
					char autor[1000];
					sprintf (autor, "%s %s", user->first_name, user->last_name);
					ps_modify_photo (date_poza, t, autor, "", "A", (char*)ps_inttostr (user->user_id));
					ps_add_photo_to_album_from_memory_into_memory (date_poza, date_album);
					ps_photo_free (date_poza);
					dim=dim+n;
				}
			}
			/*printf ("Photo OK 2");
			abort ();*/
			if (poza!=NULL) free (poza);
		}
		ps_write_album_from_memory (user_album_path (album_id), date_album);
		ps_album_free (date_album);
	}
	show_user_album (album_id);
}

void create_album_form ()
{
	printf (
	"<img src=\"/images/newalbum.jpg\" border=0 align=center><br><br>"
	"<table width=100%% cellspacing=2 cellpadding=0 class=\"afis_tabel4\">"
	"<form action=\"/cgi-bin/show.cgi?data=user&page=new_album&action=save\" method=POST>"
	"<th bgcolor=#9c9c9c>Album Information</th>"
	);
	printf (
	"<tr>"
		"<td valign=top align=left>Album Name &nbsp;&nbsp;&nbsp;"
			"<input type=text name=\"album_name\" value=\"\" maxlength=255 class=\"campuri3\">"
		"</td>"
	"</tr>"
	);
	printf (
	"<tr>"
		"<td valign=top align=left>Category&nbsp;&nbsp;&nbsp;"
		);
		write_album_categories_select ("album_cat_id", "");
		printf (		
		"&nbsp;&nbsp;&nbsp;Custom category&nbsp;&nbsp;&nbsp;<input type=text name=\"album_category\" class=\"campuri3\" maxlength=255 value=\"\">"
		"</td>"
	"</tr>"
	);
	printf (
	 "<th colspan=4 bgcolor=#9c9c9c>Description</th>"
	 "<tr>"
	 	"<td colspan=4 class=\"afis_tabel2\" valign=middle align=center><textarea name=\"album_description\" class=\"campuri3\" rows=5 cols=60 maxlength=32000></textarea></td>"
	 "</tr>"
	 "<th colspan=4 bgcolor=#9c9c9c><input type=submit value=\"Create Album\"</th>"
	 );
	 printf ("</form></table>");
}

void delete_album (const char *album_id)
{
	_ps_user *user = get_user_info (login_name);
	if (!user) return;
	if (album_id==NULL) return;
	if (!published (user->user_id, album_id, -1)) remove (user_album_path (album_id));
}

void delete_album_form (const char *album_id)
{
	if (album_id==NULL) return;
	printf (
	"<img src=\"/images/deletealbum.jpg\" border=0 align=center><br><br>"
	"<table width=100%% cellspacing=2 cellpadding=0 class=\"afis_tabel4\">"
	"<form action=\"/cgi-bin/show.cgi?data=user&album_name=%s&page=delete\" method=POST>"
	"<th bgcolor=#9c9c9c><b>ARE YOU SURE YOU WANT TO DELETE THIS ALBUM \?\?\?</b></th>"
	"<tr><td valign=top align=center>"
	"<input type=submit name=\"buton\" value=\"NO\" class=\"buton_alb\">&nbsp;&nbsp;&nbsp;<input type=submit name=\"buton\" value=\"YES\" class=\"buton_alb\">"
	"</td></tr>"
	"</form>"
	"</table>"
	, filter_html_code (album_id));
}

void show_user_albums ()
{
	printf (
	"<img src=\"/images/myalbums2.jpg\" border=0 align=center><br><br>");
	user_album_toolbar (NULL);
	printf (
	"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
	"<th colspan=4 bgcolor=#9c9c9c>%s's albums</th><tr><td colspan=4><br><br></td></tr>"
	, filter_html_code (login_name));
	struct dirent **namelist;
	int n;
	int i=0;
 	n = scandir (psw_user_album_path, &namelist, filter_psa_, alphasort);
    if (n>0)
	while(n--) 
	{
		char albumul[1000];
		int t = strlen (namelist[n]->d_name)-4;
		strncpy (albumul, namelist[n]->d_name, t);
		albumul[t]='\0';
		_ps_album *date_album = NULL;
		date_album = ps_load_album_data (user_album_path_(namelist[n]->d_name), 0);
		if (date_album!=NULL)
		{
			i++;
			char text_album[1000];
			sprintf (text_album, "%s<br><i>(C) %s</i><br>%d photos", date_album->nume, date_album->autor, date_album->nr_poze);
			if (i%4==1) printf ("<tr>");
			printf (
				"<td width=25%% align=center valign=top>"
     			"<table cellspacing=0 cellpadding=0 width=110 border=0>"
     			"<tr>"
      				"<td><a href=\"/cgi-bin/show.cgi?data=user&album_name=%s\"><img src=\"/cgi-bin/get_photo.cgi?myalbum_name=%s&photo_id=0&x=100&y=75\" border=0 height=75 width=100></a></td>"
      				"<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     			"</tr>"
     			"<tr>"
      				"<td colspan=3><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     			"</tr>"
     				"<tr>"
      				"<td colspan=3><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     			"</tr>"
	 			"</table>"
	 			"</td>"
			, albumul, albumul, text_album);
			if (i%4==0) printf ("</tr>");
			ps_album_free (date_album);
		}
		 free (namelist[n]);
    }
	printf ("</table><br>");
	printf (
    	"</td>"
	);
}

void show_user_album (const char *album_id)
{
	printf (
	"<img src=\"/images/album.jpg\" border=0 align=center><br><br>"
	);
	user_album_toolbar (album_id);
	_ps_album *date_album = ps_load_album (user_album_path (album_id));
	if (date_album!=NULL)
	{
		char data_album [1000];
		tm *info_data_album = localtime (&date_album->data);
		strftime (data_album, sizeof (data_album), "%A, %B %d, %G", info_data_album);
		printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		  "<th colspan=4 bgcolor=#9c9c9c>Album Information</th>"
     	  "<tr>"
			"<td width=100%% align=center valign=middle>"
			"<table cellspacing=0 cellpadding=0 width=100%% class=\"afis_tabel4\">"
     		"<tr>"
      		"<td colspan=2 width=50%% align=center class=\"afis_tabel4\">"
		      "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel2\">"
				"<tr><td align=center><b>Category:</b> %s</td></tr>"
      		    "<tr><td align=center><b>Album:</b> %s</td></tr>"
			    "<tr><td align=center>Created on %s</td></tr>"
      	      "</table>"
      		"</td>"
      		"<td colspan=2 width=50%% align=center class=\"afis_tabel4\">"
	          "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel2\">"
      			"<tr><td align=center>(C) %s</td></tr>"
      			"<tr><td align=center>Size %ld KB</td></tr>"
      		  "</table>"
      "</td>"
     "</tr>"
     "<th colspan=4 bgcolor=#9c9c9c>Photos contained in the album</th>"
     "<tr>"
     "<td colspan=4><br></td>"
     "</tr>"
     "<tr>"
	 , filter_html_code (date_album->categoria), filter_html_code (date_album->nume), data_album, filter_html_code (date_album->autor), date_album->n_poze / 1024);
	 int i=0;
	 for (i=1;i<=date_album->nr_poze;i++)
	 {
		 char text_poza[1000];
		 strcpy (text_poza, "");
		 _ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, i, 0);
		 if (date_poza!=NULL)
		 {
			 sprintf (text_poza, "%s<br><i>(C) %s</i>",
			 (date_poza->nume!=NULL)?date_poza->nume:"", 
			 (date_poza->autor!=NULL)?date_poza->autor:"");
			 ps_photo_free (date_poza);
		 }
		 if (i%4==1) printf ("<tr>");
		 printf (
     "<td width=25%% align=center valign=top>"
     "<table cellspacing=0 cellpadding=0 width=110 border=0>"
     "<tr>"
      "<td width=120 height=85 class=\"afis_poza\" valign=middle align=center><a href=\"/cgi-bin/show.cgi?data=user&album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?myalbum_name=%s&photo_id=%d&x=100&y=75\" border=0 height=75 width=100 class=\"afis_poza\"></a></td>"
      //"<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     "</tr>"
     "<tr>"
      //"<td colspan=4><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     "</tr>"
     "<tr>"
      "<td colspan=4><center><font class=\"text_normal\">%s<br><br></center></font></td>"
     "</tr>"
	 "</table>"
	 "</td>"
	, album_id, i, album_id, i, text_poza); 
		 if (i%4==0) printf ("</tr>");
	 }
	 printf ("</table>");
		ps_album_free (date_album);
	 	if (i%4!=0) printf ("</tr>");
	}
	printf (
    "</td>"
	"</tr>"
	"</table>"
	);
}

void show_user_photo (const char *album_name, const char *photo_id)
{
	printf (
	"<img src=\"/images/wallpaper.jpg\" border=0 align=center><br><br>"
	);
	user_album_toolbar (album_name);
	int id = ps_strtoint (photo_id);
	_ps_album *date_album = ps_load_album (user_album_path (album_name));
	if (date_album!=NULL)
	{
		_ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, id, 0);
		if (date_poza!=NULL)
		{
			printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		  "<th colspan=4 bgcolor=#9c9c9c>Photo Information</th>"
     	  "<tr>"
			"<td width=100%% align=center valign=middle>"
			"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
     		"<tr>"
      		"<td colspan=2 width=50%% align=center>"
		      "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      		    "<tr><td align=center>%s</td></tr>"
			    "<tr><td align=center><b>Album</b> %s - <a href=\"/cgi-bin/show.cgi?data=user&album_name=%s\">%s</a></td></tr>"
      	      "</table>"
      		"</td>"
      		"<td colspan=2 width=50%% align=center>"
	          "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      			"<tr><td align=center>(C) %s</td></tr>"
      			"<tr><td align=center>Size %ld KB</td></tr>"
      		  "</table>"
      "</td>"
     "</tr>"
     "<th colspan=4 bgcolor=#9c9c9c>Photo Preview</th>"
     "<tr>"
     "<td colspan=4><br></td>"
     "</tr>"
     "<tr>"
	 , filter_html_code (date_poza->nume), filter_html_code (date_album->categoria), album_name, filter_html_code (date_album->nume), filter_html_code (date_poza->autor), date_poza->n_poza / 1024);
	printf (
	 "<td colspan=4 valign=middle align=center><table border=0 cellpadding=0 cellspacing=7><tr>"
	 );
	 if (id>1) 
		 printf ("<td valign=middle align=center><a href=\"/cgi-bin/show.cgi?data=user&album_name=%s&photo_id=%d\">Previous</a></td>", filter_html_code (album_name), id-1);
	 else printf ("<td valign=middle align=center><font color=#FFFFFF>Previous</font></td>");
			printf (
	 		"<td>"
			"<table cellspacing=0 cellpadding=5 width=400 border=0 class=\"afis_poza\">"
     		"<tr>"
      			"<td><table border=0 cellspacing=0 cellpadding=0 class=\"afis_poza\"><tr><td><a href=\"/cgi-bin/show.cgi?download=1&album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?myalbum_name=%s&photo_id=%d&x=400&y=300\" border=0 height=300 width=400></a></td></tr></table></td>"
     		"</tr>"
     		"<tr>"
      			"<td width=310 height=10> </td>"
     		"</tr>"
//     		"<tr>"
//      			"<td><center><a href=\"/cgi-bin/get_photo.cgi?myalbum_name=%s&photo_id=%d\" target=_blank><font class=\"text_poza\">View Actual Size</font></a> | <a href=\"/cgi-bin/show.cgi?data=user&action=edit&album_name=%s&photo_id=%d\"><font class=\"text_poza\">Edit Photo Data</font></a></center></td>"
//     		"</tr>"
			"<tr><td>"
			, album_name, id, album_name, id);//, album_name, id, album_name, id);
			user_photo_toolbar (album_name, id);
			printf (
			"</td></tr></table></td><br>"
			);
			printf (
    "</td>"
	);
	if (id<date_album->nr_poze) 
		 printf ("<td valign=middle align=center><a href=\"/cgi-bin/show.cgi?data=user&album_name=%s&photo_id=%d\">Next</a></td>", filter_html_code (album_name), id+1);
	 else printf ("<td valign=middle align=center><font color=#FFFFFF>Next</font></td>");
	printf (
	 "</tr></table>"
	"</tr>"
	"</table>"
	);
			ps_photo_free (date_poza);
		}
		ps_album_free (date_album);
	}
	printf (
    "</td>"
	"</tr>"
	"</table>"
	 );
	
}

void save_user_album (const char *album)
{
	getpost ();
	char *album_id = NULL;
	if (album!=NULL) album_id = strdup (album);
	char *name = get_post_var ("album_name");
	int cat_id = ps_strtoint (get_post_var ("album_cat_id"));
	char *category = get_post_var ("album_category");
	char *description = get_post_var ("album_description");
	//printf ("%d<br>", cat_id);
	//debug ("description", description);
	if (name && (cat_id>0 || category))
	{
		_ps_album *date_album = ps_load_album_data (user_album_path (album_id), true);
		long dim3;
		char *date = ps_pack_album (date_album, dim3);
		if (date!=NULL) free (date);
			if (dim3<0) dim3=0;
		if (date_album==NULL)
		{
			char fisier2[1000];
			int gasit=false;
			int i=1;
			int se_poate=1;
			do
			{
				sprintf (fisier2, "album_%d", i);
				//sprintf (fisier2, "%s", user_album_path (fisier2));
				i++;
				_ps_album *date_album = ps_load_album_data (user_album_path (fisier2), false);
				if (date_album==NULL) gasit = true;
					else ps_album_free (date_album);
			} while (!gasit && i<1000);
			if (gasit) 
			{	
				album_id = strdup (fisier2);
				date_album = ps_create_new_album_in_memory ("", "", "", "", "", "");
			}
			else se_poate=0;
		}
		if (date_album!=NULL)
		{
			_ps_user *user = get_user_info (login_name);
			char user_data [100];
			strcpy (user_data, login_name);
			if (user!=NULL) sprintf (user_data, "%s %s", user->first_name, user->last_name);
			ps_modify_album_from_memory (date_album, name, user_data, (cat_id==0)?category:get_category_name (cat_id), description, (char*)ps_inttostr (user->user_id), date_album->parola);
			char dp_[100];
			for (int i=date_album->nr_poze; i>0; i--)
			{
				sprintf (dp_, "dp%d", i);
				const char * dpi = get_post_var (dp_);
				if (dpi!=NULL && (strcasecmp (dpi, "on")==0)) ps_delete_photo_nr_from_album_memory (date_album, i);
			}
			long dim2;
			char * data = ps_pack_album (date_album, dim2);
			if (data!=NULL) free (data);
			if (sum_album_space ()-dim3+dim2<=user->space*1024*1024)
			{
				ps_write_album_from_memory (user_album_path (album_id), date_album);
			}
			ps_album_free (date_album);
		}
	}
	if (album!=NULL) show_user_album (album_id);
		else show_user_albums ();
}

void edit_user_album (const char *album_id)
{
	printf (
	"<img src=\"/images/editalbum.jpg\" border=0 align=center><br><br>"
	);
	user_album_toolbar (album_id);
	_ps_album *date_album = ps_load_album (user_album_path (album_id));
	if (date_album!=NULL)
	{
		char data_album [1000];
		tm *info_data_album = localtime (&date_album->data);
		strftime (data_album, sizeof (data_album), "%A, %B %d, %G", info_data_album);
		printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\"><form action=\"/cgi-bin/show.cgi?data=user&action=save&album_name=%s\" method=POST>"
		  "<th colspan=4 bgcolor=#9c9c9c>Album Information</th>"
     	  "<tr>"
			"<td width=100%% align=center valign=middle>"
			"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
     		"<tr>"
      		"<td colspan=2 width=50%% align=center class=\"afis_tabel4\">"
		      "<table cellspacing=0 cellpadding=2 height=100%% width=100%% class=\"afis_tabel2\">"
				"<tr><td align=center><b>Category</b>&nbsp;&nbsp;&nbsp;"
		, filter_html_code(album_id));
		int gasit = write_album_categories_select ("album_cat_id", date_album->categoria);
		printf (		
		"&nbsp;&nbsp;&nbsp;<input type=text name=\"album_category\" class=\"campuri3\" maxlength=255 value=\"%s\"></td></tr>"
      		    "<tr><td align=center><b>Name</b>&nbsp;&nbsp;&nbsp;<input type=text name=\"album_name\" class=\"campuri3\" maxlength=255 value=\"%s\"></td></tr>"
			    "<tr><td align=center>Created on %s</td></tr>"
      	      "</table>"
      		"</td>"
      		"<td colspan=2 width=50%% align=center class=\"afis_tabel4\">"
	          "<table cellspacing=0 cellpadding=2 height=100%% width=100%% class=\"afis_tabel2\">"
      			"<tr><td align=center>(C) %s</td></tr>"
      			"<tr><td align=center>Size %ld KB</td></tr>"
      		  "</table>"
      "</td>"
     "</tr>"
	 "<th colspan=4 bgcolor=#9c9c9c>Description</th>"
	 "<tr>"
	 	"<td colspan=4 class=\"afis_tabel2\" valign=middle align=center><textarea name=\"album_description\" class=\"campuri3\" rows=5 cols=60 maxlength=32000>%s</textarea></td>"
	 "</tr>"
     "<th colspan=4 bgcolor=#9c9c9c>Photos contained in the album</th>"
     "<tr>"
     "<td colspan=4><br></td>"
     "</tr>"
     "<tr>"
	 , (!gasit)?filter_html_code (date_album->categoria):"" ,filter_html_code (date_album->nume), data_album, filter_html_code (date_album->autor), date_album->n_poze / 1024, date_album->descriere);
	 int i=0;
	 for (i=1;i<=date_album->nr_poze;i++)
	 {
		 char text_poza[1000];
		 strcpy (text_poza, "");
		 _ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, i, 0);
		 if (date_poza!=NULL)
		 {
			 sprintf (text_poza, "%s<br><i>(C) %s</i>",
			 (date_poza->nume!=NULL)?date_poza->nume:"", 
			 (date_poza->autor!=NULL)?date_poza->autor:"");
			 ps_photo_free (date_poza);
		 }
		 if (i%4==1) printf ("<tr>");
		 printf (
     "<td width=25%% align=center valign=top>"
     "<table cellspacing=0 cellpadding=0 width=110 border=0>"
     "<tr>"
      "<td><a href=\"/cgi-bin/show.cgi?data=user&album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?myalbum_name=%s&photo_id=%d&x=100&y=75\" border=0 height=75 width=100></a></td>"
      "<td><img height=75 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
     "</tr>"
     "<tr>"
      "<td colspan=4><img height=10 src=\"/images/jos_m.jpg\" width=110 border=0></td>"
     "</tr>"
     "<tr>"
      "<td colspan=4><center><font class=\"text_normal\">%s<br><input type=checkbox name=\"dp%d\" class=\"camuri2\">Delete</input><br></center></font></td>"
     "</tr>"
	 "</table>"
	 "</td>"
	, album_id, i, album_id, i, text_poza, i); 
		 if (i%4==0) printf ("</tr>");
	 }
	 printf ("</table>");
		ps_album_free (date_album);
	 	if (i%4!=0) printf ("</tr>");
	}
	printf (
    "</td>"
	"</tr>"
	"<th colspan=4 bgcolor=#9c9c9c><input type=submit name=\"buton\" class=\"buton_alb\" value=\"Save Album\"></a></th>"
	"</form></table>"
	);
}

void save_user_photo (const char *album_name, const char *photo_id)
{
	int id = ps_strtoint (photo_id);
	getpost ();
	const char *name = get_post_var ("photo_name");
	const char *description = get_post_var ("photo_description");
	//debug ("description", description);
	if (name)
	{
		_ps_photo *date_poza = ps_load_photo_data_nr_from_album_file (user_album_path (album_name), id, 1);
		if (date_poza!=NULL)
		{
			free (date_poza->nume);
			date_poza->nume = strdup (name);
			free (date_poza->descriere);
			date_poza->descriere = strdup (description?description:"");
			ps_modify_photo_nr_from_album_file (date_poza, user_album_path (album_name), id);
			ps_photo_free (date_poza);
		}
	}
	show_user_photo (album_name, photo_id);
}

void delete_user_photo (const char *album_name, const char *photo_id)
{
	_ps_user *user = get_user_info (login_name);
	if (!user) return;
	int id = ps_strtoint (photo_id);
	if (!published (user->user_id, album_name, id)) ps_delete_photo_nr_from_album_file (user_album_path (album_name), id);
	show_user_album (album_name);
}

void edit_user_photo (const char *album_name, const char *photo_id)
{
	printf (
	"<img src=\"/images/editphoto.jpg\" border=0 align=center><br><br>"
	);
	user_album_toolbar (album_name);
	int id = ps_strtoint (photo_id);
	_ps_album *date_album = ps_load_album (user_album_path (album_name));
	if (date_album!=NULL)
	{
		_ps_photo *date_poza = ps_load_photo_data_nr_from_album_memory (date_album, id, 0);
		if (date_poza!=NULL)
		{
			printf (
		"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
		  "<th colspan=4 bgcolor=#9c9c9c>Photo Information</th>"
     	  "<tr>"
			"<td width=100%% align=center valign=middle>"
			"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
     		"<tr>"
      		"<td colspan=2 width=50%% align=center>"
		      "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      		    "<tr><td align=center>%s</td></tr>"
			    "<tr><td align=center><b>Album</b> %s - <a href=\"/cgi-bin/show.cgi?data=user&album_name=%s\">%s</a></td></tr>"
      	      "</table>"
      		"</td>"
      		"<td colspan=2 width=50%% align=center>"
	          "<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      			"<tr><td align=center>(C) %s</td></tr>"
      			"<tr><td align=center>Size %ld KB</td></tr>"
      		  "</table>"
      "</td>"
     "</tr>"
     "<th colspan=4 bgcolor=#9c9c9c>Photo Preview</th>"
     "<tr>"
     "<td colspan=4><br></td>"
     "</tr>"
     "<tr>"
	 "<td colspan=4 valign=middle align=center>"
	 ,filter_html_code (date_poza->nume), filter_html_code (date_album->categoria), album_name, filter_html_code (date_album->nume), filter_html_code (date_poza->autor), date_poza->n_poza / 1024);
			printf (
			"<table cellspacing=0 cellpadding=5 width=400 border=0 class=\"afis_poza\">"
     		"<tr>"
      			"<td><table border=0 cellspacing=0 cellpadding=0 class=\"afis_poza\"><tr><td><a href=\"/cgi-bin/show.cgi?download=1&album_name=%s&photo_id=%d\"><img src=\"/cgi-bin/get_photo.cgi?myalbum_name=%s&photo_id=%d&x=400&y=300\" border=0 height=300 width=400></a></td></tr></table></td>"
     		"</tr>"
     		"<tr>"
      			"<td width=310 height=10> </td>"
     		"</tr>"
			"<form action=\"/cgi-bin/show.cgi?data=user&action=save&album_name=%s&photo_id=%d\" method=POST>"
			"<tr>"
				"<td align=center valign=top>Photo Information"
					"<table border=0 cellpadding=0 cellspacing=5>"
					"<tr><td align=left valign=top>Name</td><td><input type=text name=\"photo_name\" value=\"%s\" class=\"campuri3\" size=30 maxlength=255></tr>"
					"<tr><td align=left valign=top>Description</td><td><textarea name=\"photo_description\" class=\"campuri3\" maxlength=32000 cols=30 rows=7>%s</textarea></tr>"
					"</table>"
				"</td>"
			"</tr>"
			"<tr>"
      			"<td><center><input type=submit name=\"action\" value=\"Save Photo Data\" class=\"buton_alb\"></center></td>"
     		"</tr>"
			"<tr><td>"
			, album_name, id, album_name, id, album_name, id, filter_html_code(date_poza->nume), date_poza->descriere);
			user_photo_toolbar (album_name, id);
			printf (
			"</td></tr>"
			"</form>"
	 		"</table><br>"
			);
			printf (
    "</td>"
	"</tr>"
	"</table>"
	);
			ps_photo_free (date_poza);
		}
		ps_album_free (date_album);
	}
	printf (
    "</td>"
	"</tr>"
	"</table>"
	 );
}

void save_config_wallpaper ()
{
	_ps_config *config = ps_load_config (user_path ("walppaper.cfg"));
	if (config==NULL) config = ps_load_config (psw_config_default);
	if (config==NULL) return;
	getpost ();
	// wallpaper sizes
	int dx = ps_strtoint (get_post_var ("screen_x"));
	int dy = ps_strtoint (get_post_var ("screen_y"));
	
	int screen_size = ps_strtoint(get_post_var ("screen_sizes"));
	switch (screen_size)
	{
		case 0:
			dx=640;
			dy=480;
			break;
		case 1:
			dx=800;
			dy=600;
			break;
		case 2:
			dx=1024;
			dy=768;
			break;
		case 3:
			dx=1152;
			dy=864;
			break;
		case 4:
			dx=1280;
			dy=960;
			break;
		case 5:
			break;
		default:
			break;
	}
	config->system.scr_width = dx;
	config->system.scr_height = dy;
	
	// wallpaper
	config->wallpaper.dtype = ps_strtoint (get_post_var ("wallpaper_disp"));
	config->wallpaper.dinfo = ps_strtoint (get_post_var ("wallpaper_disp_info"));
	config->wallpaper.border = ps_strtoint (get_post_var ("wallpaper_border"));
	const char *format = get_post_var ("wallpaper_format");
	if (format!=NULL) strcpy (config->wallpaper.format, format);
		else strcpy (config->wallpaper.format, "");
	config->wallpaper.pos.a = ps_strtoint (get_post_var ("wallpaper_pos_auto"));
	config->wallpaper.pos.x = ps_strtoint (get_post_var ("wallpaper_pos_x"));
	config->wallpaper.pos.y = ps_strtoint (get_post_var ("wallpaper_pos_y"));
	config->wallpaper.fcolor.red = ps_strtoint (get_post_var ("wallpaper_fcolor_r"));
	config->wallpaper.fcolor.green = ps_strtoint (get_post_var ("wallpaper_fcolor_g"));
	config->wallpaper.fcolor.blue = ps_strtoint (get_post_var ("wallpaper_fcolor_b"));
	config->wallpaper.fcolor.alpha = ps_strtoint (get_post_var ("wallpaper_fcolor_a"));
	config->wallpaper.fsize = ps_strtoint (get_post_var ("wallpaper_fsize"));		
		
	// calendar
	config->calendar.disp = ps_strtoint (get_post_var ("calendar_disp"));
	config->calendar.mark_date = ps_strtoint (get_post_var ("calendar_mark_date"));
	config->calendar.p_month = ps_strtoint (get_post_var ("calendar_p_month"));
	config->calendar.n_month = ps_strtoint (get_post_var ("calendar_n_month"));
	config->calendar.border = ps_strtoint (get_post_var ("calendar_border"));
	config->calendar.pos.a = ps_strtoint (get_post_var ("calendar_pos_auto"));
	config->calendar.pos.x = ps_strtoint (get_post_var ("calendar_pos_x"));
	config->calendar.pos.y = ps_strtoint (get_post_var ("calendar_pos_y"));
	config->calendar.mcolor.red = ps_strtoint (get_post_var ("calendar_mcolor_r"));
	config->calendar.mcolor.green = ps_strtoint (get_post_var ("calendar_mcolor_g"));
	config->calendar.mcolor.blue = ps_strtoint (get_post_var ("calendar_mcolor_b"));
	config->calendar.mcolor.alpha = ps_strtoint (get_post_var ("calendar_mcolor_a"));
	config->calendar.fcolor.red = ps_strtoint (get_post_var ("calendar_fcolor_r"));
	config->calendar.fcolor.green = ps_strtoint (get_post_var ("calendar_fcolor_g"));
	config->calendar.fcolor.blue = ps_strtoint (get_post_var ("calendar_fcolor_b"));
	config->calendar.fcolor.alpha = ps_strtoint (get_post_var ("calendar_fcolor_a"));
	config->calendar.cmfsize = ps_strtoint (get_post_var ("calendar_cmfsize"));
	config->calendar.omfsize = ps_strtoint (get_post_var ("calendar_omfsize"));
	
	//quotes
	config->quotes.disp = ps_strtoint (get_post_var ("quotes_disp"));
	const char *keywords = get_post_var ("quotes_keywords");
	if (keywords!=NULL) strcpy (config->quotes.keywords, keywords);
		else strcpy (config->quotes.keywords, "");
	config->quotes.only_keywords = ps_strtoint (get_post_var ("quotes_only_keywords"));
	config->quotes.border = ps_strtoint (get_post_var ("quotes_border"));
	config->quotes.pos.a = ps_strtoint (get_post_var ("quotes_pos_auto"));
	config->quotes.pos.x = ps_strtoint (get_post_var ("quotes_pos_x"));
	config->quotes.pos.y = ps_strtoint (get_post_var ("quotes_pos_y"));
	config->quotes.fcolor.red = ps_strtoint (get_post_var ("quotes_fcolor_r"));
	config->quotes.fcolor.green = ps_strtoint (get_post_var ("quotes_fcolor_g"));
	config->quotes.fcolor.blue = ps_strtoint (get_post_var ("quotes_fcolor_b"));
	config->quotes.fcolor.alpha = ps_strtoint (get_post_var ("quotes_fcolor_a"));
	config->quotes.fsize = ps_strtoint (get_post_var ("quotes_fsize"));
		
	ps_save_config (user_file (login_name, "wallpaper.cfg"), *config);
}

void select_number (const char *name, int min, int max, int current)
{
	if (name!=NULL)
	{
		printf ("<select name=\"%s\" class=\"campuri3\">", name);
		for (int i=min;i<=max;i++)
			printf ("<option value=\"%d\"%s>%d</option>", i, (i==current)?" selected":"", i);
		printf ("</select>");
	}
}

void select_list (const char *name, const char *items[], int n, int current)
{
	if (name!=NULL && items!=NULL)
	{
		printf ("<select name=\"%s\" class=\"campuri3\">", name);
		for (int i=0;i<n;i++)
			printf ("<option value=\"%d\"%s>%s</option>", i, (i==current)?" selected":"", items[i]);
		printf ("</select>");
	}
}

void config_wallpaper (const char *album_id, int id)
{
	if (album_id==NULL) return;
	_ps_config *config = ps_load_config (user_file (login_name, "wallpaper.cfg"));
	if (config==NULL) config = ps_load_config (psw_config_default);
	if (config==NULL) return;
	score_add (album_id, id, 1);
	// !!! vine schimbata poza !!!
	printf (
	"<img src=\"/images/wallpaper.jpg\" border=0 align=center><br><br>"
	"<table width=100%% cellspacing=2 cellpadding=0 class=\"afis_tabel4\">"
	"<form action=\"/cgi-bin/show.cgi?data=user&page=configw&action=save&album_name=%s&photo_id=%d\" method=POST>",
	album_id, id);
	
	printf ("<th bgcolor=#9c9c9c>Wallpaper Preview</th>");
	printf (
			"<tr><td valign=middle align=center>"
			"<table cellspacing=0 cellpadding=5 width=600 border=0 class=\"afis_poza\">"
     		"<tr>"
      			"<td><table border=0 cellspacing=0 cellpadding=0 class=\"afis_poza\"><tr><td><a href=\"/cgi-bin/get_photo.cgi?display_type=wallpaper&album_name=%s&photo_id=%d&save=yes\"><img src=\"/cgi-bin/get_photo.cgi?display_type=wallpaper&album_name=%s&photo_id=%d&x=600&y=450\" border=0 width=600 height=450 alt=\"Wallpaper\"></a></td></tr></table></td>"
     		"</tr>"
     		"<tr>"
      			"<td width=310 height=10> </td>"
     		"</tr>"
     		"<tr>"
      		"<td><center><a href=\"/cgi-bin/get_photo.cgi?display_type=wallpaper&album_name=%s&photo_id=%d&save=yes\"><font class=\"text_poza\">Save Wallpaper</font></a> | <a href=\"/cgi-bin/show.cgi?album_name=%s\"><font class=\"text_poza\">Choose Photo</font></a></center></td>"
     		"</tr>"
	 		"</table><br>"
			"</td></tr>"
			,album_id, id, album_id, id, album_id, id, album_id);
	
	// wallpaper
	printf ("<th bgcolor=#9c9c9c>Wallpaper Settings</th>");
	printf (
	"<tr>"
		"<td valign=top align=left>Wallpaper Size&nbsp;&nbsp;&nbsp;");
		const char *screen_sizes[6] = {__("640 x 480"), __("800 x 600"), __("1024 x 768"), __("1152 x 864"), __("1280 x 960"), __("Custom Size")};
		int scr=5;
		for (int i=0;(i<6 && scr==5);i++)
		{
			char s[100];
			sprintf (s, "%d x %d", config->system.scr_width, config->system.scr_height);
			if (strcmp (s, screen_sizes[i])==0) scr=i;
		}
		select_list ("screen_sizes", screen_sizes, 6, scr);
		printf (
		"</td>"
	"</tr>");
	printf (
	"<tr>"
		"<td valign=top align=left>Custom wallpaper size&nbsp;&nbsp;&nbsp;"
			"<input type=text name=screen_x maxlength=4 value=\"%d\" size=4 class=\"campuri3\"> pixels width and "
			"<input type=text name=screen_y maxlength=4 value=\"%d\" size=4 class=\"campuri3\"> pixels height"
		"</td>"
	"</tr>",
	config->system.scr_width, config->system.scr_height);
	printf (
	"<tr>"
		"<td valign=top align=left>Wallpaper display type&nbsp;&nbsp;&nbsp;");
		const char *display_types[6] = {__("Proportional Resize"), __("Shrink Only"), __("Enlarge Only"), __("Stretch"), __("Center"), __("Tile")};
		select_list ("wallpaper_disp", display_types, 6, config->wallpaper.dtype);
		printf (
		"</td>"
	"</tr>");
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"wallpaper_disp_info\" %s class=\"campuri3\">Display photo's information</input></td>"
	"</tr>",
	config->wallpaper.dinfo?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left>Photo Information Format (\"%%n\"-name, \"%%a\"-author, \"\\n\"-new line)&nbsp;&nbsp;&nbsp;"
			"<input type=text name=\"wallpaper_format\" value=\"%s\" maxlength=255 class=\"campuri3\">"
		"</td>"
	"</tr>",
	filter_html_code (config->wallpaper.format));
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"wallpaper_border\" %s class=\"campuri3\">Draw a border around the photo's information</input></td>"
	"</tr>",
	config->wallpaper.border?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"wallpaper_pos_auto\" %s class=\"campuri3\">Use default position</input></td>"
	"</tr>",
	config->wallpaper.pos.a?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left>Photo Information Position&nbsp;&nbsp;&nbsp;"
			"<input type=text name=wallpaper_pos_x maxlength=3 value=\"%d\" size=3 class=\"campuri3\"> pixels left and "
			"<input type=text name=wallpaper_pos_y maxlength=3 value=\"%d\" size=3 class=\"campuri3\"> pixels top"
		"</td>"
	"</tr>",
	config->wallpaper.pos.x, config->wallpaper.pos.y);
	printf (
	"<tr>"
		"<td valign=top align=left>Photo Information Color&nbsp;&nbsp;&nbsp;");
		printf ("Red ");select_number ("wallpaper_fcolor_r", 0, 255, config->wallpaper.fcolor.red);
		printf (" Green ");select_number ("wallpaper_fcolor_g", 0, 255, config->wallpaper.fcolor.green);
		printf (" Blue ");select_number ("wallpaper_fcolor_b", 0, 255, config->wallpaper.fcolor.blue);
		printf (" Transparency ");select_number ("wallpaper_fcolor_a", 0, 255, config->wallpaper.fcolor.alpha);
	printf("</td></tr>");
	printf (
	"<tr>"
		"<td valign=top align=left>Photo Information Text Size&nbsp;&nbsp;&nbsp;");
		select_number ("wallpaper_fsize", 0, 30, config->wallpaper.fsize);
	printf("</td></tr>");
	
	// calendar
	printf ("<th bgcolor=#9c9c9c>Calendar Settings</th>");
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"calendar_disp\" %s class=\"campuri3\">Display calendar</input></td>"
	"</tr>",
	config->calendar.disp?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"calendar_mark_date\" %s class=\"campuri3\">Mark current date</input></td>"
	"</tr>",
	config->calendar.mark_date?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"calendar_border\" %s class=\"campuri3\">Draw a border around the calendar</input></td>"
	"</tr>",
	config->calendar.border?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left>Number of past months&nbsp;&nbsp;&nbsp;");
		select_number ("calendar_p_month", 0, 6, config->calendar.p_month);
	printf("</td></tr>");
	printf (
	"<tr>"
		"<td valign=top align=left>Number of futere months&nbsp;&nbsp;&nbsp;");
		select_number ("calendar_n_month", 0, 6, config->calendar.n_month);
	printf("</td></tr>");
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"calendar_pos_auto\" %s class=\"campuri3\">Use default position</input></td>"
	"</tr>",
	config->calendar.pos.a?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left>Calendar Position&nbsp;&nbsp;&nbsp;"
			"<input type=text name=calendar_pos_x maxlength=3 value=\"%d\" size=3 class=\"campuri3\"> pixels left and "
			"<input type=text name=calendar_pos_y maxlength=3 value=\"%d\" size=3 class=\"campuri3\"> pixels top"
		"</td>"
	"</tr>",
	config->calendar.pos.x, config->calendar.pos.y);
	printf (
	"<tr>"
		"<td valign=top align=left>Marking Color&nbsp;&nbsp;&nbsp;");
		printf ("Red ");select_number ("calendar_mcolor_r", 0, 255, config->calendar.mcolor.red);
		printf (" Green ");select_number ("calendar_mcolor_g", 0, 255, config->calendar.mcolor.green);
		printf (" Blue ");select_number ("calendar_mcolor_b", 0, 255, config->calendar.mcolor.blue);
		printf (" Transparency ");select_number ("calendar_mcolor_a", 0, 255, config->calendar.mcolor.alpha);
	printf("</td></tr>");
	printf (
	"<tr>"
		"<td valign=top align=left>Calendar Color&nbsp;&nbsp;&nbsp;");
		printf ("Red ");select_number ("calendar_fcolor_r", 0, 255, config->calendar.fcolor.red);
		printf (" Green ");select_number ("calendar_fcolor_g", 0, 255, config->calendar.fcolor.green);
		printf (" Blue ");select_number ("calendar_fcolor_b", 0, 255, config->calendar.fcolor.blue);
		printf (" Transparency ");select_number ("calendar_fcolor_a", 0, 255, config->calendar.fcolor.alpha);
	printf("</td></tr>");
	printf (
	"<tr>"
		"<td valign=top align=left>Current Month Text Size&nbsp;&nbsp;&nbsp;");
		select_number ("calendar_cmfsize", 0, 30, config->calendar.cmfsize);
	printf("</td></tr>");
	printf (
	"<tr>"
		"<td valign=top align=left>Other Months Text Size&nbsp;&nbsp;&nbsp;");
		select_number ("calendar_omfsize", 0, 30, config->calendar.omfsize);
	printf("</td></tr>");
	
	//quotes
	printf ("<th bgcolor=#9c9c9c>Quotes Settings</th>");
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"quotes_disp\" %s class=\"campuri3\">Display quotes</input></td>"
	"</tr>",
	config->quotes.disp?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left>Keywords &nbsp;&nbsp;&nbsp;"
			"<input type=text name=\"quotes_keywords\" value=\"%s\" maxlength=255 class=\"campuri3\">"
		"</td>"
	"</tr>",
	filter_html_code (config->quotes.keywords));
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"quotes_only_keywords\" %s class=\"campuri3\">Use only quotes that match keywords</input></td>"
	"</tr>",
	config->quotes.only_keywords?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"quotes_border\" %s class=\"campuri3\">Draw a border around the quote</input></td>"
	"</tr>",
	config->quotes.border?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left><input type=checkbox name=\"quotes_pos_auto\" %s class=\"campuri3\">Use default position</input></td>"
	"</tr>",
	config->quotes.pos.a?"checked":"");
	printf (
	"<tr>"
		"<td valign=top align=left>Quotes Position&nbsp;&nbsp;&nbsp;"
			"<input type=text name=quotes_pos_x maxlength=3 value=\"%d\" size=3 class=\"campuri3\"> pixels left and "
			"<input type=text name=quotes_pos_y maxlength=3 value=\"%d\" size=3 class=\"campuri3\"> pixels top"
		"</td>"
	"</tr>",
	config->quotes.pos.x, config->quotes.pos.y);
	printf (
	"<tr>"
		"<td valign=top align=left>Quotes Color&nbsp;&nbsp;&nbsp;");
		printf ("Red ");select_number ("quotes_fcolor_r", 0, 255, config->quotes.fcolor.red);
		printf (" Green ");select_number ("quotes_fcolor_g", 0, 255, config->quotes.fcolor.green);
		printf (" Blue ");select_number ("quotes_fcolor_b", 0, 255, config->quotes.fcolor.blue);
		printf (" Transparency ");select_number ("quotes_fcolor_a", 0, 255, config->quotes.fcolor.alpha);
	printf("</td></tr>");
	printf (
	"<tr>"
		"<td valign=top align=left>Quotes Text Size&nbsp;&nbsp;&nbsp;");
		select_number ("quotes_fsize", 0, 30, config->quotes.fsize);
	printf("</td></tr>");
	
	printf ("<th bgcolor=#9c9c9c><input type=submit name=buton class=\"buton_alb\" value=\"Apply Settings\"</th>");
	
	printf (
	"</form>"
	"</table>"
	);
	
}

void publish_user_photo (const char *album_id, const char *photo_id)
{
	int id = ps_strtoint (photo_id);
	_ps_user *user = get_user_info (login_name);
	if (user)
	{
		if (publish (user->user_id, album_id, id)) printf ("Error<br>");
			else printf ("OK<br>");
	}
	else printf ("Error<br>");
}

int main()
{
	db_init ();
	//update_db ();
	if (!session_init()) session_new();
	login_name = session_var_get ("login_name");
	getquery ();
	const char *data = get_query_var ("data");
	const char *download = get_query_var ("download");
	const char *album_name = get_query_var ("album_name");
	const char *photo_id = get_query_var ("photo_id");
	const int cat_id = ps_strtoint (get_query_var ("cat_id"));
	const char *search = get_query_var ("search");
	const char *all_keywords = get_query_var ("all_keywords");
	char *s_name = get_query_var ("s_name");
	const char *s_author = get_query_var ("s_author");
	const char *s_description = get_query_var ("s_description");
	const char *page = get_query_var ("page");
	const char *action = get_query_var ("action");
	int skips = ps_strtoint (get_query_var ("skips"));
	if (data==NULL && download!=NULL)
	{
		if (strcmp (download, "1")==0)
			if (photo_id!=NULL) download_photo (album_name, photo_id);
			else download_album (album_name);
		if (strcmp (download, "2")==0)
			if (photo_id!=NULL) download_image (album_name, photo_id);
	}
	content ("text/html");
	printf ("<html>");
// head
	printf ("<head>");
	style ("/css/ps_style.css");
	printf ("</head>");
	main_display_init ();
	printf ("<td width=720 align=center valign=top>");
	if (data==NULL)
	{
		if (page!=NULL && strcmp (page, "configw")==0)
		{
			show_html ("wallpaper");
		}
		else
		if (album_name!=NULL && photo_id!=NULL)
		{
			show_photo (album_name, photo_id);
		}
		else
		if (album_name!=NULL) show_album (album_name);
		else
		if (cat_id>0) show_categorie (cat_id);
		else
		if (search!=NULL) 
		{
			//int fl = 0;
			photo_index (search, skips, all_keywords, s_name, s_author, s_description);
		}
		else
		if (page!=NULL && strcmp (page, "search")==0) 
		{
			printf (
			"<img src=\"/images/search.jpg\" border=0 align=center><br><br>"
			);
			search_page (search, all_keywords, s_name, s_author, s_description);
		}
		else
		if (page!=NULL && strcmp (page, "wallpapers")==0)
		{
			photo_index (NULL, 0, NULL, NULL, NULL, NULL);
		}
		else show_albums ();
	}
	else
	if (strcmp (data, "user")==0)
	{
		if (login_name)
		{
			sprintf (psw_user_album_path, "%s/%s/albums", psw_users_path, login_name);
			if (page!=NULL && strcmp (page, "new_album")==0)
			{
				if (action!=NULL && strcmp (action, "save")==0)
				{
					save_user_album (NULL);
				}
				else
				create_album_form ();
			}
			else
			if (page!=NULL && strcmp (page, "delete")==0)
			{
				if (album_name!=NULL && photo_id!=NULL)
				{
				}
				else if (album_name!=NULL)
				{
					getpost ();
					char *buton = get_post_var ("buton");
					if (buton!=NULL)
					{
						//printf ("%s<br>", buton);
						if (strcmp (buton, "YES")==0)
						{
							delete_album (album_name);
							show_user_albums ();
						}
						else show_user_album (album_name);
					}
					else
					delete_album_form (album_name);
				}
				else show_user_albums ();
			}
			else
			if (page!=NULL && strcmp (page, "new_photos")==0 && album_name!=NULL)
			{
				if (action!=NULL && strcmp (action, "upload")==0)
				{
					upload_photos (album_name);
				}
				else
				new_photo_from (album_name);
			}
			else
			if (page!=NULL && strcmp (page, "configw")==0)
			{
				if (action!=NULL && strcmp (action, "save")==0)
					save_config_wallpaper ();
				config_wallpaper (album_name, ps_strtoint (photo_id));
			}
			else
			if (album_name!=NULL && photo_id!=NULL && action!=NULL && strcmp (action, "edit")==0)
			{
				edit_user_photo (album_name, photo_id);
			}
			else
			if (album_name!=NULL && photo_id!=NULL && action!=NULL && strcmp (action, "save")==0)
			{
				save_user_photo (album_name, photo_id);
			}
			else
			if (album_name!=NULL && photo_id!=NULL && action!=NULL && strcmp (action, "delete")==0)
			{
				delete_user_photo (album_name, photo_id);
			}
			else
			if (album_name!=NULL && photo_id!=NULL && action!=NULL && strcmp (action, "publish")==0)
			{
				publish_user_photo (album_name, photo_id);
			}
			else
			if (album_name!=NULL && photo_id==NULL && action!=NULL && strcmp (action, "edit")==0)
			{
				edit_user_album (album_name);
			}
			else
			if (album_name!=NULL && photo_id==NULL && action!=NULL && strcmp (action, "save")==0)
			{
				save_user_album (album_name);
			}
			else
			if (album_name!=NULL && photo_id==NULL && action!=NULL && strcmp (action, "publish")==0)
			{
				publish_user_photo (album_name, 0);
			}
			else
			if (album_name!=NULL && photo_id!=NULL)
			{
				show_user_photo (album_name, photo_id);
			}
			else
			if (album_name!=NULL) 
			{	
				show_user_album (album_name);
			}
			else
			show_user_albums ();
		}
	}
	
	printf ("</td>");		
	
	write_vertical_line ();
	write_right_start ();
	write_album_categories ();
	write_login ();
	write_download ();
	write_right_end ();
	main_display_deinit ();
	main_display_close ();
	db_close ();
	return 0;
}
