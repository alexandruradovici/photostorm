
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <crypt.h>
#include <zlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "userdb.h"
#include "data.h"
#include "cgi_cpp.h"
#include "misc.h"
#include "quotes.h"
#include "htmls.h"
#include "gdlib/gd.h"
#include <time.h>

const char *months[12] = { 
		                    		__("January"), __("February"), __("March"), __("April"), 
						    		__("May"), __("June"), __("July"), __("August"), 
						    	    __("September"), __("October"), __("Novenber"),
									__("December")
		                  		  };

enum
{
	err_nr_code,
	err_exists,
	err_username,
	err_password,
	err_email,
	err_first_name,
	err_last_name,
	err_birthdate,
	err_vars,
	err_server
};
								  
void print_error ()
{
	content ("text/html");
	printf ("Error, cookies not supported");
}



void useradd_form (_ps_user *user, int e);

static _ps_user *current_user;
static int error;

_ps_user * ps_create_user (const char *username, const char *password, const char *password2, 
						   const char *email, const char *first_name, const char *last_name, int day,
						   int month, int year, const char *country, const char *city, 
						   const char *ocupation, const char *website, const char *description)
{
	_ps_user *result = (_ps_user*)malloc (sizeof (_ps_user));
	if (result!=NULL)
	{
		result->user_id=-1;
		// username
		if (username!=NULL) 
		{
			strncpy (result->username, ps_stronly (username, CHARS), USER_MAX_L);
			result->username[USER_MAX_L]='\0';
		} else strcpy (result->username, "");
		// password
		if (password!=NULL && password2!=NULL && strlen(password) > PASSWORD_MIN_L && strcmp(password, password2)==0) 
		{
			char *parola = crypt (password, "$1$PS_User$");
			parola = &parola[11];
			strncpy (result->password, parola, PASSWORD_MAX_L);
			result->password[PASSWORD_MAX_L]='\0';
		} else strcpy (result->password, "");
		// email
		if (email!=NULL) 
		{
			char *name = strtok (strdup(email), "@");
			char *domain = strtok (NULL, "\0");
			if (name==NULL || domain==NULL) strcpy (result->email, "");
			else
			{
				strncpy (result->email, email, EMAIL_MAX_L);
				result->email[EMAIL_MAX_L]='\0';
			}
			//if (name!=NULL) free (name);
			//if (domain!=NULL) free (domain);
		} else strcpy (result->email, "");
		// first_name
		if (first_name!=NULL) 
		{
			strncpy (result->first_name, ps_stronly (first_name, CHARS_SPACE), FNAME_MAX_L);
			result->first_name[FNAME_MAX_L]='\0';
		} else strcpy (result->first_name, "");
		// last_name
		if (last_name!=NULL) 
		{
			strncpy (result->last_name, ps_stronly(last_name, CHARS_SPACE), LNAME_MAX_L);
			result->last_name[LNAME_MAX_L]='\0';
		} else strcpy (result->last_name, "");
		// date
		if (year > 1900 && month>0 && month<=12) 
		{
			if (month == 1 || month==3 || month == 5 || month==7 || month==8 || month == 10 || month == 12)
				if (day<0 || day>31) day = 0;
			if (month == 2)
				if (day<0 || day>29) day=0;
			if (month == 4 || month==6 || month == 9 || month==11)
				if (day<0 || day>30) day = 0;
			sprintf (result->birthdate, "%d/%d/%d", year, month, day);
		} else strcpy (result->birthdate, "1900/1/1");
		// country
		if (country!=NULL) 
		{
			strncpy (result->country, country, COUNTRY_MAX_L);
			result->country[COUNTRY_MAX_L]='\0';
		} else strcpy (result->country, "");
		// city
		if (city!=NULL) 
		{
			strncpy (result->city, city, CITY_MAX_L);
			result->city[CITY_MAX_L]='\0';
		} else strcpy (result->city, "");
		// ocupation
		if (ocupation!=NULL) 
		{
			strncpy (result->ocupation, ocupation, OCCUP_MAX_L);
			result->ocupation[OCCUP_MAX_L]='\0';
		} else strcpy (result->ocupation, "");
		// website
		if (website!=NULL) 
		{
			strncpy (result->website, website, WEBSITE_MAX_L);
			result->website[WEBSITE_MAX_L]='\0';
		} else strcpy (result->website, "");
		// description
		if (description!=NULL) 
		{
			strncpy (result->description, description, DESCRIPTION_MAX_L);
			result->description[DESCRIPTION_MAX_L]='\0';
		} else strcpy (result->description, "");
		result->credits = INIT_USER_CREDITS;
		result->space = INIT_USER_SPACE;
	} else return NULL;
	return result;
}

void login_page ()
{
	printf (
	"<center>"
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/login2.jpg\" border=0 align=center><br><br>"
	"<center>"
	"<form action=\"/cgi-bin/users.cgi?action=login\" method=\"POST\">"
	"<table cellspacing=0 cellpadding=0 width=300 class=\"afis_tabel4\">"
    "<th colspan=3 bgcolor=#9c9c9c><font color=red> There was an error while trying to login. Please try again.</font></th>"
    "<tr>"
     "<td colspan=2><br></td>"
     "</tr>"
	 "<tr height=25>"
      "<td width=30%% align=left>Username</td>"
      "<td width=70%% align=left><input type=text name=\"username\" class=\"campuri3\" value=\"\" size=15 maxlength=20></td>"
     "</tr>"
	 "<tr height=25>"
      "<td width=30%% align=left>Password</td>"
      "<td width=70%% align=left><input type=password name=\"password\" class=\"campuri3\" value=\"\" size=15 maxlength=30></td>"
     "</tr>"
	 "<tr height=25>"
      "<td colspan=2 align=right><input type=image src=\"/images/signin2.jpg\"></td>"
     "</tr>"
	"</table>"
	"</form>"
	"</center>"
	"</td>"
	);
}

void user_page ()
{
	_ps_user *user = get_user_info (session_var_get ("login_name"));
	if (user==NULL)
	{
		useradd_form (NULL, 0);
		return;
	}
	time_t t;
	time (&t);
	tm *info_data = localtime (&t);
	int zi, luna, an;
	sscanf (user->birthdate, "%d-%d-%d", &an, &luna, &zi);
	int varsta = 1900+info_data->tm_year-an;
	if (luna-1 > info_data->tm_mon) varsta--;
		else if (luna-1 == info_data->tm_mon)
			if (zi < info_data->tm_mday) varsta--;
	printf (
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/upage.jpg\" border=0 align=center><br><br>"
	"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
     "<th colspan=3 bgcolor=#9c9c9c>User Information</th>"
     "<tr>"
      "<td rowspan=10 width=30%% align=centre valign=middle>"
     "<center>"
     "<table cellspacing=0 cellpadding=0 width=110 height=125 border=0 bgcolor=#ababab class=\"afis_tabel\">"
     "<tr>"
      "<td><img height=118 src=\"/images/mypic.jpg\" width=101 border=0></td>"
      "<td><img height=118 src=\"/images/mypdr.jpg\" width=9 border=0></td>"
     "</tr>"
     "<tr>"
      "<td colspan=2><img height=7 src=\"/images/mypjos.jpg\" width=\"110\" border=0></td>"
     "</tr>"
     "</table>"
     "</center>"
	"</td>"
	"<td width=70%% align=center valign=middle>"
	"<table cellspacing=0 cellpadding=0 width=100%%  class=\"afis_tabel4\">"
      "</td>"
      "<td width=20%% align=left>First Name</td>"
      "<td width=50%% align=left>%s</td>"
     "</tr>"
     "<tr>"
      "<td width=20%% align=left>Last Name</td>"
      "<td width=50%% align=left>%s</td>"
     "</tr>"
     "<tr>"
      "<td width=20%% align=left>Username</td>"
      "<td width=50%% align=left>%s</td>"
     "</tr>"
     "<tr>"
      "<td width=20%% align=left>Age</td>"
      "<td width=50%% align=left>%d</td>"
     "</tr>"
     "<tr>"
      "<td width=20%% align=left>Location</td>"
      "<td width=50%% align=left>%s, %s</td>"
     "</tr>"
     "<tr>"
      "<td width=20%% align=left>Occupation</td>"
      "<td width=50%% align=left>%s</td>"
     "</tr>"
     "<tr>"
      "<td width=20%% align=left>Description</td>"
      "<td width=50%% align=left>%s</td>"
     "</tr>"
     "<tr>"
      "<td width=20%% align=left>E-mail</td>"
      "<td width=50%% align=left>%s</td>"
     "</tr>"
     "<tr>"
      "<td width=20%% align=left>Website</td>"
      "<td width=50%% align=left>%s</td>"
     "</tr>"
	 "<tr>"
      "<td width=20%% align=left>Credits</td>"
      "<td width=50%% align=left>%d</td>"
     "</tr>"
	 "<tr>"
      "<td width=20%% align=left>Space</td>"
      "<td width=50%% align=left>%d MB</td>"
     "</tr>"
	"</table>"
	"</td>"
	"</tr>"
	"</table>"
	"<br>"
	"<table cellspacing=6 cellpadding=3 width=100%% border=0 align=center>"
	"<tr>"
	"<td valign=top align=center>"
	"<table cellspacing=0 cellpadding=0 width=700 border=0 bgcolor=#ababab class=\"afis_tabel2\">"
	"<tr>"
	"<td colspan=7>"
	"<hr class=\"afis_tabel4\">"
	"</td>"
	"</tr>"
     "<tr>"
      "<td width=14%% align=center>"
		"<center><a href=\"/cgi-bin/messages.cgi\"><img src=/images/messages.jpg border=0></a></center>"
      	"</td>"
      	"<td width=17%% align=center>"
		"<center><a href=\"/cgi-bin/show.cgi?data=user\"><img src=/images/myalbums.jpg border=0></a></center>"
      "</td>"
      "<td width=17%% align=center>"
		"<center><a href=\"/cgi-bin/users.cgi?action=edit\"><img src=/images/editp.jpg border=0></a></center>"
      "</td>"
      "<td width=11%% align=center>"
		"<center><a href=\"/cgi-bin/msgstorm.cgi\"><img src=/images/forum.jpg border=0></a></center>"
      "</td>"
      "<!--<td width=11%% align=center>"
		"<center><a href=\"/cgi-bin/upload.cgi\"><img src=/images/upload.jpg border=0></a></center>"
      "</td>"
      "<td width=17%% align=center>"
		"<center><a href=\"/cgi-bin/users.cgi?action=list\"><img src=/images/mlist.jpg border=0></a></center>"
      "</td>-->"
      "<td width=11%% align=center>"
		"<center><a href=\"/cgi-bin/users.cgi?action=logout\"><img src=/images/logout.jpg border=0></a></center>"
	  "</td>"
     "</tr>"
	"<tr valign=top>"
	"<td colspan=7 valign=top>"
	"<hr class=\"afis_tabel4\">"
	"</td>"
	"</tr>"
	"</table>"
	"</td>"
	"</tr>"
	"</table>"
	,filter_html_code(user->first_name) ,filter_html_code(user->last_name), filter_html_code(user->username), varsta
	,filter_html_code(user->city), filter_html_code(user->country), filter_html_code(user->ocupation)
	,filter_html_code(user->description),filter_html_code(user->email), filter_html_code(user->website)
	,user->credits, user->space);
}
 
void useradd_form (_ps_user *user, int e)
{
	if (user==NULL) user = ps_create_user (NULL, NULL, NULL, NULL, NULL, NULL,
										   0, 0, 0, NULL, NULL, NULL,
										   NULL, NULL);
	int zi, luna, an;
	sscanf (user->birthdate, "%d/%d/%d", &zi, &luna, &an);
	time_t timp;
	time (&timp);
	tm *info_data = localtime (&timp);
	printf (
	"<center>"
	"<td width=720 align=center valign=top>"
	"<img src=\"/images/createnewa.jpg\" border=0 align=center><br><br>"
	"<center>"
	"<form action=\"/cgi-bin/users.cgi?action=useradd\" method=\"POST\">"
	"<table cellspacing=0 cellpadding=0 width=500 class=\"afis_tabel4\">"
	);
	if (e!=0)
	{
		printf (
		"<th colspan=3 bgcolor=#9c9c9c><font color=red>There are some errors</font></th>"
    	"<tr>"
     	"<td colspan=2>"
		"<ul>"
		);
		if (e&(1<<err_exists)) printf ("<li>We are sorry, but the username that you have chosen is not available.</li>");	
		if (e&(1<<err_username)) printf ("<li>Please enter a username that has at least one charater.</li>");
		if (e&(1<<err_password)) printf ("<li>The password you typed is not valid. Please make sure that the passwords match and that they are at least four charaters long.</li>");
		if (e&(1<<err_email)) printf ("<li>You have typed an invalid email address.</li>");	
		if (e&(1<<err_first_name)) printf ("<li>Plaese type your fist name.</li>");	
		if (e&(1<<err_last_name)) printf ("<li>Please type your last name</li>");
		if (e&(1<<err_birthdate)) printf ("<li>Please fill in the birthdate data correctly.</li>");	
		if (e&(1<<err_nr_code)) printf ("<li>The number that you have typed is not correct. Please try it again.</li>");
		printf (
		"</ul>"
		"</td>"
     	"</tr>"
		);
	}
	printf (
    "<th colspan=3 bgcolor=#9c9c9c>User Information</th>"
    "<tr>"
     "<td colspan=2><br></td>"
     "</tr>"
	 "<tr height=25>"
      "<td width=30%% align=left>Username</td>"
      "<td width=70%% align=left><input type=text name=\"username\" class=\"campuri3\" value=\"%s\" size=15 maxlength=20></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Password</td>"
      "<td width=70%% align=left><input type=password name=\"password\" class=\"campuri3\" value=\"\" size=20 maxlength=30></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Confirm Password</td>"
      "<td width=70%% align=left><input type=password name=\"password2\" class=\"campuri3\" value=\"\" size=20 maxlength=30></td>"
     "</tr>"
	 "<tr height=25>"
      "<td width=30%% align=left>E-mail</td>"
      "<td width=70%% align=left><input type=text name=\"email\" class=\"campuri3\" value=\"%s\" size=20 250></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>First Name</td>"
      "<td width=70%% align=left><input type=text name=\"first_name\" class=\"campuri3\" value=\"%s\" size=15 maxlength=30></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Last Name</td>"
      "<td width=70%% align=left><input type=text name=\"last_name\" class=\"campuri3\" value=\"%s\" size=15 maxlength=30></td>"
     "</tr>"
     "<th colspan=3 bgcolor=#9c9c9c>Detailed Information</th>"
     "<tr>"
     "<td colspan=2><br></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Date of birth</td>"
      "<td width=70%% align=left><select name=\"day\" class=\"campuri3\">"
	  , user->username, user->email, user->first_name, user->last_name);
	  	for (int day=1;day<=31;day++) printf ("<option %s value=\"%d\">%d</option>", (zi==day)?"selected=true":"", day, day);
	  printf (
	    "</select>&nbsp;/&nbsp;<select name=\"month\" class=\"campuri3\">"
	  );
		for (int month=0;month<12;month++) printf ("<option %s value=\"%d\">%s</option>", (luna==1+month)?"selected=true":"", month+1, months[month]);
	  printf (
	   "</select>&nbsp;/&nbsp;<select name=year class=\"campuri3\">"
	  );
		for (int year=info_data->tm_year;year>=0;year--) printf ("<option %s value=\"%d\">%d</option>", (an==1900+year)?"selected=true":"", 1900+year, 1900+year);
		printf (
	 "</select></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Country</td>"
      "<td width=70%% align=left><input type=text name=\"country\" class=\"campuri3\" value=\"%s\" size=15></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>City</td>"
      "<td width=70%% align=left><input type=text name=\"city\" class=\"campuri3\" value=\"%s\" size=15></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Occupation</td>"
      "<td width=70%% align=left><input type=text name=\"ocupation\" class=\"campuri3\" value=\"%s\" size=15></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Website</td>"
      "<td width=70%% align=left><input type=text name=\"website\" class=\"campuri3\" value=\"%s\" size=25></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Short Description</td>"
      "<td width=70%% align=left><textarea name=\"description\" class=\"campuri3\" cols=40 rows=7 maxlength=255>%s</textarea></td>"
     "</tr>"
     "<th colspan=3 bgcolor=#9c9c9c>Status</th>"
     "<tr>"
     "<td colspan=2><br></td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Credits </td>"
      "<td width=70%% align=left>You get 30 credits for a new account </td>"
     "</tr>"
     "<tr height=25>"
      "<td width=30%% align=left>Space </td>"
      "<td width=70%% align=left>2 mb: your personal space for photos (can be maximize through credits see Help)  </td>"
     "</tr>"
	 "<th colspan=3 bgcolor=#9c9c9c>Security</th>"
     "<tr>"
     "<td colspan=2><br></td>"
     "</tr>"
     "<tr height=25>"
      "<td colspan=2 align=center><img src=\"/cgi-bin/get_photo.cgi?code=generate\" width=100 height=35></td>"
	 "</tr>"
	 "<tr height=25><td colspan=2>"
	 "<table width=100%% border=0 class=\"afis_tabel2\"><tr>"
	  "<td width=70%% align=left>Please type the following number in the editbox </td>"
 	  "<td width=30%% align=left><input type=text name=\"signup_code\" class=\"campuri3\" value=\"\" size=9 maxlength=7></td>"
	 "</tr></table>"
     "</td></tr>"
	"</table><br>"
	"<br>"
	"<center><input type=image src=\"/images/createacc.jpg\" name=\"button\" value=\"sign_up\" border=0></center>"
	"</form>"
	"</center>"
	"</td>"
	,user->country, user->city, user->ocupation, user->website, user->description);
}

void login_user (const char *username)
{
	if (username!=NULL)
	{
		time_t timp;
		time (&timp);
		session_var_set ("login_name", username);
		session_var_set ("login_time", ps_inttostr (timp));
		char t[1000];
		sprintf (t, "%s/%s", psw_users_path, username);
		mkdir (t, S_IRWXU);
		sprintf (t, "%s/%s/messages", psw_users_path, username);
		mkdir (t, S_IRWXU);
		sprintf (t, "%s/%s/albums", psw_users_path, username);
		mkdir (t, S_IRWXU);
	}
}

int ps_check_user_data (_ps_user *user)
{
	int r = 0;
	if (user!=NULL)
	{
		const char *code = session_var_get ("signup_code");
		const char *user_code = get_post_var ("signup_code");
		if (code!=NULL && user_code!=NULL)
		{
			if (strcmp (code, user_code)!=0) r|=1<<err_nr_code;
		} else r|=1<<err_nr_code;
		if (user_exists (user->username)) r|=1<<err_exists;
		if (strlen (user->username)==0) r|=1<<err_username;
		if (strlen (user->password)==0) r|=1<<err_password;
		if (strlen (user->email)==0) r|=1<<err_email;
		if (strlen (user->first_name)==0) r|=1<<err_first_name;
		if (strlen (user->last_name)==0) r|=1<<err_last_name;
		if (strlen (user->birthdate)==0) r|=1<<err_birthdate;
	} 
	else r|=1<<err_server;
	return r;
}

void clear_user_session_vars ()
{
	session_var_del ("signup_username");
	session_var_del ("signup_password");
	session_var_del ("signup_email");
	session_var_del ("signup_first_name");
	session_var_del ("signup_last_name");
	session_var_del ("signup_birthdate");
	session_var_del ("signup_country");
	session_var_del ("signup_city");
	session_var_del ("signup_ocupation");
	session_var_del ("signup_website");
	session_var_del ("signup_description");
}

int save_user_to_session (_ps_user *user)
{
	int r=1;
	if (user!=NULL)
	{
		session_var_set ("signup_username", user->username);
		session_var_set ("signup_password", user->password);
		session_var_set ("signup_email", user->email);
		session_var_set ("signup_first_name", user->first_name);
		session_var_set ("signup_last_name", user->last_name);
		session_var_set ("signup_birthdate", user->birthdate);
		session_var_set ("signup_country", user->country);
		session_var_set ("signup_city", user->city);
		session_var_set ("signup_ocupation", user->ocupation);
		session_var_set ("signup_website", user->website);
		session_var_set ("signup_description", user->description);
	} else r=0;
	return r;
}

int login (const char *username, const char *password)
{
	int r=0;
	if (username!=NULL && password!=NULL)
	{
		_ps_user *user = get_user_info (username);
		if (user==NULL) return r;
		char *parola = crypt (password, "$1$PS_User$");
		parola = &parola[11];
		if (parola!=NULL)
		{
			if (strcmp (parola, user->password)==0) 
			{	
				login_user (username);
				r=1;
			}
		}
		free (user);
	}
	return r;
}

void logout ()
{
	session_var_del ("login_name");
	session_var_del ("login_time");
}

int useradd ()
{
	error=0;
	getpost ();
	clear_user_session_vars ();
	_ps_user *user = ps_create_user (
		get_post_var("username"),
		get_post_var ("password"),
		get_post_var ("password2"),
		get_post_var ("email"),
		get_post_var("first_name"),
		get_post_var("last_name"),
		ps_strtoint (get_post_var("day")),
		ps_strtoint (get_post_var ("month")),
		ps_strtoint (get_post_var ("year")),
		get_post_var ("country"),
		get_post_var ("city"),
		get_post_var("ocupation"),
		get_post_var ("website"),
		get_post_var ("description")
	);
	current_user=user;
	int e = ps_check_user_data (user);
	if (e==0)
	{
		//save_user_to_session (user);
		user_add (user);
		login (user->username, get_post_var ("password"));
		return 1;
	} 
	else error=e;
	return 0;
}

int main()
{
	/*
		pagina = 0 - sign up
		pagina = -1 - eroare la sign up data
		pagina = 1 - login
		pagina = 2 - login error
	*/
	getquery ();
	db_init ();
	get_user_info ("alex");
	//user_exists ("dasd");
	int pagina = 0;
	if (!session_init()) if (!session_new()) 
	{		
		print_error();
		return 0;
	}
	const char *action = get_query_var ("action");
	if (action!=NULL)
	{
		if (strcmp (action, "signup")==0) pagina = 1;
		else
		if (strcmp (action, "useradd")==0)
		{
			if (!useradd ()) pagina=-1;
				else pagina=0;
		}
		else
		if (strcmp (action, "login")==0)
		{
			logout ();
			getpost ();
			if (!login (get_post_var ("username"), get_post_var ("password"))) pagina = 2;
				else pagina = 0;
		}
		else
		if (strcmp (action, "logout")==0)
		{
			logout ();
			pagina = 0;
		}
	}
//	if (strcmp (action, "login")==0) login ();
	content ("text/html");
	printf ("<html>");
// head
	printf ("<head>");
	style ("/css/ps_style.css");
	printf ("</head>");
	main_display_init ();
	
	if (pagina==-1) useradd_form (current_user, error);
	if (pagina==0) user_page ();
	if (pagina==1) useradd_form (NULL, 0);
	if (pagina==2) login_page ();
	
	write_vertical_line ();
	write_right_start();
	write_album_categories ();
	write_login ();
	write_download ();
	write_right_end();
	main_display_deinit ();
	main_display_close ();
	db_close ();
	return 0;
}
