
#ifndef _MISC__H
#define _MISC__H

#include <stdio.h>
#include <stdlib.h>

#include "data.h"
#include "photo.h"

void show_html (const char *html_file);
const char * config_path (const char *file);
const char * album_path_ (const char *album);
const char * album_path (const char *album);
const char * categories_path (const char *cat);
const char * categories_path_ (const char *cat);
const char * user_path (const char *user);
const char * user_file (const char *user, const char *fis);
char * font_path (const char *font);
char * strtrim (const char *s_);
char * ps_stronly (const char *s_, const char *chars_);
char * ps_strfilter_filename (char *filename);
char * ps_replace_str (char *s, unsigned long lmax);
char * extract_path (const char *str);
int search_keywords (char *keys_, const char *keywords_);
int search_keywords_ (char *keys_, const char *keywords_);
char *readline (FILE *f);
int ps_strtoint (const char *str);
const char * ps_inttostr (int nr);
_ps_color * ps_strtocolor (const char *str);
const char * ps_colortostr (_ps_color color);
_ps_color * ps_pack_color (int r, int g, int b, int alpha);;

#endif
