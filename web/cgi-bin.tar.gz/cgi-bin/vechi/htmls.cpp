
#include "data.h"
#include "htmls.h"
#include "misc.h"
#include "cgi_cpp.h"
#include "albumdb.h"
#include <string.h>
#include <stdio.h>
#include <dirent.h>

void write_album_categories ()
{
	printf (
	"<table cellspacing=\"0\" cellpadding=\"0\" width=\"230\" height=172 border=0 bgcolor=#ababab class=\"afis_tabel\">"
      "<form action=\"/cgi-bin/users.cgi?action=login\" method=POST>"
      "<tr>"
      	"<td colspan=3><img height=11 src=\"/images/sus_mm.jpg\" width=230 border=0></td>"
      "</tr>"
      "<tr>"
        "<td><img height=100%% src=\"/images/st.jpg\" width=15 border=0></td>"
      	"<td width=200 height=150 align=center>"
        	"<img src=\"/images/categories.jpg\" border=0 valign=top><br><br>"
		 	"<table border=0>"
      		  "<tr><td align=center valign=middle class=\"text_tabel\">"
	);
	int nr = get_categories ();
	_ps_category_list *categorii = get_categories_list ();
	for (int i=0;i<nr;i++) printf ("<a href=\"/cgi-bin/show.cgi?cat_id=%d\">%s</a><br>", categorii[i].cat_id, categorii[i].nume);
	printf (
	"</td></tr>"
			"</table>"
        "</td>"
        "<td><img height=100%% src=\"/images/dr.jpg\" width=15 border=0></td>"
      "</tr>"
      "<tr>"
        "<td colspan=3><img height=11 src=\"/images/jos.jpg\" width=230 border=0></td>"
      "</tr>"
	  "</form>"
	"</table>"
	);
}

void write_right_start ()
{
	printf (
	"<br>"
	"<td rowspan=2 width=* align=center valign=top>"
	);
}

void write_login ()
{
	if (session_var_get ("login_name"))
	{
	printf (
	"<table cellspacing=\"0\" cellpadding=\"0\" width=\"230\" height=172 border=0 bgcolor=#ababab class=\"afis_tabel\">"
      "<form action=\"/cgi-bin/users.cgi?action=login\" method=POST>"
      "<tr>"
      	"<td colspan=3><img height=11 src=\"/images/sus_mm.jpg\" width=230 border=0></td>"
      "</tr>"
      "<tr>"
        "<td><img height=100%% src=\"/images/st.jpg\" width=15 border=0></td>"
      	"<td width=200 height=150 align=center>"
        	"<img src=\"/images/qmenu.jpg\" border=0 valign=top><br><br>"
			   "<a href=/cgi-bin/users.cgi>Home</a><br>"
		 	   "<a href=/cgi-bin/messages.cgi>Messages</a><br>"
      		   "<a href=/cgi-bin/show.cgi?data=user>My Albums</a><br>"
      		   "<a href=/cgi-bin/users.cgi?page=edit_profile>Edit Profile</a><br>"
      		   "<a href=/cgi-bin/msgstorm.cgi>Forum</a><br>"
      		   "<!--<a href=/cgi-bin/users.cgi?action=members>Member list</a><br>-->"
			   "<a href=/cgi-bin/users.cgi?action=logout>Logout</a><br><br>"
        "</td>"
        "<td><img height=100%% src=\"/images/dr.jpg\" width=15 border=0></td>"
      "</tr>"
      "<tr>"
        "<td colspan=3><img height=11 src=\"/images/jos.jpg\" width=230 border=0></td>"
      "</tr>"
	  "</form>"
	"</table>"
	);
	}
	else
	{
	printf (
	"<table cellspacing=\"0\" cellpadding=\"0\" width=\"230\" height=172 border=0 bgcolor=#ababab class=\"afis_tabel\">"
      "<form action=\"/cgi-bin/users.cgi?action=login\" method=POST>"
      "<tr>"
      	"<td colspan=3><img height=11 src=\"/images/sus_mm.jpg\" width=230 border=0></td>"
      "</tr>"
      "<tr>"
        "<td><img height=150 src=\"/images/st.jpg\" width=15 border=0></td>"
      	"<td width=200 height=150 align=center>"
        	"<img src=\"/images/login.jpg\" border=0 valign=top><br><br>"
		 	"<table border=0>"
      		  "<tr><td align=left valign=middle class=\"text_tabel\">Username</td><td align=left valign=middle><input type=text name=\"username\" class=\"campuri\" value=\"\" maxlength=20></td></tr>"
      		  "<tr><td align=left valign=middle class=\"text_tabel\">Password</td><td align=left valign=middle><input type=password name=\"password\" class=\"campuri\" value=\"\" maxlength=30></td></tr>"
			"</table>"
     		"<input type=image src=\"/images/signin.jpg\" border=0 valign=top>&nbsp;&nbsp;&nbsp;<a href=\"/cgi-bin/users.cgi?action=signup\"><img src=\"/images/signup.jpg\" border=0 valign=top></a>"     
        "</td>"
        "<td><img height=150 src=\"/images/dr.jpg\" width=15 border=0></td>"
      "</tr>"
      "<tr>"
        "<td colspan=3><img height=11 src=\"/images/jos.jpg\" width=230 border=0></td>"
      "</tr>"
	  "</form>"
	"</table>"
	);
	}
}

void write_download ()
{
	printf (
	"<table cellspacing=0 cellpadding=0 width=230 height=172 border=0 bgcolor=#ababab class=\"afis_tabel3\">"
      "<tr>"
        "<td colspan=3><img height=11 src=\"/images/sus_mm.jpg\" width=230 border=0></td>"
      "</tr>"
      "<tr>"
        "<td><img height=100%% src=\"/images/st.jpg\" width=15 border=0></td>"
        "<td width=200 height=150 align=center>"
          "<img src=\"/images/download.jpg\" border=0 valign=top><br><br>"
      	     "PhotoStorm Desktop is available for <a href=\"/cgi-bin/storm.cgi?page=soft#linux\"><font color=#FFFF00>Linux</font></a> and <a href=\"/cgi-bin/storm.cgi?page=soft#win32\"><font color=#FFFF00>Microsoft<sup>TM</sup> Windows<sup>TM</sup></font></a>. "
			 "For other systems, you may use the <a href=\"/cgi-bin/show.cgi?page=configw\"><font color=#FFFF00>online wallpaper</font></a> feature."
		"</td>"
      	"<td><img height=100%% src=\"/images/dr.jpg\" width=15 border=0></td>"
     	"</tr>"
     	"<tr>"
      	"<td colspan=3><img height=11 src=\"/images/jos.jpg\" width=230 border=0></td>"
        "</tr>"
	  "</table>"
	  "<br>"
	);
}

void write_right_end ()
{
	 printf (
		"</td>"
	 );
}

void write_menu_copyright ()
{
	printf (
 	"<center><font class=\"text_normal\"><b>| <a href=/cgi-bin/storm.cgi target=afis>HOME</a> | <a href=\"/cgi-bin/show.cgi?page=wallpapers\" target=afis>WALLPAPERS</a> | <a href=/cgi-bin/show.cgi target=afis>ALBUMS</a> | <a href=/cgi-bin/users.cgi target=afis>MY PHOTOS</a> | <a href=\"/cgi-bin/storm.cgi?page=world\"	target=afis>WORLDWIDE</a> | <a href=\"/cgi-bin/show.cgi?page=search\" target=afis>SEARCH</a> | <a href=/cgi-bin/storm.cgi?page=soft target=afis>SOFTWARE</a> | <a href=/cgi-bin/storm.cgi?page=about target=afis>ABOUT</a> |</b></center></font><br>"
 	"<center><font class=\"text_normal\">Copyright <a href=\"mailto:contact@photostorm.net\"><b>Project Info</b></a> 2004<br>All the content of this website is subject to the <a href=/psl.txt target=_blank><b><i>PhotoStorm License</i></b></font></center></font>"
	);
}

void main_display_init ()
{
	printf (
	"<body class=\"pagina\">"
	"<center>"
	"<table width=1000 height=400 border=0 cellpadding=0 cellspacing=0>"
	"<tr>"
	);
}

void main_display_deinit ()
{
	printf (
	"</tr>"
	);
}

void write_vertical_line ()
{
	printf (
	"<td rowspan=2 class=\"linia_verticala\" background=\"/images/linia2.jpg\">"
	"</td>"
	);
}

void write_horizontal_line ()
{
	printf (
	"<tr>"
	"<td colspan=4 width=100%% class=\"linia_orizontala\" background=\"/images/linia.jpg\">"
	"</td>"
	"</tr>"
	);
}

void main_display_close ()
{
	write_horizontal_line ();
	printf (
	"</table><br>"
	);
	write_menu_copyright ();
	printf (
	"</body>"
	"</html>"
	);
}
