
#define CHARS "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"
#define CHARS_SPACE "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_- ,"
#define CHARS_DATE "0123456789/-"
#define CHARS_EMAIL "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-@."
#define CHARS_WEBSITE "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-./:"

unsigned const int USER_MAX_L = 20;
unsigned const int PASSWORD_MIN_L = 4;
unsigned const int PASSWORD_MAX_L = 40;
unsigned const int FNAME_MAX_L = 40;
unsigned const int LNAME_MAX_L = 40;
unsigned const int EMAIL_MAX_L = 255;
unsigned const int COUNTRY_MAX_L = 30;
unsigned const int CITY_MAX_L = 30;
unsigned const int OCCUP_MAX_L = 41;
unsigned const int WEBSITE_MAX_L = 250;
unsigned const int DESCRIPTION_MAX_L = 10000;
unsigned const int INIT_USER_CREDITS = 30;
unsigned const int INIT_USER_SPACE = 2; //MB

struct _ps_user
{
	int user_id;
	char username[USER_MAX_L+1];
	char password[PASSWORD_MAX_L+1];
	char email[EMAIL_MAX_L+1];
	char first_name[FNAME_MAX_L+1];
	char last_name[LNAME_MAX_L+1];
	char birthdate[11];
	char country[COUNTRY_MAX_L+1];
	char city[CITY_MAX_L+1];
	char ocupation[OCCUP_MAX_L+1];
	char website[WEBSITE_MAX_L+1];
	char description [DESCRIPTION_MAX_L+1];
	int credits;
	int space;
};

int db_init ();
int user_exists (const char *username);
int user_add (_ps_user *user);
_ps_user * get_user_info (const char *username);
void db_close ();
