
#include "data.h"
#include "htmls.h"
#include "misc.h"
#include "cgi_cpp.h"
#include "db.h"
#include <string.h>
#include <stdio.h>
#include <dirent.h>

void write_header ()
{
	printf (
	"<head>"
		"<title>Welcome to PhotoStorm.net</title>"
		"<link href=\"/css/ps_style.css\" type=\"text/css\" rel=\"StyleSheet\">"
	"</head>"
	);
}

void write_album_categories ()
{
	printf (
	"<table cellspacing=0 cellpadding=0 width=230 border=0 bgcolor=#ababab class=\"window_yellow_full\">"
      "<form action=\"/cgi-bin/users.cgi?action=login\" method=POST>"
      "<tr>"
      	"<td colspan=3><img height=11 src=\"/images/sus_mm.jpg\" width=230 border=0></td>"
      "</tr>"
      "<tr>"
        "<td><img height=100%% src=\"/images/st.jpg\" width=15 border=0></td>"
      	"<td valign=top width=200 height=150 align=center><br>"
        	"<img src=\"/images/categories.jpg\" border=0 valign=top><br>"
		 	"<table border=0>"
      		  "<tr><td align=center valign=middle class=\"text_tabel\">"
	);
	int nr = get_categories ();
	_ps_category_list *categorii = get_categories_list ();
	for (int i=0;i<nr;i++) printf ("<a href=\"/cgi-bin/artstorm.cgi?page=category&category_id=%d\">%s</a><br>", categorii[i].cat_id, categorii[i].nume);
	printf (
	"</td></tr>"
			"</table>"
        "</td>"
        "<td><img height=100%% src=\"/images/dr.jpg\" width=15 border=0></td>"
      "</tr>"
      "<tr>"
        "<td colspan=3><img height=11 src=\"/images/jos.jpg\" width=230 border=0></td>"
      "</tr>"
	  "</form>"
	"</table>"
	);
}

void write_right_start ()
{
	printf (
	"<br>"
	"<td rowspan=2 width=* align=center valign=top>"
	);
}

void write_login ()
{
	if (session_var_get ("login_name"))
	{
	printf (
	"<table cellspacing=\"0\" cellpadding=\"0\" width=\"230\" height=172 border=0 bgcolor=#ababab class=\"window_yellow_full\">"
      "<form action=\"/cgi-bin/users.cgi?action=login\" method=POST>"
      "<tr>"
      	"<td colspan=3><img height=11 src=\"/images/sus_mm.jpg\" width=230 border=0></td>"
      "</tr>"
      "<tr>"
        "<td><img height=100%% src=\"/images/st.jpg\" width=15 border=0></td>"
      	"<td width=200 height=150 align=center>"
        	"<img src=\"/images/qmenu.jpg\" border=0 valign=top><br><br>"
			   "<a href=/cgi-bin/users.cgi>Home</a><br>"
		 	   "<a href=/cgi-bin/messages.cgi>Messages</a><br>"
      		   "<a href=/cgi-bin/show.cgi?data=user>My Albums</a><br>"
      		   "<a href=/cgi-bin/users.cgi?page=edit_profile>Edit Profile</a><br>"
      		   "<a href=/cgi-bin/msgstorm.cgi>Forum</a><br>"
      		   "<!--<a href=/cgi-bin/users.cgi?action=members>Member list</a><br>-->"
			   "<a href=/cgi-bin/users.cgi?action=logout>Logout</a><br><br>"
        "</td>"
        "<td><img height=100%% src=\"/images/dr.jpg\" width=15 border=0></td>"
      "</tr>"
      "<tr>"
        "<td colspan=3><img height=11 src=\"/images/jos.jpg\" width=230 border=0></td>"
      "</tr>"
	  "</form>"
	"</table>"
	);
	}
	else
	{
	printf (
	"<table cellspacing=\"0\" cellpadding=\"0\" width=\"230\" height=172 border=0 bgcolor=#ababab class=\"window_yellow_full\">"
      "<form action=\"/cgi-bin/users.cgi?action=login\" method=POST>"
      "<tr>"
      	"<td colspan=3><img height=11 src=\"/images/sus_mm.jpg\" width=230 border=0></td>"
      "</tr>"
      "<tr>"
        "<td><img height=150 src=\"/images/st.jpg\" width=15 border=0></td>"
      	"<td width=200 height=150 align=center>"
        	"<img src=\"/images/login.jpg\" border=0 valign=top><br><br>"
		 	"<table border=0>"
      		  "<tr><td align=left valign=middle class=\"text_tabel\">Username</td><td align=left valign=middle><input type=text name=\"username\" class=\"campuri\" value=\"\" maxlength=20></td></tr>"
      		  "<tr><td align=left valign=middle class=\"text_tabel\">Password</td><td align=left valign=middle><input type=password name=\"password\" class=\"campuri\" value=\"\" maxlength=30></td></tr>"
			"</table>"
     		"<input type=image src=\"/images/signin.jpg\" border=0 valign=top>&nbsp;&nbsp;&nbsp;<a href=\"/cgi-bin/users.cgi?action=signup\"><img src=\"/images/signup.jpg\" border=0 valign=top></a>"     
        "</td>"
        "<td><img height=150 src=\"/images/dr.jpg\" width=15 border=0></td>"
      "</tr>"
      "<tr>"
        "<td colspan=3><img height=11 src=\"/images/jos.jpg\" width=230 border=0></td>"
      "</tr>"
	  "</form>"
	"</table>"
	);
	}
}

void write_download ()
{
	printf (
	"<table cellspacing=0 cellpadding=0 width=230 height=172 border=0 bgcolor=#ababab class=\"afis_tabel3\">"
      "<tr>"
        "<td colspan=3><img height=11 src=\"/images/sus_mm.jpg\" width=230 border=0></td>"
      "</tr>"
      "<tr>"
        "<td><img height=100%% src=\"/images/st.jpg\" width=15 border=0></td>"
        "<td width=200 height=150 align=center>"
          "<img src=\"/images/download.jpg\" border=0 valign=top><br><br>"
      	     "PhotoStorm Desktop is available for <a href=\"/cgi-bin/storm.cgi?page=soft#linux\"><font color=#FFFF00>Linux</font></a> and <a href=\"/cgi-bin/storm.cgi?page=soft#win32\"><font color=#FFFF00>Microsoft<sup>TM</sup> Windows<sup>TM</sup></font></a>. "
			 "For other systems, you may use the <a href=\"/cgi-bin/show.cgi?page=configw\"><font color=#FFFF00>online wallpaper</font></a> feature."
		"</td>"
      	"<td><img height=100%% src=\"/images/dr.jpg\" width=15 border=0></td>"
     	"</tr>"
     	"<tr>"
      	"<td colspan=3><img height=11 src=\"/images/jos.jpg\" width=230 border=0></td>"
        "</tr>"
	  "</table>"
	  "<br>"
	);
}

void write_right_end ()
{
	 printf (
		"</td>"
	 );
}

void write_menu_copyright ()
{
	printf (
 	"<font class=\"text_normal\"><b>| <a href=/cgi-bin/artstorm.cgi target=afis>HOME</a> | <a href=\"/cgi-bin/artstorm.cgi?page=wallpapers\" target=afis>WALLPAPERS</a> | <a href=/cgi-bin/artstorm.cgi?page=albums target=afis>ALBUMS</a> | <a href=/cgi-bin/artstorm.cgi?page=user target=afis>MY PHOTOS</a> | <a href=\"/cgi-bin/artstorm.cgi?page=worldwide\" target=afis>WORLDWIDE</a> | <a href=\"/cgi-bin/artstorm.cgi?page=search\" target=afis>SEARCH</a> | <a href=/cgi-bin/artstorm.cgi?page=software target=afis>SOFTWARE</a> | <a href=/cgi-bin/artstorm.cgi?page=about target=afis>ABOUT</a> |</b></font><br><br>"
 	"<font class=\"text_normal\">Copyright <a href=\"mailto:contact@photostorm.net\"><b>Project Info</b></a> 2004<br>All the content of this website is subject to the <a href=/psl.txt target=_blank><b><i>PhotoStorm License</i></b></font>"
	);
}

void main_display_init ()
{
	printf (
	"<body class=\"pagina\">"
	"<center>"
	"<table width=1000 height=400 border=0 cellpadding=0 cellspacing=0>"
	"<tr>"
	);
}

void main_display_deinit ()
{
	printf (
	"</tr>"
	);
}

void write_vertical_line ()
{
	printf (
	"<td width=10 class=\"linia_verticala\" background=\"/images/linia2.jpg\">"
	"</td>"
	);
}

void write_horizontal_line ()
{
	printf (
	"<tr>"
	"<td colspan=3 width=1000 height=13 class=\"linia_orizontala\" background=\"/images/linia.jpg\">"
	"</td>"
	"</tr>"
	);
}

void main_display_close ()
{
	write_horizontal_line ();
	printf (
	"</table><br>"
	);
	write_menu_copyright ();
	printf (
	"</body>"
	"</html>"
	);
}

void write_quote ()
{
	int nr = get_quotes_count ();
	_ps_quote *q = get_quote_nr (1+ps_random (nr));
	if (q!=NULL)
	{
		ps_quote_free (q);
	}
}

void show_small_photo (int album_id, int photo_id, const char* alt_text, const char *link, const char *text)
{
	printf (
		"<table border=0 cellspacing=0 cellpadding=0"
		"<tr><td valign=top align=center>"
		"<table border=0 cellpadding=0 cellspacing=0>"
		"<tr><td width=170 height=130 class=\"display_photo\" valign=middle align=center><a href=\"%s\"><img src=\"/cgi-bin/get_photo.cgi?album_id=%d&photo_id=%d&x=160&y=120\" border=0 height=120 width=160 class=\"display_photo\" alt=\"%s\"></a></td></tr>"
		"</table>"
		"</td></tr>"
	, link, album_id, photo_id, alt_text);
	if (text!=NULL && strcmp (text, "")!=0) printf ("<tr><td valign=top align=center class=\"photo_text\">%s<br><br></td></tr>", text);
	printf ("</table>");
}

void show_very_small_photo (int album_id, int photo_id, const char* alt_text, const char *link, const char *text)
{
	printf (
		"<table border=0 cellspacing=0 cellpadding=0"
		"<tr><td valign=top align=center>"
		"<table border=0 cellpadding=0 cellspacing=0>"
		"<tr><td width=106 height=81 class=\"display_photo\" valign=middle align=center><a href=\"%s\"><img src=\"/cgi-bin/get_photo.cgi?album_id=%d&photo_id=%d&x=100&y=75\" border=0 height=75 width=100 class=\"display_photo\" alt=\"%s\"></a></td></tr>"
		"</table>"
		"</td></tr>"
	, link, album_id, photo_id, alt_text);
	if (text!=NULL && strcmp (text, "")!=0) printf ("<tr><td valign=top align=center class=\"photo_text\">%s<br><br></td></tr>", text);
	printf ("</table>");
}

void write_small_album (int album_id, const char *name, const char *author, int nr_photos, const char* link)
{
	char text[1000];
	sprintf (text, "%s<br><i>&copy; %s</i><br>%d photos", filter_html_code(name), filter_html_code(author), nr_photos);
	printf (
	"<table cellspacing=0 cellpadding=0 border=0>"
	"<tr><td valign=top align=center>"
		"<table cellspacing=0 cellpadding=0 width=160 border=0>"
    	"<tr>"
    		"<td><a href=\"%s\"><img src=\"/cgi-bin/get_photo.cgi?album_id=%d&photo_id=0&x=160&y=120\" border=0 height=120 width=160></a></td>"
    		"<td><img height=120 src=\"/images/dr_m.jpg\" width=10 border=0></td>"
    	"</tr>"
    	"<tr>"
    		"<td colspan=3><img height=10 src=\"/images/jos_m.jpg\" width=160 border=0></td>"
    	"</tr>"
		"</table>"
	"</td></tr>"
    "<tr>"
    	"<td colspan=3><center><font class=\"text_normal\">%s<br><br></center></font></td>"
    "</tr>"
	"</table>"
	, link, album_id, text);
}

void show_large_photo (int album_id, int photo_id, const char *link, const char *alt_text, const char *text)
{
	printf (
		"<table border=0 cellspacing=20 cellpadding=0"
		"<tr><td valign=top align=center>"
		"<table border=0 cellpadding=5 cellspacing=0>"
		"<tr><td width=400 height=300 class=\"display_photo\" valign=middle align=center><a href=\"%s\"><img src=\"/cgi-bin/get_photo.cgi?album_id=%d&photo_id=%d&x=400&y=300\" border=0 height=300 width=400 class=\"display_photo\" alt=\"%s\"></a><br><br>%s</td></tr>"
		"</table>"
		"</td></tr>"
	, link, album_id, photo_id, alt_text, text);
	printf ("</table>");
}
