
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "cgi_cpp.h"
#include "album.h"
#include "photo.h"
#include "misc.h"
#include "configs.h"
#include "db.h"

const char * user_album_path (const char *album)
{
    char s[1000];
    strcpy (s,"");
    if (album!=NULL) sprintf (s, "%s/%s/albums/%s.psa", psw_users_path, session_var_get ("login_name"), album);
    return strdup (s);
}

int ps_generate_code_photo ()
{
	int code = 0;
	gdImage *img = gdImageCreate (100, 35);
	if (img!=NULL)
	{
		int gri = gdImageColorAllocate (img, 126, 126, 126);
		gri=0;
		int alb = gdImageColorAllocate (img, 255, 255, 255);
		int negru = gdImageColorAllocate (img, 156, 156, 156);
		gdImageRectangle (img, 0, 0, 99, 34, negru);
		int x = 1 + (int) (10000000.0 * rand()/(RAND_MAX + 1.0));
		code = x;
		int spatiu_text[8];
		gdImageStringFT (img, &spatiu_text[0], alb, font_path ("signature"), 14, -0.2, 10, 15, (char*)ps_inttostr (x));
		int n = 0;
		char *date = NULL;
		date = (char*)gdImageJpegPtr (img, &n, 90);
		gdImageDestroy (img);
		if (date!=NULL && n>0)
		{	
			printf ("Pragma: public\n");
			printf ("Cache-Control: no-store, max-age=0, no-cache, must-revalidate\n");
			printf ("Cache-Control: post-check=0, pre-check=0\n");
			printf ("Cache-control: private\n");
			printf ("Content-Disposition: inline; filename=\"signup_code.jpg\"\n");
			printf ("Content-Length: %u\n", n);
			content ("image/jpeg; name=\"signup_code.jpg\"");
			fwrite (date, n, 1, stdout);
		}
		if (date!=NULL) free (date);
	}
	return code;
}

int main()
{
	db_init ();
	srand (time(0));
	getquery();
	const char *code = get_query_var ("code");
	if (code!=NULL && (strcmp (code, "generate")==0))
	{
		int code = ps_generate_code_photo ();
		if (!session_init ()) session_new ();
		session_var_set ("signup_code", ps_inttostr (code));
		return 0;
	}
	const char *display_type = get_query_var ("display_type");
	int album_id = ps_strtoint (get_query_var ("album_id"));
	const char *myalbum_name = get_query_var ("myalbum_name");
	const char *sphoto_id = get_query_var ("photo_id");
	int photo_id=0;
	if (sphoto_id==NULL) photo_id = -1;
		else photo_id = ps_strtoint (sphoto_id);
	int dxp = ps_strtoint (get_query_var ("x"));
	int dyp = ps_strtoint (get_query_var ("y"));
	if (dxp<0) dxp=0;
	if (dyp<0) dyp=0;
	const char *album_name = get_album_file (album_id);
	const char *page = get_query_var ("page");
	// album
	if (album_name!=NULL && page==NULL)
	{
		if (photo_id>-1)
		{
			_ps_photo *date_poza = NULL;
			if (photo_id>0) date_poza = ps_load_photo_nr_from_album_file (album_path_(album_name), photo_id);
				else date_poza = ps_load_photo_random_from_album_file (album_path_(album_name));
			int n=0;
			char *date = NULL;
			if (display_type!=NULL && strcmp (display_type, "wallpaper")==0)
			{
				if (!session_init()) exit (0);
				const char *login_name = session_var_get ("login_name");
				_ps_config *config = ps_load_config (user_file (login_name, "wallpaper.cfg"));
				if (config==NULL) config = ps_load_config (psw_config_default);
				if (config!=NULL)
				{
					if (dxp>0) config->system.scr_width=dxp;
					if (dyp>0) config->system.scr_height=dyp;
				}
				date = ps_create_photo_wallpaper (date_poza, n, config);
			}
			else
			{
				if (dxp>0 || dyp>0) date = ps_create_photo_preview_data (date_poza->date, date_poza->n_poza, dxp, dyp, n, false);
				else
				{
					date = ps_create_photo_export_data (date_poza->date, date_poza->n_poza, n);
					/*date = date_poza->date;
					n = date_poza->n_poza;*/
				}
			}
			if (date!=NULL && n>0)
			{
				char filename[1000];
				if (display_type!=NULL && strcmp (display_type, "wallpaper")==0) strcpy (filename, "ps_wallpaper.jpg");
					else sprintf (filename, "%s___%s.jpg", ps_strfilter_filename(date_poza->autor), ps_strfilter_filename(date_poza->nume));
				printf ("Pragma: public\n");
				printf ("Cache-Control: no-store, max-age=0, no-cache, must-revalidate\n");
				printf ("Cache-Control: post-check=0, pre-check=0\n");
				printf ("Cache-control: private\n");
				printf ("Content-Disposition: inline; filename=\"%s\"\n", filename);
				printf ("Content-Length: %u\n",n+1000);
				const char *save = get_query_var ("save");
				if (save!=NULL && strcmp (save, "yes")==0) 
				{
					printf ("Content-Type: application/octet-stream; name=\"%s\"\n\n", filename);
					score_add (album_id, photo_id, 2);
				}
					else printf ("Content-Type: image/jpeg; name=\"%s\"\n\n", filename);
				fwrite (date, n, 1, stdout);
				if (display_type!=NULL && strcmp (display_type, "wallpaper")==0) score_add (album_id, photo_id, 1);
			}
			if (date!=NULL) free (date);
			if (date_poza!=NULL) ps_photo_free (date_poza);
		}
	}
	else
	if (album_name!=NULL && photo_id > -1 && page!=NULL && strcmp (page, "download_photo")==0)
	{
		_ps_album *dwl = NULL;
		_ps_album *date_album = ps_load_album (album_path_ (album_name));
		int id = photo_id;
		if (date_album!=NULL)
		{
			_ps_photo *date_poza = ps_load_photo_nr_from_album_memory (date_album, id);
			if (date_poza!=NULL)
			{
				dwl = ps_create_new_album_in_memory (date_album->nume, date_album->autor,
													 date_album->categoria, date_album->descriere,
													 "", "");
				if (dwl!=NULL)
				{
					ps_add_photo_to_album_from_memory_into_memory (date_poza, dwl);
					long n;
					char *date = NULL;
					date = ps_pack_album (dwl, n);
					char filename[1000];
					sprintf (filename, "psp_%ld%d.psp", time(0), (1 + (int) (100000000.0 * rand()/(RAND_MAX + 1.0))));
					printf ("Pragma: public\n");
					printf ("Cache-Control: no-store, max-age=0, no-cache, must-revalidate\n");
					printf ("Cache-Control: post-check=0, pre-check=0\n");
					printf ("Cache-control: private\n");
					printf ("Content-Disposition: inline; filename=\"%s\"\n", filename);
					printf ("Content-Length: %ld\n",n);
					printf ("Content-Type: photo_album/psp; name=\"%s\"\n\n", filename);
					fwrite (date, n, 1, stdout);
					if (date!=NULL) free (date);
					ps_album_free (dwl);
					score_add (album_id, id, 3);
				}
				ps_photo_free (date_poza);
			}
			ps_album_free (date_album);
		} 
	}
	else
	if (album_name!=NULL && photo_id < 0 && page!=NULL && strcmp (page, "download_album")==0)
	{
		_ps_album *date_album = ps_load_album (album_path_ (album_name));
		if (date_album!=NULL)
		{
			long n;
			char *date = NULL;
			date = ps_pack_album (date_album, n);
			char filename[1000];
			sprintf (filename, "psa_%ld%d.psa", time(0), (1 + (int) (100000000.0 * rand()/(RAND_MAX + 1.0))));
			printf ("Pragma: public\n");
			printf ("Cache-Control: no-store, max-age=0, no-cache, must-revalidate\n");
			printf ("Cache-Control: post-check=0, pre-check=0\n");
			printf ("Cache-control: private\n");
			printf ("Content-Disposition: inline; filename=\"%s\"\n", filename);
			printf ("Content-Length: %ld\n",n);
			printf ("Content-Type: photo_album/psa; name=\"%s\"\n\n", filename);
			fwrite (date, n, 1, stdout);
			if (date!=NULL) free (date);
			for (int i=0;i<date_album->nr_poze;i++) score_add (album_id, i+1, 3);
			score_add (album_id, 1); 
			ps_album_free (date_album);
		}
	}
	else
	// my album
	if (myalbum_name!=NULL)
	{
		if (!session_init()) exit (0);
		if (photo_id>-1)
		{
			_ps_photo *date_poza = NULL;
			if (photo_id>0) date_poza = ps_load_photo_nr_from_album_file (user_album_path(myalbum_name), photo_id);
				else date_poza = ps_load_photo_random_from_album_file (user_album_path(myalbum_name));
			int n=0;
			char *date = NULL;
			if (dxp>0 || dyp>0) date = ps_create_photo_preview_data (date_poza->date, date_poza->n_poza, dxp, dyp, n, false);
			else
			{
				date = date_poza->date;
				n = date_poza->n_poza+200;
			}
			if (date!=NULL && n>0)
			{
				char filename[1000];
				sprintf (filename, "%s___%s.jpg", ps_strfilter_filename(date_poza->autor), ps_strfilter_filename(date_poza->nume));
				printf ("Pragma: public\n");
				printf ("Cache-Control: no-store, max-age=0, no-cache, must-revalidate\n");
				printf ("Cache-Control: post-check=0, pre-check=0\n");
				printf ("Cache-control: private\n");
				printf ("Content-Disposition: inline; filename=\"%s\"\n", filename);
				printf ("Content-Length: %u\n",n);
				printf ("Content-Type: image/jpeg; name=\"%s\"\n\n", filename);
				fwrite (date, n, 1, stdout);
			}
			if (date!=NULL) free (date);
			if (date_poza!=NULL) ps_photo_free (date_poza);
		}
	}
	db_close ();
}
