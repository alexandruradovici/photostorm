// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef PHOTOSTORM_PRIVATE_H
#define PHOTOSTORM_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"0.1.1.404"
#define VER_MAJOR	0
#define VER_MINOR	1
#define VER_RELEASE	1
#define VER_BUILD	404
#define COMPANY_NAME	"Project Info"
#define FILE_VERSION	"Win32-0.1.1"
#define FILE_DESCRIPTION	"PhotoStorm Desktop"
#define INTERNAL_NAME	"photostorm"
#define LEGAL_COPYRIGHT	"Project Info 2004 under the GNU GPL License"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"PhotoStorm Desktop"
#define PRODUCT_VERSION	"Win32-0.1.1"

#endif //PHOTOSTORM_PRIVATE_H
