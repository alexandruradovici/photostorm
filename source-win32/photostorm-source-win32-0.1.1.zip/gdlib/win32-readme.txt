Welcome to the win32 binary distribution of the gd library! This 
win32 distribution includes the dynamic link library bgd.dll, the 
mingw32/cygwin import library libbgd.a, the export definitions file
bgd.def, the gd header files, the gd manual in the file index.html, 
and a few simple win32 console applications that relate to gd. 

If you are a PHP programmer, you may be in the wrong place. The 
current release of PHP includes its own GD dll which works well 
with that language. You do not need this version for PHP.

Need an import library for MSVC? Type "makemsvcimport.bat" to
build bgd.lib using your copy of MSVC. Similar syntax will
work for other compilers. 

See the gd FAQ for more information about gd:

http://www.boutell.com/gd/faq.html

