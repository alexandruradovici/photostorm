
#ifndef _PS_WIZARDS__H
#define _PS_WIZARDS__H

#include <gtk/gtk.h>

// functions
void ps_add_photo_wizard ();
void ps_create_album_wizard ();

#endif
