
char *crypt (const char *key, const char *salt);
